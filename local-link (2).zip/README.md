# Local Link — Final Integrated Platform

Local Link is a single-origin local-service booking platform served at **http://localhost:3000**.

## Workflow implemented

### 1. Login and email verification
- Customer and Service Professional accounts use the same front-door login.
- Registration requires a real email address, phone number, strong password and OTP verification.
- OTPs are stored as hashes in PostgreSQL and expire after 5 minutes.
- OTP sending uses **Resend** on the server; no email/API secret is exposed to the browser.
- Production startup requires a real email provider. Development can use `DEV_EMAIL_MODE=true` to print OTPs to the server terminal for local testing.

### 2. Service Professional assessment
- Professional login opens `/assessment/`.
- The user selects **Plumber, Electrician, Carpenter or House Keeping**.
- Exactly 20 questions are loaded from PostgreSQL for the selected profession.
- The assessment is 20 minutes, supports visited/unanswered/answered state, manual submission and automatic timeout submission.
- The server calculates the result.
- **60% or higher** unlocks the professional console.
- Assessment questions/options/answers/attempt state are PostgreSQL-backed; assessment media has a separate PostgreSQL image schema.

### 3. Professional dashboard
- Only professionals who have passed the assessment can enter `/worker/`.
- Requests are ordered by their selected time slot.
- A professional can accept one pending request at a time.
- Accepting one request atomically changes all other pending requests for that professional to `auto-rejected`.
- The customer receives a clear booking-update state and can choose another professional.
- Exact customer latitude/longitude is hidden from the worker until acceptance.
- After acceptance, both sides receive confirmation emails; the worker email contains the customer's name, email, phone, service, time and exact location.
- A worker can mark an accepted job completed.
- Worker history is calculated per worker from PostgreSQL metrics and customer reviews; there are no fake shared weekly statistics.

### 4. Customer booking
After customer login, the customer chooses:

**AI Automated**
- Chat-style problem description.
- Groq understands the problem and identifies the likely profession.
- The backend ranks eligible workers using verification, service compatibility, availability, distance, reputation and reliability.
- The customer selects a recommended worker and time slot.

**Self Booking**
- Leaflet/OpenStreetMap map.
- Current location or searched landmark can be selected.
- Customer chooses radius, profession and one-hour slot.
- Eligible workers are ranked and displayed.
- The customer selects a worker and sends a request.

Both modes use the same PostgreSQL booking lifecycle and worker console.

### 5. Reviews and safety rating
After a completed job, the customer can submit:
- overall rating
- punctuality
- professionalism
- safety
- written review

The worker reputation is calculated from these factors rather than stars alone. The review is also copied into the worker analytics dataset so each professional's dashboard remains independent.

## AI provider
OpenAI has been removed from the active customer AI implementation.

The customer AI uses Groq's OpenAI-compatible Chat Completions endpoint and defaults to `openai/gpt-oss-120b`. Groq's current documentation lists that model as a production model and documents the same endpoint used by this project. See the official Groq API reference: https://console.groq.com/docs/api-reference

Set:

```env
GROQ_API_KEY=your_key_here
GROQ_MODEL=openai/gpt-oss-120b
```

A deterministic local classifier remains available when the key is absent or the provider is temporarily unavailable, so booking discovery does not become unusable.

## Email configuration
For real OTP and booking emails, configure Resend with a verified sending domain/address. Resend requires domain verification for sending domains; SPF/DKIM records are part of that verification process.

Set:

```env
RESEND_API_KEY=your_key_here
MAIL_FROM_EMAIL=verified@your-domain.com
```

Do **not** put these values in any frontend `.env` file.

## PostgreSQL
One hosted PostgreSQL database is sufficient. The project creates its required tables/schemas automatically on startup. No local PostgreSQL installation and no Docker daemon are required.

Set:

```env
DATABASE_URL=your_hosted_postgresql_connection_string
DATABASE_SSL=true
JWT_SECRET=generate_a_long_random_secret
```

## Run

```bash
npm run install:all
npm run build
npm start
```

Then open:

**http://localhost:3000**

## Security included
- Helmet security headers
- Content Security Policy at the gateway
- PostgreSQL persistence
- server-side sessions with HttpOnly cookies
- short-lived bridge tokens
- OTP hashing and attempt limits
- login throttling and account lockout
- request body limits
- API rate limiting
- role/assessment authorization
- transactional booking acceptance
- atomic competing-request rejection
- exact-location disclosure only after acceptance
- no API keys in frontend code

## Validation performed for the final source package
- Node.js syntax checks across gateway, authentication, customer backend, worker backend and scripts.
- Package JSON validation.
- Search for active OpenAI configuration references and legacy worker JSON storage.
- Route/link/source audit against the requested workflow.

A full live PostgreSQL/API/browser run still requires the user's hosted PostgreSQL URL, verified Resend sender/API key, and (for AI) Groq key; those secrets cannot be embedded in the ZIP.

## Email setup: Gmail SMTP

Local Link supports Gmail SMTP for **both email verification/OTP and booking notifications**. SMTP is preferred over Resend when these variables are present:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=your-gmail@gmail.com
SMTP_PASS=your-google-app-password
SMTP_FROM=your-gmail@gmail.com
```

`SMTP_PASS` must be a Google App Password, not the normal Gmail password. Resend remains an optional fallback only. Do not put either credential in frontend code or commit them to source control.
