import { useEffect } from 'react';

/* Staggered fade/slide-in for elements as they enter the viewport (runs once per element). */
const GROUPS = [['.sec .h', 0], ['.sec .lead', 0], ['.tile', 0.07], ['.pts li', 0.1], ['.bk', 0],
                ['.tl li', 0.14], ['.cta', 0], ['.faq details', 0.07]];

export default function useReveal() {
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) return;
    const els = [];
    GROUPS.forEach(([selector, step]) => {
      const counts = new Map();
      document.querySelectorAll(selector).forEach((el) => {
        const i = counts.get(el.parentNode) || 0;
        counts.set(el.parentNode, i + 1);
        const delay = i * step + (selector === '.sec .lead' ? 0.08 : 0);
        el.classList.add('rv');
        el.style.setProperty('--d', `${delay.toFixed(2)}s`);
        els.push(el);
      });
    });
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (!e.isIntersecting) return;
        const el = e.target;
        io.unobserve(el);
        el.classList.add('in');
        el.addEventListener('transitionend', function done(ev) {
          if (ev.propertyName !== 'opacity') return;
          el.removeEventListener('transitionend', done);
          el.classList.remove('rv', 'in');   // hand control back to hover styles
          el.style.removeProperty('--d');
        });
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -6% 0px' });
    els.forEach((el) => io.observe(el));
    return () => {
      io.disconnect();
      els.forEach((el) => { el.classList.remove('rv', 'in'); el.style.removeProperty('--d'); });
    };
  }, []);
}
