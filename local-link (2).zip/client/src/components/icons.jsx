export const LogoMark = () => (
  <svg viewBox="0 0 24 24"><path d="M12 22s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12z" fill="#2563eb" /><circle cx="12" cy="10" r="2.6" fill="#fff" /></svg>
);
export const Logo = () => <a className="logo" href="/"><LogoMark />Local Link</a>;

export const ProIcon = () => (
  <svg viewBox="0 0 40 40"><path d="M7 36c0-7 6-11 13-11s13 4 13 11z" fill="#3b82f6" /><circle cx="20" cy="16" r="6" fill="#f2c9a0" /><path d="M12.5 14.5a7.5 7.5 0 0 1 15 0z" fill="#2563eb" /><rect x="11" y="13.5" width="18" height="3" rx="1.5" fill="#1d4ed8" /></svg>
);
export const CustomerIcon = () => (
  <svg viewBox="0 0 40 40"><path d="M5 19L20 6l15 13" fill="none" stroke="#16a36a" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /><path d="M9 17v16h22V17L20 8z" fill="#e6f6ee" stroke="#16a36a" strokeWidth="2.4" strokeLinejoin="round" /><rect x="16" y="22" width="8" height="11" rx="1" fill="#16a36a" /></svg>
);
export const ArrowIcon = () => (
  <svg className="ar" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" /></svg>
);

const hard = (<><path d="M12 15.5a8 8 0 0 1 16 0z" fill="#f5b800" /><rect x="10.5" y="14.5" width="19" height="2.6" rx="1.3" fill="#e0a400" /></>);
const cap = (c) => (<><path d="M12.5 15.5a7.5 7.5 0 0 1 15 0z" fill={c} /><rect x="12" y="14.5" width="22" height="2.4" rx="1.2" fill={c} /></>);
const people = {
  electrician: ['#fde9b8', '#f59e0b', '#d9a577', hard],
  plumber: ['#d6e4ff', '#2563eb', '#f0c7a0', cap('#1d4ed8')],
  ac: ['#d4f0e4', '#16a36a', '#b98160', cap('#0f7f52')],
};
export function Avatar({ who }) {
  const [bg, shirt, skin, hat] = people[who];
  return (
    <span className="av"><svg viewBox="0 0 40 40"><rect width="40" height="40" fill={bg} /><path d="M5 40c0-9 6-13 15-13s15 4 15 13z" fill={shirt} /><circle cx="20" cy="17" r="7" fill={skin} />{hat}</svg></span>
  );
}
