import { Avatar } from './icons.jsx';

const services = [
  ['Electrician', 'Wiring, fans, switches and appliance fittings.', <path d="M13 3L5 14h6l-1 7 8-11h-6z" />],
  ['Plumber', 'Leaks, taps, drains and bathroom fixtures.', <path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z" />],
  ['Carpenter', 'Furniture repair, doors, shelves and fittings.', <path d="M4 20L20 4M14 4h6v6M4 14v6h6" />],
  ['Mechanic', 'Bike and car servicing, doorstep checks and repairs.', <path d="M14.5 6.5a4 4 0 0 0-5 5L4 17l3 3 5.5-5.5a4 4 0 0 0 5-5l-2.5 2.5-2.5-.5-.5-2.5z" />],
  ['AC Technician', 'Installation, gas refill, servicing and repair.', <path d="M12 3v18M4.5 7.5l15 9M19.5 7.5l-15 9" />],
  ['Home Cleaning', 'Deep cleaning for kitchens, bathrooms and rooms.', <path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM18 16l.8 2.2L21 19l-2.2.8L18 22l-.8-2.2L15 19l2.2-.8z" />],
];

const points = [
  ['Profiles you can check', 'Ratings and reviews come from completed bookings, not from the professionals themselves.'],
  ['Prices before you book', 'See the cost up front and compare nearby professionals side by side.'],
  ['Track every booking', 'Confirmation, arrival and completion all stay in one place.'],
];

const faqs = [
  ['How do I book a professional?', "Choose Customer, log in, then pick a service. You can compare nearby professionals and schedule a time that works for you."],
  ['How are professionals rated?', 'Ratings and reviews are left by customers after a completed booking.'],
  ['Can I join as a service professional?', 'Yes. Choose Service Professional, select your profession and log in to start receiving nearby jobs.'],
  ['Which services are available?', 'Electrician, plumber, carpenter, mechanic, AC technician and home cleaning, with more being added.'],
];

const Check = () => (
  <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" /><path d="M8 12.5l3 3 5-6" /></svg>
);

export default function Sections({ onSelect }) {
  return (
    <>
      <section className="sec" id="services">
        <div className="wrap">
          <h2 className="h">Book the help your home needs</h2>
          <p className="lead">Pick a service to get started. You'll see professionals near you, with ratings and prices before you book.</p>
          <div className="svc">
            {services.map(([name, text, icon]) => (
              <button className="tile" type="button" key={name} onClick={() => onSelect('customer')}>
                <svg viewBox="0 0 24 24">{icon}</svg>
                <span><b>{name}</b><small>{text}</small></span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="sec band">
        <div className="wrap trust">
          <div>
            <h2 className="h">Know who is coming to your door</h2>
            <p className="lead">Every booking shows who is coming, when they arrive and what it costs, so there are no surprises.</p>
            <ul className="pts">
              {points.map(([title, text]) => (
                <li key={title}><Check /><div><b>{title}</b><span>{text}</span></div></li>
              ))}
            </ul>
          </div>
          <div className="bk" aria-hidden="true">
            <div className="bk-h"><span>Booking summary</span><span className="ok">Confirmed</span></div>
            <div className="bk-p"><Avatar who="electrician" /><div><b>Electrician</b><small><i>4.8 ★</i> · 1.2 km away</small></div></div>
            <ul className="tl">
              <li className="d">Booking confirmed<em>Today</em></li>
              <li className="d">Professional assigned<em>Today</em></li>
              <li>On the way<em>Tomorrow, 10:00 AM</em></li>
              <li>Job completed and reviewed</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="sec">
        <div className="wrap">
          <div className="cta">
            <div>
              <h2>Offer your skills to people nearby</h2>
              <p>Join Local Link as a service professional to get nearby jobs and manage your bookings in one place.</p>
            </div>
            <button className="btn" type="button" onClick={() => onSelect('professional')}>Join as a professional</button>
          </div>
        </div>
      </section>

      <section className="sec" style={{ paddingTop: 8 }}>
        <div className="wrap">
          <h2 className="h">Common questions</h2>
          <div className="faq">
            {faqs.map(([q, a]) => (
              <details key={q}><summary>{q}</summary><p>{a}</p></details>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
