import { Logo, ProIcon, CustomerIcon, ArrowIcon } from './icons.jsx';

export default function RoleCard({ onSelect }) {
  return (
    <section className="card" aria-labelledby="cont">
      <Logo />
      <h2 id="cont">How do you want to continue?</h2>
      <div className="roles">
        <button className="role active" type="button" onClick={() => onSelect('professional')}>
          <span className="ic"><ProIcon /></span>
          <span className="t"><b>Service Professional</b><small>Get nearby jobs &amp; manage your services.</small></span>
          <ArrowIcon />
        </button>
        <button className="role" type="button" onClick={() => onSelect('customer')}>
          <span className="ic"><CustomerIcon /></span>
          <span className="t"><b>Customer</b><small>Find &amp; book trusted professionals near you.</small></span>
          <ArrowIcon />
        </button>
      </div>
    </section>
  );
}
