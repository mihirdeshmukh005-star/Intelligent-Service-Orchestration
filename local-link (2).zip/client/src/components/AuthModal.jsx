import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ProIcon, CustomerIcon } from './icons.jsx';
import { api } from '../api.js';
import { emailProblem, passwordProblem, passwordStrength, STRENGTH_LABEL } from '../validators.js';

const ROLES = {
  customer: { title: 'Customer', sub: 'Find & book trusted professionals near you.', Icon: CustomerIcon },
  professional: { title: 'Service Professional', sub: 'Get nearby jobs & manage your services.', Icon: ProIcon },
};
const PROFESSIONS = ['Electrician', 'Plumber', 'Carpenter', 'House Keeping'];
const EMPTY = { name: '', phone: '', profession: '', email: '', password: '', otp: '' };

export default function AuthModal({ role, onClose }) {
  const open = Boolean(role);
  const [shown, setShown] = useState('customer');     // keeps the text while the modal fades out
  const [f, setF] = useState(EMPTY);
  const [otpSentTo, setOtpSentTo] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [sending, setSending] = useState(false);
  const [checking, setChecking] = useState(false);
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [lockLeft, setLockLeft] = useState(0);        // seconds until login is allowed again (server lockout)
  const [msg, setMsg] = useState({ text: '', kind: '' });
  const dialog = useRef(null);
  const navigate = useNavigate();

  const say = (text, kind = '') => setMsg({ text, kind });
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  /* every time the modal opens: fresh form, scroll lock, focus */
  useEffect(() => {
    if (!role) return undefined;
    setShown(role); setF(EMPTY); setOtpSentTo(''); setOtpVerified(false);
    setCooldown(0); setSending(false); setChecking(false); setBusy(false); setShowPw(false); setLockLeft(0); say('');
    document.body.classList.add('lock');
    const t = setTimeout(() => dialog.current && dialog.current.focus(), 30);
    return () => { clearTimeout(t); document.body.classList.remove('lock'); };
  }, [role]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  /* resend countdown */
  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  /* login-lockout countdown */
  useEffect(() => {
    if (lockLeft <= 0) return undefined;
    const t = setTimeout(() => setLockLeft((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [lockLeft]);

  const isPro = shown === 'professional';
  const registering = otpVerified || f.otp.length > 0 || Boolean(otpSentTo);
  const strength = passwordStrength(f.password, { email: f.email, name: f.name });
  const mmss = (n) => `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`;
  const { title, sub, Icon } = ROLES[shown];

  const onEmail = (e) => {
    const value = e.target.value;
    setF((s) => ({ ...s, email: value }));
    if (otpSentTo && value.trim().toLowerCase() !== otpSentTo) {   // changing the email restarts verification
      setOtpSentTo(''); setOtpVerified(false); setCooldown(0); setF((s) => ({ ...s, email: value, otp: '' })); say('');
    }
  };

  /* Verify / Resend -> backend emails a fresh OTP through the configured email provider */
  const sendOtp = async () => {
    if (sending || otpVerified || cooldown > 0) return;
    const email = f.email.trim().toLowerCase();
    const bad = emailProblem(email);
    if (bad) { say(bad, 'error'); return; }
    setSending(true); say('');
    const r = await api(otpSentTo === email ? 'resend-otp' : 'send-otp', { email });
    setSending(false);
    if (r.ok) {
      setOtpSentTo(email); setF((s) => ({ ...s, otp: '' })); setCooldown(r.data.cooldown || 30);
      say(`We sent a 6-digit code to ${email}. It expires in 5 minutes.`, 'ok');
      return;
    }
    if (r.data.retryAfter) setCooldown(Math.min(r.data.retryAfter, 3600));
    say(r.data.message || 'Something went wrong. Please try again.', 'error');
  };

  /* Check the OTP with the backend (runs automatically on the 6th digit) */
  const checkOtp = async (code) => {
    if (otpVerified) return true;
    if (!otpSentTo) { say('Click Verify first to receive a code by email.', 'error'); return false; }
    if (checking) return false;
    setChecking(true);
    const r = await api('verify-otp', { email: otpSentTo, otp: code });
    setChecking(false);
    if (r.ok) { setOtpVerified(true); say('Email verified. Complete your details and press Login to create your account.', 'ok'); return true; }
    say(r.data.message || 'Could not verify the code. Please try again.', 'error');
    return false;
  };

  const onOtp = (e) => {
    const code = e.target.value.replace(/\D/g, '').slice(0, 6);
    setF((s) => ({ ...s, otp: code }));
    if (code.length === 6) checkOtp(code);
  };

  /* Login button: OTP entered = create account, otherwise = log in */
  const submit = async (e) => {
    e.preventDefault();
    if (busy) return;
    const email = f.email.trim().toLowerCase();
    const bad = emailProblem(email);
    if (bad) return say(bad, 'error');
    if (lockLeft > 0) return;
    const registering = otpVerified || f.otp.length > 0;
    if (registering) {
      if (f.name.trim().length < 2) return say('Please enter your name.', 'error');
      if (f.phone.replace(/\D/g, '').length < 10) return say('Please enter a valid phone number.', 'error');
      const weak = passwordProblem(f.password, { email, name: f.name });
      if (weak) return say(weak, 'error');
      if (isPro && !f.profession) return say('Please select your profession.', 'error');
      if (!otpVerified && f.otp.length !== 6) return say('Enter the 6-digit code we emailed you.', 'error');
      if (otpSentTo && otpSentTo !== email) return say('The email changed. Please verify it again.', 'error');
    }
    setBusy(true); say('');
    let r;
    if (registering) {
      const ok = await checkOtp(f.otp);
      r = ok ? await api('register', { name: f.name.trim(), phone: f.phone.trim(), email, password: f.password, role: shown, profession: f.profession }) : null;
    } else {
      r = await api('login', { email, password: f.password });
    }
    if (r && r.ok) { say(registering ? 'Account created. Redirecting…' : 'Logged in. Redirecting…', 'ok'); navigate(r.data.redirect); return; }
    setBusy(false);
    if (!r) return;
    if (r.status === 429 && r.data.retryAfter && !registering) {          // too many failed logins: show a live countdown
      setLockLeft(Math.min(r.data.retryAfter, 3600));
      say(r.data.message, 'error');
      return;
    }
    if (!registering && r.status === 401) {
      say('Invalid email or password. New to Local Link? Click Verify to get a code and create your account.', 'error');
      return;
    }
    say(r.data.message || 'Something went wrong. Please try again.', 'error');
  };

  const verifyLabel = otpVerified ? 'Verified' : sending ? 'Sending…' : cooldown > 0 ? `Resend in ${cooldown}s` : otpSentTo ? 'Resend' : 'Verify';

  return (
    <div className={`overlay${open ? ' open' : ''}`} aria-hidden={!open} onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="mTitle" tabIndex={-1} ref={dialog}>
        <button className="modal-x" type="button" aria-label="Close" onClick={onClose}>
          <svg viewBox="0 0 16 16"><path d="M3 3l10 10M13 3L3 13" /></svg>
        </button>
        <div className="modal-head">
          <span className="ic"><Icon /></span>
          <div><h3 id="mTitle">{title}</h3><p>{sub}</p></div>
        </div>
        <div className="modal-body">
          <form className="form" autoComplete="on" onSubmit={submit}>
            <div className="field">
              <label htmlFor="fName">Name</label>
              <input id="fName" name="name" type="text" placeholder="Your full name" autoComplete="name" maxLength={80} value={f.name} onChange={set('name')} />
            </div>
            <div className="field" hidden={!isPro}>
              <label htmlFor="fProf">Profession</label>
              <select id="fProf" name="profession" value={f.profession} onChange={set('profession')}>
                <option value="" disabled>Select your profession</option>
                {PROFESSIONS.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            {registering && <div className="field"><label htmlFor="fPhone">Phone number</label><input id="fPhone" name="phone" type="tel" placeholder="10-digit phone number" autoComplete="tel" inputMode="tel" maxLength={20} required value={f.phone} onChange={set('phone')} /></div>}
            <div className="field">
              <label htmlFor="fEmail">Email</label>
              <div className="inbox">
                <input id="fEmail" name="email" type="email" placeholder="you@example.com" autoComplete="email" inputMode="email" autoCapitalize="none" spellCheck={false} maxLength={254} required value={f.email} onChange={onEmail}
                  onBlur={() => { const p = f.email.trim() && emailProblem(f.email); if (p) say(p, 'error'); }} />
                <button className={`vbtn${otpVerified ? ' done' : ''}`} type="button" onClick={sendOtp} disabled={otpVerified || sending || cooldown > 0}>{verifyLabel}</button>
              </div>
            </div>
            <div className="field">
              <label htmlFor="fPass">Password</label>
              <div className="inbox">
                <input id="fPass" name="password" type={showPw ? 'text' : 'password'} placeholder={registering ? 'Create a strong password' : 'Enter your password'}
                  autoComplete={registering ? 'new-password' : 'current-password'} maxLength={128} required value={f.password} onChange={set('password')} />
                <button className="vbtn" type="button" onClick={() => setShowPw((v) => !v)} aria-pressed={showPw} aria-label={showPw ? 'Hide password' : 'Show password'}>{showPw ? 'Hide' : 'Show'}</button>
              </div>
              {registering && f.password && (
                <div className="pw-meter" data-level={strength} aria-live="polite">
                  <span className="bars"><i /><i /><i /><i /></span>
                  <small>{STRENGTH_LABEL[strength]}{passwordProblem(f.password, { email: f.email, name: f.name }) ? ` — ${passwordProblem(f.password, { email: f.email, name: f.name })}` : ''}</small>
                </div>
              )}
            </div>
            <div className="field">
              <label htmlFor="fOtp">OTP</label>
              <input id="fOtp" name="otp" type="text" inputMode="numeric" pattern="[0-9]{6}" maxLength={6} placeholder="Enter OTP" autoComplete="one-time-code" readOnly={otpVerified} value={f.otp} onChange={onOtp} />
            </div>
            <p className="form-msg" role="status" aria-live="polite">{msg.text}</p>
            <button className="btn" type="submit" disabled={busy || lockLeft > 0}>{lockLeft > 0 ? `Try again in ${mmss(lockLeft)}` : busy ? 'Please wait…' : 'Login'}</button>
          </form>
        </div>
      </div>
    </div>
  );
}
