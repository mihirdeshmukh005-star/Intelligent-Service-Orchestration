const steps = [
  ['Discover', 'Find nearby professionals', <><circle cx="11" cy="11" r="7" /><path d="M20 20l-4-4" /></>],
  ['Compare', 'Check ratings, reviews & prices', <path d="M12 4v16M6 20h12M5 7h14M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z" />],
  ['Book', 'Schedule at your convenience', <><rect x="4" y="5" width="16" height="15" rx="2" /><path d="M4 10h16M9 3v4M15 3v4" /></>],
  ['Get it Done', "Relax, we've got you covered", <><circle cx="12" cy="12" r="9" /><path d="M8 12.5l3 3 5-6" /></>],
];

export default function Hero() {
  return (
    <section className="hero">
      <span className="pill">Local Services Made Simple</span>
      <h1>Your local problem.<br />The right professional.<br /><span>One simple booking.</span></h1>
      <p className="sub">Find trusted professionals near you for all your home service needs. Fast, reliable and hassle-free.</p>
      <div className="steps">
        {steps.map(([title, text, icon]) => (
          <div className="step" key={title}>
            <svg viewBox="0 0 24 24">{icon}</svg>
            <b>{title}</b><small>{text}</small>
          </div>
        ))}
      </div>
      <figure className="quote">
        <blockquote>Good service starts with knowing who is coming to your door.</blockquote>
        <figcaption>Our promise at Local Link</figcaption>
      </figure>
    </section>
  );
}
