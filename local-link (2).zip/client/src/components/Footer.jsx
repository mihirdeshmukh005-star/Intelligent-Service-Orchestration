export default function Footer() {
  return (
    <footer>
      <span>© 2026 Local Link. All rights reserved.</span>
      <nav aria-label="Footer navigation">
        <a href="/" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>Home</a>
        <a href="/#about">Trust & About</a>
        <a href="mailto:support@local-link.example">Help</a>
      </nav>
    </footer>
  );
}
