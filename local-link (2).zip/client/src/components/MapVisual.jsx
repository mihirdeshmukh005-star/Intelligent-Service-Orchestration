import { useEffect, useRef, useState } from 'react';
import { Avatar } from './icons.jsx';

const providers = [
  ['p1', 'electrician', 'Electrician', '4.8', '1.2'],
  ['p2', 'plumber', 'Plumber', '4.7', '2.1'],
  ['p3', 'ac', 'AC Technician', '4.6', '3.4'],
];

export default function MapVisual() {
  const mapRef = useRef(null);
  const bgRef = useRef(null);
  const [hl, setHl] = useState(-1); // which provider card is hovered -> highlights its marker

  /* subtle parallax; pauses when the map is off-screen */
  useEffect(() => {
    const map = mapRef.current, bg = bgRef.current;
    if (!map || !bg || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let ticking = false, visible = true;
    const update = () => {
      ticking = false;
      const y = Math.min(window.scrollY, 700);
      map.style.transform = `translate3d(0,${(y * 0.06).toFixed(1)}px,0)`;
      bg.style.transform = `translate3d(0,${(-y * 0.04).toFixed(1)}px,0)`;
    };
    const onScroll = () => { if (visible && !ticking) { ticking = true; requestAnimationFrame(update); } };
    window.addEventListener('scroll', onScroll, { passive: true });
    const io = new IntersectionObserver((e) => { visible = e[0].isIntersecting; map.classList.toggle('paused', !visible); });
    io.observe(map);
    return () => { window.removeEventListener('scroll', onScroll); io.disconnect(); };
  }, []);

  return (
    <aside className="map" ref={mapRef} aria-hidden="true">
      <svg ref={bgRef} className="bg" aria-hidden="true" viewBox="0 0 420 420" fill="none">
      <defs><radialGradient id="fadeG" gradientUnits="userSpaceOnUse" cx="250" cy="100" r="430"><stop offset=".4" stopColor="#fff"/><stop offset="1" stopColor="#fff" stopOpacity="0"/></radialGradient><mask id="fadeM" maskUnits="userSpaceOnUse" x="-600" y="-400" width="1600" height="1200"><rect x="-600" y="-400" width="1600" height="1200" fill="url(#fadeG)"/></mask></defs>
      <g mask="url(#fadeM)"><g fill="#e3ece6" opacity=".7"><rect x="-30" y="-40" width="72" height="52" rx="6"/><rect x="262" y="-96" width="92" height="58" rx="6"/><rect x="298" y="318" width="66" height="48" rx="6"/><rect x="-120" y="170" width="60" height="50" rx="6"/></g><g stroke="#e3e9f2" strokeLinecap="round"><path d="M-520 -102.9L940 -207.1" strokeWidth="10"/><path d="M-520 27.1L940 -77.1" strokeWidth="6"/><path d="M-520 157.1L940 52.9" strokeWidth="10"/><path d="M-520 287.1L940 182.9" strokeWidth="6"/><path d="M-520 397.1L940 292.9" strokeWidth="10"/><path d="M-520 527.1L940 422.9" strokeWidth="6"/><path d="M-520 657.1L940 552.9" strokeWidth="10"/><path d="M-432.9 -300L-287.1 720" strokeWidth="10"/><path d="M-282.9 -300L-137.1 720" strokeWidth="6"/><path d="M-132.9 -300L12.9 720" strokeWidth="10"/><path d="M17.1 -300L162.9 720" strokeWidth="6"/><path d="M167.1 -300L312.9 720" strokeWidth="10"/><path d="M317.1 -300L462.9 720" strokeWidth="6"/><path d="M467.1 -300L612.9 720" strokeWidth="10"/><path d="M617.1 -300L762.9 720" strokeWidth="6"/><path d="M767.1 -300L912.9 720" strokeWidth="10"/></g></g>
      
      <rect x="150" y="60" width="64" height="48" rx="6" fill="#e3ece6" opacity=".7"/>
      <rect x="30" y="290" width="50" height="46" rx="6" fill="#e3ece6" opacity=".7"/>
      <g stroke="#e3e9f2" strokeWidth="10" strokeLinecap="round"><path d="M0 120L420 90"/><path d="M0 250L420 220"/><path d="M60 0L120 420"/><path d="M210 0L260 420"/><path d="M0 360L420 330"/></g>
      <path d="M96 196C140 240 140 280 170 292" stroke="#2563eb" strokeWidth="1.6" className="rt" strokeDasharray="4 5" opacity=".7"/>
      <path d="M96 196C170 150 220 150 262 118" stroke="#2563eb" strokeWidth="1.6" className="rt" strokeDasharray="4 5" opacity=".5"/>
      <circle className={"dt" + (hl === 0 ? " hl" : "")} style={{animationDelay:'1.4s'}} cx="262" cy="118" r="5" fill="#fff" stroke="#2563eb" strokeWidth="2"/>
      <circle className={"dt" + (hl === 2 ? " hl" : "")} style={{animationDelay:'1.7s'}} cx="170" cy="292" r="5" fill="#fff" stroke="#2563eb" strokeWidth="2"/>
      <circle cx="96" cy="196" r="22" fill="#2563eb" opacity=".1"/>
      <circle className="rt" cx="96" cy="196" r="78" stroke="#2563eb" strokeWidth="1" opacity=".14"/>
      <path className="rt" d="M96 196C150 222 180 234 214 236" stroke="#2563eb" strokeWidth="1.6" strokeDasharray="4 5" opacity=".6"/>
      <circle className={"dt" + (hl === 1 ? " hl" : "")} style={{animationDelay:'1.55s'}} cx="214" cy="236" r="5" fill="#fff" stroke="#2563eb" strokeWidth="2"/>
      <g fill="#bcd2fb" stroke="#2563eb" strokeWidth="1.2"><circle className="sm" style={{animationDelay:'2s'}} cx="52" cy="128" r="3.500"/><circle className="sm" style={{animationDelay:'2.2s'}} cx="168" cy="170" r="3.500"/><circle className="sm" style={{animationDelay:'2.4s'}} cx="40" cy="270" r="3.500"/><circle className="sm" style={{animationDelay:'2.6s'}} cx="220" cy="64" r="3.500"/></g>
      <g className="chip" style={{animationDelay:'1.1s'}}><rect x="114" y="183" width="86" height="22" rx="11" fill="#fff" stroke="#e3e9f2"/><text x="157" y="198" textAnchor="middle" fontFamily="Inter,system-ui,sans-serif" fontSize="10.500" fontWeight="600" fill="#0f1f3d">Your location</text></g>
      <g className="chip" style={{animationDelay:'1.6s'}}><rect x="164" y="132" width="46" height="20" rx="10" fill="#2563eb"/><text x="187" y="146" textAnchor="middle" fontFamily="Inter,system-ui,sans-serif" fontSize="10" fontWeight="600" fill="#fff">8 min</text></g>
      <g className="pin"><path d="M96 218s-12-10.5-12-20a12 12 0 1 1 24 0c0 9.500-12 20-12 20z" fill="#2563eb"/><circle cx="96" cy="198" r="4.500" fill="#fff"/></g>
    </svg>
      {providers.map(([cls, who, name, rating, km], i) => (
        <div key={cls} aria-hidden="true" className={`pro ${cls}`} onMouseEnter={() => setHl(i)} onMouseLeave={() => setHl(-1)}>
          <Avatar who={who} />
          <div><b>{name}</b><small><i>{rating} ★</i> · {km} km</small></div>
        </div>
      ))}
      <div aria-hidden="true" className="pro p0">
        <span className="ck"><svg viewBox="0 0 24 24"><path d="M6 12.5l4 4 8-9" /></svg></span>
        <div><b>Booking confirmed</b><small>Electrician · arrives in 8 min</small></div>
      </div>
    </aside>
  );
}
