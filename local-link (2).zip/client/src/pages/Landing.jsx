import { useRef, useState } from 'react';
import { Logo } from '../components/icons.jsx';
import Hero from '../components/Hero.jsx';
import RoleCard from '../components/RoleCard.jsx';
import MapVisual from '../components/MapVisual.jsx';
import Sections from '../components/Sections.jsx';
import Footer from '../components/Footer.jsx';
import AuthModal from '../components/AuthModal.jsx';
import useReveal from '../hooks/useReveal.js';

export default function Landing() {
  const [role, setRole] = useState(null);      // 'customer' | 'professional' | null (modal closed)
  const trigger = useRef(null);
  useReveal();

  const open = (key) => { trigger.current = document.activeElement; setRole(key); };
  const close = () => { setRole(null); if (trigger.current && trigger.current.focus) trigger.current.focus(); };

  return (
    <>
      <header><Logo /></header>
      <main>
        <Hero />
        <RoleCard onSelect={open} />
        <MapVisual />
      </main>
      <Sections onSelect={open} />
      <Footer />
      <AuthModal role={role} onClose={close} />
    </>
  );
}
