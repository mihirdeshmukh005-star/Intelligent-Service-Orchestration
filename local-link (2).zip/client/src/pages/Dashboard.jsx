import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Logo } from '../components/icons.jsx';
import { api } from '../api.js';

export default function Dashboard({ role }) {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    let alive = true;
    api('me').then((r) => {
      if (!alive) return;
      if (!r.ok) return navigate('/', { replace: true });
      if (r.data.user.role !== role) return navigate(r.data.redirect, { replace: true }); // wrong dashboard -> right one
      // Hand over to the right app: customers -> customer app, professionals -> assessment (it forwards to the worker app once passed).
      window.location.replace(role === 'PROFESSIONAL' ? '/assessment/' : '/customer/');
      setUser(r.data.user);
    });
    return () => { alive = false; };
  }, [role, navigate]);

  const logout = async () => { await api('logout', {}); navigate('/', { replace: true }); };
  const logoutAll = async () => { await api('logout-all', {}); navigate('/', { replace: true }); };

  if (!user) return <header><Logo /></header>;
  const isPro = user.role === 'PROFESSIONAL';
  const last = user.lastLogin ? new Date(user.lastLogin).toLocaleString() : '—';

  return (
    <>
      <header>
        <Logo />
        <div className="dash-user">
          <span>{user.name}</span>
          <button className="btn sm" type="button" onClick={logout}>Log out</button>
        </div>
      </header>
      <main className="dash-main" style={{ display: 'block' }}>
        <span className="pill">{isPro ? 'Service Professional' : 'Customer'}</span>
        <h1 style={{ marginTop: 16 }}>Welcome, {user.name}</h1>
        <p className="sub">{isPro
          ? 'You are logged in to your Service Professional dashboard.'
          : 'You are logged in to your Customer dashboard.'}</p>
        <dl className="dash-card">
          <div><dt>Email</dt><dd>{user.email}</dd></div>
          <div><dt>Account type</dt><dd>{isPro ? 'Service Professional' : 'Customer'}</dd></div>
          {isPro && <div><dt>Profession</dt><dd>{user.profession}</dd></div>}
          <div><dt>Last login</dt><dd>{last}</dd></div>
        </dl>
        <p className="sub" style={{ marginTop: 20, fontSize: 13 }}>
          Using a shared or lost device?{' '}
          <button type="button" className="linkbtn" onClick={logoutAll}>Log out of all devices</button>
        </p>
      </main>
    </>
  );
}
