// Client-side checks give instant feedback. The server repeats every check; never rely on these alone.
const LOCAL_RE = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
const LABEL_RE = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
const TLD_RE = /^(?:[a-z]{2,24}|xn--[a-z0-9-]{2,59})$/;

/** Returns a human message when the email is not valid, or '' when it looks genuine. */
export function emailProblem(raw) {
  const email = String(raw || '').trim().toLowerCase();
  if (!email) return 'Please enter your email address.';
  if (email.length > 254 || !/^[\x21-\x7e]+$/.test(email)) return 'Please enter a valid email address (letters, numbers and normal symbols only).';
  const parts = email.split('@');
  if (parts.length < 2) return 'Your email is missing the "@" symbol.';
  if (parts.length > 2) return 'An email address can contain only one "@".';
  const [local, domain] = parts;
  if (!local || local.length > 64 || !LOCAL_RE.test(local)) return 'The part before "@" in your email is not valid.';
  const labels = domain.split('.');
  if (!domain) return 'Your email is missing the domain after "@" (like gmail.com).';
  if (labels.length < 2 || !labels.every((l) => LABEL_RE.test(l))) return 'The domain after "@" is not valid (it should look like gmail.com).';
  if (!TLD_RE.test(labels[labels.length - 1])) return 'The domain ending (like .com) is not valid.';
  return '';
}

const COMMON = /(password|qwerty|letmein|iloveyou|12345678|abcdefg)/i;

/** First problem with a new password, or ''. Mirrors the server policy (length, letter+number, not common, not your own details). */
export function passwordProblem(pw, { email = '', name = '' } = {}) {
  if (pw.length < 10) return 'Use at least 10 characters.';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Include at least one letter and one number.';
  if (/^(.)\1+$/.test(pw) || COMMON.test(pw)) return 'That password is too common. Pick something less guessable.';
  const lower = pw.toLowerCase();
  const local = email.split('@')[0].toLowerCase();
  if (local.length >= 4 && lower.includes(local)) return 'Don\'t include your email name in your password.';
  if (name.toLowerCase().split(/\s+/).some((p) => p.length >= 4 && lower.includes(p))) return 'Don\'t include your name in your password.';
  return '';
}

/** 0-4 strength for the meter. */
export function passwordStrength(pw, ctx) {
  if (!pw) return 0;
  if (passwordProblem(pw, ctx)) return 1;
  let s = 2;
  if (pw.length >= 14) s += 1;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw) && /[^A-Za-z0-9]/.test(pw)) s += 1;
  else if (pw.length >= 18) s += 1;
  return Math.min(4, s);
}
export const STRENGTH_LABEL = ['', 'Weak', 'Okay', 'Good', 'Strong'];
