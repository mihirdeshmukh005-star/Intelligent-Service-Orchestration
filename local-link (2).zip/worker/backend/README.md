# Local Link Worker API

The worker API is the professional-side service behind `/worker/`.

- PostgreSQL only for active persistence.
- Requests are read from the shared customer `requests` table so customer booking and worker acceptance operate on the same record.
- Accepting one request atomically auto-rejects other pending requests for that worker.
- Exact coordinates are hidden from request-list responses and disclosed only on accepted requests / confirmation email.
- Completed work and customer review metrics are stored per worker.
- Weekly analysis is generated from PostgreSQL worker feedback data.

Internal service port: `5003`.

The public application is served through `http://localhost:3000/worker/`.
