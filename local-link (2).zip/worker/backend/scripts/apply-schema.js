import 'dotenv/config';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from '../src/config/db.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
try{
  const sql=await fs.readFile(path.join(root,'sql/schema.sql'),'utf8');
  await pool.query(sql);
  console.log('PostgreSQL schema created/updated.');
}finally{await pool.end();}
