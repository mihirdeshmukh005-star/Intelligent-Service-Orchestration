-- Local Link Worker PostgreSQL storage
-- This schema preserves the existing worker backend API/data model.
-- user_id is nullable for now so this backend can later be linked to the
-- central Login users table without changing the worker API.

CREATE TABLE IF NOT EXISTS worker_profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT UNIQUE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'worker',
  services JSONB NOT NULL DEFAULT '[]'::jsonb,
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  assessment_passed BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_login_at TIMESTAMPTZ,
  base_rating NUMERIC(4,2) NOT NULL DEFAULT 0,
  jobs_completed INTEGER NOT NULL DEFAULT 0,
  total_feedback INTEGER NOT NULL DEFAULT 0,
  response_rate NUMERIC(5,3) NOT NULL DEFAULT 0,
  on_time_rate NUMERIC(5,3) NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS worker_refresh_tokens (
  jti TEXT PRIMARY KEY,
  worker_id TEXT NOT NULL REFERENCES worker_profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  revoked BOOLEAN NOT NULL DEFAULT FALSE,
  revoked_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS worker_requests (
  id TEXT PRIMARY KEY,
  worker_id TEXT NOT NULL REFERENCES worker_profiles(id) ON DELETE CASCADE,
  customer TEXT NOT NULL,
  customer_email TEXT,
  service TEXT NOT NULL,
  area TEXT,
  time_slot TEXT,
  distance_km NUMERIC(10,2) DEFAULT 0,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  accepted_at TIMESTAMPTZ,
  rejected_at TIMESTAMPTZ,
  rejection_reason TEXT,
  completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_worker_requests_worker_status
  ON worker_requests(worker_id,status);

CREATE TABLE IF NOT EXISTS worker_assessments (
  id TEXT PRIMARY KEY,
  worker_id TEXT NOT NULL REFERENCES worker_profiles(id) ON DELETE CASCADE,
  profession TEXT NOT NULL,
  score NUMERIC NOT NULL,
  total NUMERIC NOT NULL DEFAULT 20,
  passed BOOLEAN NOT NULL,
  auto_submitted BOOLEAN NOT NULL DEFAULT FALSE,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_worker_assessments_worker
  ON worker_assessments(worker_id,submitted_at DESC);

CREATE TABLE IF NOT EXISTS worker_feedback (
  id TEXT PRIMARY KEY,
  worker_id TEXT NOT NULL REFERENCES worker_profiles(id) ON DELETE CASCADE,
  request_id TEXT,
  date DATE NOT NULL,
  stars NUMERIC(3,1),
  arrival_minutes_early NUMERIC,
  job_completed BOOLEAN NOT NULL DEFAULT TRUE,
  professionalism NUMERIC(3,1),
  safety NUMERIC(3,1),
  comment TEXT,
  calculated_rating NUMERIC(4,2)
);

CREATE INDEX IF NOT EXISTS idx_worker_feedback_worker_date
  ON worker_feedback(worker_id,date);

CREATE TABLE IF NOT EXISTS worker_daily_metrics (
  worker_id TEXT NOT NULL REFERENCES worker_profiles(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  visits INTEGER NOT NULL DEFAULT 0,
  feedback_count INTEGER NOT NULL DEFAULT 0,
  rating_total NUMERIC(10,2) NOT NULL DEFAULT 0,
  on_time_count INTEGER NOT NULL DEFAULT 0,
  completion_count INTEGER NOT NULL DEFAULT 0,
  average_rating NUMERIC(4,2),
  on_time_rate NUMERIC(5,3),
  completion_rate NUMERIC(5,3),
  PRIMARY KEY(worker_id,date)
);
