import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { env } from './config/env.js';
import { pool } from './config/db.js';
import { apiLimiter } from './middleware/rateLimit.js';
import { notFound,errorHandler } from './middleware/errorHandler.js';
import routes from './routes/index.js';

const app=express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({origin:env.corsOrigin.split(',').map(x=>x.trim()),credentials:false}));
app.use(express.json({limit:'32kb'}));
app.use(apiLimiter);
app.get('/api/health',async(req,res,next)=>{
  try { await pool.query('SELECT 1'); res.json({ok:true,service:'local-link-worker-backend',database:'postgresql',time:new Date().toISOString()}); }
  catch(e){ next(e); }
});
app.use('/api',routes);
app.use(notFound);
app.use(errorHandler);

app.listen(env.port,()=>console.log(`Local Link Worker API listening on http://localhost:${env.port}`));
