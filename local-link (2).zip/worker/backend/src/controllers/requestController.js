import { query, transaction } from '../config/db.js';
import { sendBookingEmail, sendRejectionEmail } from '../services/emailService.js';
import { parseSlot } from '../utils/slots.js';

const base=`SELECT r.*,c.name customer_name,c.email customer_email,c.phone customer_phone
            FROM requests r JOIN customers c ON c.id=r.customer_id`;

function map(r,full=false){
  return {
    id:r.id, workerId:r.worker_id, customer:r.customer_name, customerEmail:r.customer_email,
    customerPhone:r.customer_phone, service:r.profession, area:full ? r.location_label : 'Customer area',
    timeSlot:r.slot, distanceKm:Number(r.distance_km||0), note:r.problem, status:r.status,
    createdAt:r.created_at, updatedAt:r.updated_at, startedAt:r.started_at || null,
    occupiedUntilMinutes:r.occupied_until_minutes == null ? null : Number(r.occupied_until_minutes),
    extensionReason:r.extension_reason || null,
    location:full?{lat:Number(r.lat),lng:Number(r.lng),label:r.location_label}:undefined
  };
}

function overlap(slotA, occupiedUntilMinutes, slotB){
  const a=parseSlot(slotA), b=parseSlot(slotB);
  if(!a || !b) return false;
  const endA=Math.max(a.end, Number(occupiedUntilMinutes)||a.end);
  return b.start < endA && b.end > a.start;
}
function intervalOverlaps(startMinutes,endMinutes,slot){
  const b=parseSlot(slot);
  return !!b && b.start < endMinutes && b.end > startMinutes;
}

async function rejectOverlappingPending(db, workerId, occupiedSlot, occupiedUntil, excludeId, reason){
  const {rows}=await db.query(
    `SELECT id,slot FROM requests WHERE worker_id=$1 AND status='pending' AND id<>$2 FOR UPDATE`,
    [workerId,excludeId]
  );
  const ids=rows.filter(r=>overlap(occupiedSlot,occupiedUntil,r.slot)).map(r=>r.id);
  if(!ids.length) return [];
  await db.query(
    `UPDATE requests SET status='auto-rejected',rejection_reason=$3,updated_at=NOW()
     WHERE worker_id=$1 AND id=ANY($2::text[])`,
    [workerId,ids,reason]
  );
  return ids;
}

export async function listRequests(req,res,next){
  try{
    const {rows}=await query(`${base}
      WHERE r.worker_id=$1
      ORDER BY CASE WHEN r.status='pending' THEN 0 WHEN r.status='in_progress' THEN 1 WHEN r.status='accepted' THEN 2 ELSE 3 END,
               r.slot,r.created_at DESC`,[req.auth.sub]);
    res.json({ok:true,data:rows.map(x=>map(x,false))});
  }catch(e){next(e)}
}

export async function getRequest(req,res,next){
  try{
    const {rows}=await query(`${base} WHERE r.id=$1 AND r.worker_id=$2`,[req.params.id,req.auth.sub]);
    if(!rows[0])return res.status(404).json({ok:false,error:'Request not found'});
    res.json({ok:true,data:map(rows[0],['accepted','in_progress','completed'].includes(rows[0].status))});
  }catch(e){next(e)}
}

export async function acceptRequest(req,res,next){
  try{
    const out=await transaction(async c=>{
      // Lock the canonical worker row so concurrent accepts/extension operations serialize.
      const lock=(await c.query(`SELECT id FROM workers WHERE id=$1 FOR UPDATE`,[req.auth.sub])).rows[0];
      if(!lock)throw Object.assign(new Error('Worker profile not found'),{status:404});

      const t=(await c.query(`${base} WHERE r.id=$1 AND r.worker_id=$2 FOR UPDATE`,[req.params.id,req.auth.sub])).rows[0];
      if(!t)throw Object.assign(new Error('Request not found'),{status:404});
      if(t.status!=='pending')throw Object.assign(new Error(`Request is already ${t.status}`),{status:409});
      const targetSlot=parseSlot(t.slot);
      if(!targetSlot)throw Object.assign(new Error('Invalid booking time slot'),{status:400});

      const active=(await c.query(
        `SELECT id,slot,occupied_until_minutes,status FROM requests
         WHERE worker_id=$1 AND status IN ('accepted','in_progress') AND id<>$2 FOR UPDATE`,
        [req.auth.sub,t.id]
      )).rows;
      const conflict=active.find(r=>overlap(r.slot,r.occupied_until_minutes,t.slot));
      if(conflict){
        throw Object.assign(new Error(`This booking overlaps an active ${conflict.slot} booking. The customer should choose another time or professional.`),{status:409});
      }

      const occupiedUntil=targetSlot.end;
      const chosen=(await c.query(
        `UPDATE requests
         SET status='accepted',occupied_until_minutes=$2,updated_at=NOW()
         WHERE id=$1 RETURNING *`,
        [t.id,occupiedUntil]
      )).rows[0];

      const rejected=await rejectOverlappingPending(
        c,req.auth.sub,t.slot,occupiedUntil,t.id,
        'Another booking was accepted for an overlapping time slot.'
      );
      return {target:map({...t,...chosen},true),rejected};
    });

    const worker=(await query('SELECT * FROM workers WHERE id=$1',[req.auth.sub])).rows[0];
    const customer=(await query('SELECT * FROM customers WHERE id=(SELECT customer_id FROM requests WHERE id=$1)',[out.target.id])).rows[0];
    let email;
    try{
      email=await sendBookingEmail({
        request:out.target,worker:{name:worker.name,email:worker.email},
        customerEmail:customer.email,customer
      });
    }catch(e){
      console.error('Booking email delivery failed:',e.message);
      email={emailSent:false,error:'Booking accepted, but confirmation email delivery failed. Check Resend/SMTP configuration.'};
    }
    for(const id of out.rejected){
      const r=(await query(`${base} WHERE r.id=$1`,[id])).rows[0];
      if(r)sendRejectionEmail({
        request:map(r,true),
        customer:{name:r.customer_name,email:r.customer_email},
        reason:'The professional is now unavailable for your selected time slot.'
      }).catch(e=>console.error(e.message));
    }
    res.json({
      ok:true,
      data:{
        request:out.target,email,autoRejectedRequestIds:out.rejected,
        message:'Request accepted. Only overlapping pending requests were automatically rejected.'
      }
    });
  }catch(e){next(e)}
}

export async function rejectRequest(req,res,next){
  try{
    const out=await transaction(async c=>{
      const r=(await c.query(`${base} WHERE r.id=$1 AND r.worker_id=$2 FOR UPDATE`,[req.params.id,req.auth.sub])).rows[0];
      if(!r)return null;
      if(r.status!=='pending')throw Object.assign(new Error(`Request is already ${r.status}`),{status:409});
      const u=(await c.query(`UPDATE requests SET status='rejected',updated_at=NOW() WHERE id=$1 RETURNING *`,[r.id])).rows[0];
      return map({...r,...u},true)
    });
    if(!out)return res.status(404).json({ok:false,error:'Request not found'});
    const customer=(await query('SELECT * FROM customers WHERE id=(SELECT customer_id FROM requests WHERE id=$1)',[out.id])).rows[0];
    let email;
    try{email=await sendRejectionEmail({request:out,customer});}catch(e){email={emailSent:false,error:e.message}}
    res.json({ok:true,data:{request:out,email},message:'Request rejected. Customer can book another professional.'});
  }catch(e){next(e)}
}

export async function startRequest(req,res,next){
  try{
    const changed=await transaction(async c=>{
      const lock=(await c.query(`SELECT id FROM workers WHERE id=$1 FOR UPDATE`,[req.auth.sub])).rows[0];
      if(!lock)throw Object.assign(new Error('Worker profile not found'),{status:404});
      const {rows}=await c.query(
        `UPDATE requests SET status='in_progress',started_at=COALESCE(started_at,NOW()),updated_at=NOW()
         WHERE id=$1 AND worker_id=$2 AND status='accepted' RETURNING *`,
        [req.params.id,req.auth.sub]
      );
      if(!rows[0])throw Object.assign(new Error('Only an accepted request can be started'),{status:409});
      return rows[0];
    });
    res.json({ok:true,data:{request:map(changed,true),message:'Job is now in progress. Request more time before the reserved slot ends if needed.'}});
  }catch(e){next(e)}
}

export async function extendRequest(req,res,next){
  try{
    const additional=Math.round(Number(req.body?.additionalMinutes));
    const reason=String(req.body?.reason||'Work requires additional time.').trim().slice(0,500);
    if(!Number.isInteger(additional)||additional<15||additional>240){
      return res.status(400).json({ok:false,error:'additionalMinutes must be a whole number from 15 to 240.'});
    }
    const out=await transaction(async c=>{
      const lock=(await c.query(`SELECT id FROM workers WHERE id=$1 FOR UPDATE`,[req.auth.sub])).rows[0];
      if(!lock)throw Object.assign(new Error('Worker profile not found'),{status:404});
      const current=(await c.query(`${base} WHERE r.id=$1 AND r.worker_id=$2 FOR UPDATE`,[req.params.id,req.auth.sub])).rows[0];
      if(!current)throw Object.assign(new Error('Request not found'),{status:404});
      if(!['accepted','in_progress'].includes(current.status)){
        throw Object.assign(new Error('Only an accepted or in-progress job can request more time'),{status:409});
      }
      const slot=parseSlot(current.slot);
      if(!slot)throw Object.assign(new Error('Invalid booking time slot'),{status:400});
      const currentUntil=Math.max(slot.end,Number(current.occupied_until_minutes)||slot.end);
      const newUntil=currentUntil+additional;

      const future=(await c.query(
        `SELECT id,slot,occupied_until_minutes,status FROM requests
         WHERE worker_id=$1 AND status IN ('accepted','in_progress') AND id<>$2 FOR UPDATE`,
        [req.auth.sub,current.id]
      )).rows;
      const conflict=future.find(r=>intervalOverlaps(currentUntil,newUntil,r.slot));
      if(conflict){
        throw Object.assign(new Error(`Cannot extend this job because another active booking occupies ${conflict.slot}.`),{status:409});
      }

      const updated=(await c.query(
        `UPDATE requests SET status='in_progress',occupied_until_minutes=$2,extension_reason=$3,started_at=COALESCE(started_at,NOW()),updated_at=NOW()
         WHERE id=$1 RETURNING *`,
        [current.id,newUntil,reason]
      )).rows[0];

      const pending=(await c.query(
        `SELECT id,slot FROM requests WHERE worker_id=$1 AND status='pending' AND id<>$2 FOR UPDATE`,
        [req.auth.sub,current.id]
      )).rows;
      const ids=pending.filter(r=>overlap(current.slot,newUntil,r.slot)).map(r=>r.id);
      if(ids.length){
        await c.query(
          `UPDATE requests SET status='auto-rejected',rejection_reason='The professional requested more time on an active job.',updated_at=NOW()
           WHERE worker_id=$1 AND id=ANY($2::text[])`,
          [req.auth.sub,ids]
        );
      }
      return {updated,ids};
    });

    for(const id of out.ids){
      const r=(await query(`${base} WHERE r.id=$1`,[id])).rows[0];
      if(r)sendRejectionEmail({
        request:map(r,true),
        customer:{name:r.customer_name,email:r.customer_email},
        reason:'The professional needs more time to finish an existing job. Please choose another available professional.'
      }).catch(e=>console.error(e.message));
    }
    res.json({
      ok:true,data:{
        request:map(out.updated,true),autoRejectedRequestIds:out.ids,
        message:'Additional time recorded. Overlapping future requests are blocked.'
      }
    });
  }catch(e){next(e)}
}

export async function completeRequest(req,res,next){
  try{
    const {rows}=await query(
      `UPDATE requests SET status='completed',updated_at=NOW()
       WHERE id=$1 AND worker_id=$2 AND status IN ('accepted','in_progress') RETURNING *`,
      [req.params.id,req.auth.sub]
    );
    if(!rows[0])return res.status(409).json({ok:false,error:'Only an accepted or in-progress request can be completed'});
    await query('UPDATE workers SET jobs_completed=jobs_completed+1,completion_rate=LEAST(100,completion_rate+0.5),updated_at=NOW() WHERE id=$1',[req.auth.sub]);
    await query('UPDATE worker_profiles SET jobs_completed=jobs_completed+1,updated_at=NOW() WHERE id=$1',[req.auth.sub]);
    res.json({ok:true,data:{request:map(rows[0],true)}});
  }catch(e){next(e)}
}
