import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { query, transaction } from '../config/db.js';
import { signAccess, signRefresh, verifyRefresh, newJti } from '../utils/jwt.js';

function publicWorker(w){
  return {
    id:w.id,name:w.name,email:w.email,role:w.role,services:w.services || [],
    verified:w.verified,assessmentPassed:w.assessment_passed,active:w.active,
    createdAt:w.created_at,lastLoginAt:w.last_login_at,
    metrics:{
      baseRating:Number(w.base_rating ?? 0),
      jobsCompleted:Number(w.jobs_completed ?? 0),
      totalFeedback:Number(w.total_feedback ?? 0),
      responseRate:Number(w.response_rate ?? 0),
      onTimeRate:Number(w.on_time_rate ?? 0)
    }
  };
}

async function findWorker(id){
  const {rows}=await query('SELECT * FROM worker_profiles WHERE id=$1 AND active=true LIMIT 1',[id]);
  return rows[0];
}

export async function login(req,res,next){try{
  const {email,password}=req.body||{};
  if(typeof email!=='string'||typeof password!=='string') return res.status(400).json({ok:false,error:'Email and password are required'});
  const {rows}=await query('SELECT * FROM worker_profiles WHERE LOWER(email)=LOWER($1) AND active=true LIMIT 1',[email]);
  const worker=rows[0];
  if(!worker || !(await bcrypt.compare(password,worker.password_hash))) return res.status(401).json({ok:false,error:'Invalid credentials'});
  const now=new Date().toISOString();
  await query('UPDATE worker_profiles SET last_login_at=$1, updated_at=NOW() WHERE id=$2',[now,worker.id]);
  const jti=newJti(), accessToken=signAccess({...worker,id:worker.id,role:worker.role}), refreshToken=signRefresh({...worker,id:worker.id,role:worker.role},jti);
  await query('INSERT INTO worker_refresh_tokens(jti,worker_id,created_at,revoked) VALUES($1,$2,NOW(),false)',[jti,worker.id]);
  worker.last_login_at=now;
  res.json({ok:true,data:{worker:publicWorker(worker),accessToken,refreshToken,accessScope:worker.verified&&worker.assessment_passed?'professional':'assessment-only'}});
}catch(e){next(e)}}

export async function refresh(req,res,next){try{
  const {refreshToken}=req.body||{}; if(!refreshToken)return res.status(400).json({ok:false,error:'refreshToken is required'});
  const payload=verifyRefresh(refreshToken); if(payload.type!=='refresh')throw new Error('bad token');
  const {rows:tokens}=await query('SELECT * FROM worker_refresh_tokens WHERE jti=$1 AND worker_id=$2 AND revoked=false LIMIT 1',[payload.jti,payload.sub]);
  if(!tokens[0])return res.status(401).json({ok:false,error:'Refresh token revoked or invalid'});
  const worker=await findWorker(payload.sub); if(!worker)return res.status(403).json({ok:false,error:'Worker account is inactive'});
  await query('UPDATE worker_refresh_tokens SET revoked=true, revoked_at=NOW() WHERE jti=$1',[payload.jti]);
  const jti=newJti();
  const accessToken=signAccess(worker), newRefreshToken=signRefresh(worker,jti);
  await query('INSERT INTO worker_refresh_tokens(jti,worker_id,created_at,revoked) VALUES($1,$2,NOW(),false)',[jti,worker.id]);
  res.json({ok:true,data:{accessToken,refreshToken:newRefreshToken,accessScope:worker.verified&&worker.assessment_passed?'professional':'assessment-only'}});
}catch(e){return res.status(401).json({ok:false,error:'Invalid refresh token'})}}

export async function logout(req,res,next){try{
  const {refreshToken}=req.body||{};
  if(refreshToken){try{const p=verifyRefresh(refreshToken);await query('UPDATE worker_refresh_tokens SET revoked=true, revoked_at=NOW() WHERE jti=$1',[p.jti]);}catch{}}
  res.json({ok:true,message:'Signed out'});
}catch(e){next(e)}}

export async function me(req,res,next){try{
  const w=await findWorker(req.auth.sub); if(!w)return res.status(404).json({ok:false,error:'Worker not found'});
  res.json({ok:true,data:publicWorker(w)});
}catch(e){next(e)}}

export async function register(req,res,next){try{
 const {name,email,password,services=[]}=req.body||{};
 if(!name||!email||!password)return res.status(400).json({ok:false,error:'name, email and password are required'});
 if(password.length<8)return res.status(400).json({ok:false,error:'Password must be at least 8 characters'});
 const {rows:existing}=await query('SELECT id FROM worker_profiles WHERE LOWER(email)=LOWER($1) LIMIT 1',[email]);
 if(existing[0])return res.status(409).json({ok:false,error:'Worker already exists'});
 const worker={id:`wrk_${crypto.randomUUID()}`,name,email,passwordHash:await bcrypt.hash(password,12),role:'worker',services,verified:false,assessmentPassed:false,active:true,createdAt:new Date().toISOString()};
 await query(
  `INSERT INTO worker_profiles
   (id,name,email,password_hash,role,services,verified,assessment_passed,active,created_at,last_login_at,base_rating,jobs_completed,total_feedback,response_rate,on_time_rate)
   VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,NULL,0,0,0,0,0)`,
  [worker.id,worker.name,worker.email,worker.passwordHash,worker.role,JSON.stringify(worker.services),false,false,true,worker.createdAt]
 );
 res.status(201).json({ok:true,data:{id:worker.id,email:worker.email,verified:false,assessmentPassed:false},message:'Registration created. Authority verification and assessment must be completed before access.'});
}catch(e){next(e)}}
