import { query, transaction } from '../config/db.js';

function mapAssessment(r){return {id:r.id,workerId:r.worker_id,profession:r.profession,score:r.score,total:r.total,passed:r.passed,autoSubmitted:r.auto_submitted,submittedAt:r.submitted_at};}

export async function submitAssessment(req,res,next){try{
 const {profession,score,total=20,autoSubmitted=false}=req.body||{};
 if(!profession||typeof score!=='number')return res.status(400).json({ok:false,error:'profession and numeric score are required'});
 const passed=score/total>=0.6;
 const id=`ass_${Date.now()}`;
 const rec=await transaction(async client=>{
   const {rows}=await client.query(
    `INSERT INTO worker_assessments(id,worker_id,profession,score,total,passed,auto_submitted,submitted_at)
     VALUES($1,$2,$3,$4,$5,$6,$7,NOW()) RETURNING *`,
    [id,req.auth.sub,profession,score,total,passed,autoSubmitted]
   );
   if(passed)await client.query('UPDATE worker_profiles SET assessment_passed=true,updated_at=NOW() WHERE id=$1',[req.auth.sub]);
   return rows[0];
 });
 res.json({ok:true,data:mapAssessment(rec),message:passed?'Assessment passed.':'Assessment not passed.'});
}catch(e){next(e)}}

export async function assessmentHistory(req,res,next){try{
 const {rows}=await query('SELECT * FROM worker_assessments WHERE worker_id=$1 ORDER BY submitted_at DESC',[req.auth.sub]);
 res.json({ok:true,data:rows.map(mapAssessment)});
}catch(e){next(e)}}
