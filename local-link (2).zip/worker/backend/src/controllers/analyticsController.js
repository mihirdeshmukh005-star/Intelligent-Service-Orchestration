import { query } from '../config/db.js';
import { rebuildDailyMetrics } from '../services/ratingService.js';

export async function weeklySummary(req,res,next){try{
  const rows=await rebuildDailyMetrics(req.auth.sub);
  const now=new Date(),start=new Date(now);start.setDate(now.getDate()-6);
  const days=[];for(let i=0;i<7;i++){const d=new Date(start);d.setDate(start.getDate()+i);days.push(d.toISOString().slice(0,10));}
  const data=days.map(date=>rows.find(x=>String(x.date).slice(0,10)===date)||{date,visits:0,feedbackCount:0,averageRating:null,onTimeRate:null,completionRate:null});
  const {rows:feedback}=await query('SELECT calculated_rating FROM worker_feedback WHERE worker_id=$1 AND date = ANY($2::date[])',[req.auth.sub,days]);
  const avg=feedback.length?Number((feedback.reduce((s,x)=>s+Number(x.calculated_rating||0),0)/feedback.length).toFixed(2)):null;
  res.json({ok:true,data:{days:data,weeklyAverageRating:avg,totalPlacesVisited:data.reduce((s,x)=>s+Number(x.visits||0),0),totalFeedback:feedback.length}});
}catch(e){next(e)}}

export async function rating(req,res,next){try{
  const {rows}=await query(`SELECT date,stars,arrival_minutes_early,calculated_rating,professionalism,safety FROM worker_feedback WHERE worker_id=$1 ORDER BY date DESC`,[req.auth.sub]);
  const overall=rows.length?Number((rows.reduce((s,x)=>s+Number(x.calculated_rating||0),0)/rows.length).toFixed(2)):null;
  res.json({ok:true,data:{overallRating:overall,ratings:rows.map(x=>({date:x.date,stars:x.stars,arrivalMinutesEarly:x.arrival_minutes_early,calculatedRating:x.calculated_rating,professionalism:x.professionalism,safety:x.safety}))}});
}catch(e){next(e)}}
