import {Router} from 'express';import {authenticate,authorize,requireAuthorisedWorker} from '../middleware/auth.js';import {weeklySummary,rating} from '../controllers/analyticsController.js';
const r=Router();r.use(authenticate,authorize('worker'),requireAuthorisedWorker);r.get('/weekly',weeklySummary);r.get('/rating',rating);export default r;
