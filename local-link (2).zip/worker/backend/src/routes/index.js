import { Router } from 'express';import auth from './authRoutes.js';import requests from './requestRoutes.js';import assessments from './assessmentRoutes.js';import analytics from './analyticsRoutes.js';
const r=Router();r.use('/auth',auth);r.use('/requests',requests);r.use('/assessments',assessments);r.use('/analytics',analytics);export default r;
