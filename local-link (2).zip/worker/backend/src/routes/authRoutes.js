import { Router } from 'express';
import { login,refresh,logout,me,register } from '../controllers/authController.js';
import { authenticate } from '../middleware/auth.js';
import { authLimiter } from '../middleware/rateLimit.js';
const r=Router();r.post('/register',authLimiter,register);r.post('/login',authLimiter,login);r.post('/refresh',authLimiter,refresh);r.post('/logout',authenticate,logout);r.get('/me',authenticate,me);export default r;
