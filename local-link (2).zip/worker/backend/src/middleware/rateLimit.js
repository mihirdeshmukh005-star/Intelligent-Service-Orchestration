import rateLimit from 'express-rate-limit';
import { env } from '../config/env.js';
export const apiLimiter = rateLimit({ windowMs: env.rateWindowMs, limit: env.rateMax, standardHeaders:'draft-8', legacyHeaders:false, message:{ok:false,error:'Too many requests. Please try again later.'} });
export const authLimiter = rateLimit({ windowMs: 15*60*1000, limit: 10, standardHeaders:'draft-8', legacyHeaders:false, message:{ok:false,error:'Too many authentication attempts. Try again later.'} });
export const actionLimiter = rateLimit({ windowMs: 60*1000, limit: 12, standardHeaders:'draft-8', legacyHeaders:false, message:{ok:false,error:'Too many action requests. Please slow down.'} });
