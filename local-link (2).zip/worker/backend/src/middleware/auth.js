import { verifyAccess } from '../utils/jwt.js';
import { query } from '../config/db.js';

export function authenticate(req,res,next){
  const header=req.headers.authorization||'';
  if(!header.startsWith('Bearer ')) return res.status(401).json({ok:false,error:'Authentication required'});
  try { req.auth=verifyAccess(header.slice(7)); next(); }
  catch { return res.status(401).json({ok:false,error:'Invalid or expired access token'}); }
}

export function authorize(...roles){
  return (req,res,next)=>roles.includes(req.auth?.role) ? next() : res.status(403).json({ok:false,error:'Forbidden'});
}

export async function requireAuthorisedWorker(req,res,next){
  try {
    const { rows } = await query(
      `SELECT * FROM worker_profiles WHERE id=$1 AND active=true LIMIT 1`,
      [req.auth?.sub]
    );
    const worker=rows[0];
    if(!worker) return res.status(403).json({ok:false,error:'Worker account is inactive or unavailable'});
    if(!worker.verified || !worker.assessment_passed)
      return res.status(403).json({ok:false,error:'Worker is authenticated but not authorised for professional work'});
    req.worker=worker;
    next();
  } catch(err){ next(err); }
}
