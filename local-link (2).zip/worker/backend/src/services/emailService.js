import nodemailer from 'nodemailer';import {env} from '../config/env.js';let transport;function smtp(){if(!env.smtp.host||!env.smtp.user||!env.smtp.pass)return null;if(!transport)transport=nodemailer.createTransport({host:env.smtp.host,port:env.smtp.port,secure:env.smtp.secure,auth:{user:env.smtp.user,pass:env.smtp.pass}});return transport;}async function send(to,subject,text){
  const t=smtp();
  if(t){await t.sendMail({from:env.smtp.from,to,subject,text});return {emailSent:true,provider:'smtp'};}
  if(env.resendKey&&env.resendKey!=='your_key_here'&&env.mailFromEmail){
    const r=await fetch(env.resendUrl,{method:'POST',headers:{Authorization:`Bearer ${env.resendKey}`,'Content-Type':'application/json'},body:JSON.stringify({from:`${env.mailFromName} <${env.mailFromEmail}>`,to:[to],subject,text}),signal:AbortSignal.timeout(10000)});
    if(!r.ok)throw new Error(`Resend ${r.status}: ${(await r.text()).slice(0,200)}`);
    return {emailSent:true,provider:'resend'};
  }
  console.log(`[DEV EMAIL] to=${to}\n${text}`);
  return {emailSent:false,demoMode:true,provider:'dev'};
}
export async function sendBookingEmail({request,worker,customerEmail,customer}){const subject=`Local Link booking confirmed — ${request.profession}`;const a=await send(customerEmail,subject,[`Booking confirmed with ${worker.name}`,`Service: ${request.profession}`,`Time: ${request.slot}`,`Location: ${request.location.label}`,`Worker email: ${worker.email}`].join('\n'));const b=await send(worker.email,subject,[`Booking confirmed with ${customer.name}`,`Customer email: ${customer.email}`,`Customer phone: ${customer.phone||'Not provided'}`,`Service: ${request.profession}`,`Time: ${request.slot}`,`Location: ${request.location.label}`,`Latitude: ${request.location.lat}`,`Longitude: ${request.location.lng}`,`Problem: ${request.problem||'Not provided'}`,'','Exact location disclosed after acceptance.'].join('\n'));return {emailSent:a.emailSent&&b.emailSent,demoMode:Boolean(a.demoMode||b.demoMode),recipients:[customerEmail,worker.email],providers:[a.provider,b.provider]};}export async function sendRejectionEmail({request,customer}){return send(customer.email,`Local Link — ${request.profession} request update`,[`Your request was not accepted.`,`Time: ${request.slot}`,'Please choose another professional.'].join('\n'));}
