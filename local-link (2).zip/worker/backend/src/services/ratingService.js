import { query } from '../config/db.js';

function clamp(n,min,max){return Math.max(min,Math.min(max,n));}

export function calculateRating(f){
  const stars=clamp(Number(f.stars)||0,1,5);
  const arrival = Number(f.arrivalMinutesEarly||0) >= 0 ? 5 : Number(f.arrivalMinutesEarly) >= -10 ? 4 : Number(f.arrivalMinutesEarly) >= -20 ? 3 : 2;
  const professionalism=clamp(Number(f.professionalism)||stars,1,5);
  const safety=clamp(Number(f.safety)||5,1,5);
  const completion=f.jobCompleted===false?2:5;
  return Number((stars*.45 + arrival*.20 + professionalism*.15 + safety*.15 + completion*.05).toFixed(2));
}

export async function recordFeedback(input){
  const calculatedRating=calculateRating(input);
  const id=`fb_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
  const date=input.date||new Date().toISOString().slice(0,10);
  const {rows}=await query(
    `INSERT INTO worker_feedback
     (id,worker_id,request_id,date,stars,arrival_minutes_early,job_completed,professionalism,safety,comment,calculated_rating)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
    [id,input.workerId,input.requestId,date,input.stars,input.arrivalMinutesEarly,input.jobCompleted!==false,input.professionalism,input.safety,input.comment||null,calculatedRating]
  );
  await rebuildDailyMetrics(input.workerId);
  return mapFeedback(rows[0]);
}

function mapFeedback(f){return {id:f.id,workerId:f.worker_id,requestId:f.request_id,date:f.date,stars:f.stars,arrivalMinutesEarly:f.arrival_minutes_early,jobCompleted:f.job_completed,professionalism:f.professionalism,safety:f.safety,comment:f.comment,calculatedRating:f.calculated_rating};}

export async function rebuildDailyMetrics(workerId){
  const {rows}=await query(`
    SELECT date,
      COUNT(*)::int AS visits,
      COUNT(*)::int AS feedback_count,
      COALESCE(SUM(calculated_rating),0) AS rating_total,
      COUNT(*) FILTER (WHERE arrival_minutes_early >= 0)::int AS on_time_count,
      COUNT(*) FILTER (WHERE job_completed = true)::int AS completion_count
    FROM worker_feedback
    WHERE worker_id=$1
    GROUP BY date
    ORDER BY date
  `,[workerId]);
  const out=rows.map(g=>({
    date:g.date,visits:g.visits,feedbackCount:g.feedback_count,
    ratingTotal:Number(g.rating_total),
    onTimeCount:g.on_time_count,completionCount:g.completion_count,
    averageRating:g.feedback_count?Number((Number(g.rating_total)/g.feedback_count).toFixed(2)):null,
    onTimeRate:g.feedback_count?Number((g.on_time_count/g.feedback_count).toFixed(3)):null,
    completionRate:g.feedback_count?Number((g.completion_count/g.feedback_count).toFixed(3)):null
  }));
  await query('DELETE FROM worker_daily_metrics WHERE worker_id=$1',[workerId]);
  for(const x of out){
    await query(`INSERT INTO worker_daily_metrics(worker_id,date,visits,feedback_count,rating_total,on_time_count,completion_count,average_rating,on_time_rate,completion_rate)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [workerId,x.date,x.visits,x.feedbackCount,x.ratingTotal,x.onTimeCount,x.completionCount,x.averageRating,x.onTimeRate,x.completionRate]);
  }
  return out;
}
