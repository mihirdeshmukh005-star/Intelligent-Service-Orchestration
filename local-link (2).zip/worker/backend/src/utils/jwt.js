import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { env } from '../config/env.js';
export const signAccess = (worker) => jwt.sign({ sub: worker.id, role: worker.role, type: 'access' }, env.accessSecret, { expiresIn: env.accessExpires });
export const signRefresh = (worker, jti) => jwt.sign({ sub: worker.id, role: worker.role, type: 'refresh', jti }, env.refreshSecret, { expiresIn: env.refreshExpires });
export const verifyAccess = (token) => jwt.verify(token, env.accessSecret);
export const verifyRefresh = (token) => jwt.verify(token, env.refreshSecret);
export const newJti = () => crypto.randomUUID();
