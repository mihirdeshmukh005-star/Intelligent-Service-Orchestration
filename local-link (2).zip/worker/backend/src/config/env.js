import 'dotenv/config';

const required = ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET'];

if (process.env.NODE_ENV === 'production') {
  for (const key of required) {
    if (!process.env[key] || process.env[key].length < 32) {
      throw new Error(`${key} must be at least 32 characters in production`);
    }
  }
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required in production');
}

export const env = {
  port: Number(process.env.PORT || 5000),
  nodeEnv: process.env.NODE_ENV || 'development',
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  databaseUrl: process.env.DATABASE_URL || '',
  databaseSsl: String(process.env.DATABASE_SSL || 'false') === 'true',
  accessSecret: process.env.JWT_ACCESS_SECRET || 'dev_access_secret_change_me_32_chars_long',
  accessExpires: process.env.JWT_ACCESS_EXPIRES || '15m',
  refreshSecret: process.env.JWT_REFRESH_SECRET || 'dev_refresh_secret_change_me_32_chars_long',
  refreshExpires: process.env.JWT_REFRESH_EXPIRES || '7d',
  rateWindowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60000),
  rateMax: Number(process.env.RATE_LIMIT_MAX || 60),
  resendKey: process.env.RESEND_API_KEY || '',
  resendUrl: process.env.RESEND_API_URL || 'https://api.resend.com/emails',
  mailFromEmail: process.env.MAIL_FROM_EMAIL || '',
  mailFromName: process.env.MAIL_FROM_NAME || 'Local Link',
  smtp: {
    host: process.env.SMTP_HOST || '', port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE) === 'true', user: process.env.SMTP_USER || '', pass: process.env.SMTP_PASS || '',
    from: process.env.SMTP_FROM || 'Local Link <no-reply@example.com>'
  }
};
