import test from 'node:test';
import assert from 'node:assert/strict';
import { parseSlot, overlaps } from './src/utils/slots.js';

test('parses Local Link one-hour slots',()=>{
  assert.deepEqual(parseSlot('10:00–11:00'),{start:600,end:660});
  assert.deepEqual(parseSlot('10:00-11:00'),{start:600,end:660});
});

test('accepted 10-11 blocks only overlapping slots',()=>{
  assert.equal(overlaps('10:00–11:00',660,'10:00–11:00'),true);
  assert.equal(overlaps('10:00–11:00',660,'10:30–11:30'),true);
  assert.equal(overlaps('10:00–11:00',660,'11:00–12:00'),false);
  assert.equal(overlaps('10:00–11:00',660,'12:00–13:00'),false);
});

test('overrun to 11:30 blocks 11-12',()=>{
  assert.equal(overlaps('10:00–11:00',690,'11:00–12:00'),true);
  assert.equal(overlaps('10:00–11:00',690,'12:00–13:00'),false);
});

test('invalid slots are rejected by parser',()=>{
  assert.equal(parseSlot('11:00–10:00'),null);
  assert.equal(parseSlot('abc'),null);
});
