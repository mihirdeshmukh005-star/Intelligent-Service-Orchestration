export default { base: '/worker/' };
