import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { motion, AnimatePresence } from 'framer-motion';
import './styles.css';
import * as api from './api.js';
const BASE = import.meta.env.BASE_URL;

const ICONS = {
  bell: '◔', profile: '◉', briefcase: '▣', chart: '▥', shield: '◆', clock: '◷', star: '★', map: '⌖', check: '✓', x: '×', mail: '✉', bolt: 'ϟ', wrench: '⚒'
};


const mapRequest = (r,i) => ({
  id: r.id, customer: r.customer, service: r.service, area: r.area, time: String(r.timeSlot||'').replace(' - ',' – '),
  distance: `${Number(r.distanceKm||0).toFixed(1)} km`, price: r.price || '—', customerEmail: r.customerEmail, note: r.note,
  image: `${BASE}assets/customer-${(i%4)+1}.svg`, status: r.status, occupiedUntilMinutes: r.occupiedUntilMinutes, extensionReason: r.extensionReason, startedAt: r.startedAt
});

const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

function App(){
  const [screen,setScreen] = useState('loading');
  const [me,setMe] = useState(null);
  const [requests,setRequests] = useState([]);
  const [weekly,setWeekly] = useState(null);
  const [selected,setSelected] = useState(null);
  const [toast,setToast] = useState(null);
  const [profileOpen,setProfileOpen] = useState(false);
  const seenPendingRef = useRef(null);

  useEffect(()=>{
    let alive=true;
    let timer=null;
    api.login().then(u=>{
      if(!alive)return;
      setMe(u); setScreen('dashboard');
      loadData({notifyNew:false});
      timer=setInterval(pollRequests,5000);
    }).catch(()=>{});
    return ()=>{alive=false;if(timer)clearInterval(timer)};
  },[]);
  useEffect(()=>{ if(!toast) return; const t=setTimeout(()=>setToast(null),4200); return ()=>clearTimeout(t); },[toast]);

  const pending = requests.filter(r=>r.status==='pending').length;
  const accepted = requests.find(r=>['accepted','in_progress'].includes(r.status));

  async function pollRequests(){
    try{
      const list=await api.getRequests();
      const normalized=list.filter(r=>['pending','accepted','in_progress','rejected','auto-rejected','completed'].includes(r.status)).map(mapRequest);
      const pendingIds=new Set(normalized.filter(r=>r.status==='pending').map(r=>r.id));
      if(seenPendingRef.current){
        const fresh=normalized.find(r=>r.status==='pending'&&!seenPendingRef.current.has(r.id));
        if(fresh)setToast({type:'success',title:'New booking request',text:`${fresh.customer} requested ${fresh.service} for ${fresh.time}.`});
      }
      seenPendingRef.current=pendingIds;
      setRequests(normalized);
    }catch(e){/* dashboard remains usable if one poll fails */}
  }
  async function loadData({notifyNew=true}={}){
    try {
      const [list,profile,summary]=await Promise.all([api.getRequests(),api.getProfile(),api.getWeekly()]);
      const normalized=list.filter(r=>['pending','accepted','in_progress','rejected','auto-rejected','completed'].includes(r.status)).map(mapRequest);
      const pendingIds=new Set(normalized.filter(r=>r.status==='pending').map(r=>r.id));
      if(notifyNew && seenPendingRef.current){
        const newRequest=normalized.find(r=>r.status==='pending'&&!seenPendingRef.current.has(r.id));
        if(newRequest) setToast({type:'success',title:'New booking request',text:`${newRequest.customer} requested ${newRequest.service} for ${newRequest.time}.`});
      }
      seenPendingRef.current=pendingIds;
      setRequests(normalized); setMe(profile); setWeekly(summary);
    }
    catch(e){ setToast({type:'warning',title:'Could not load dashboard',text:e.message}); }
  }
  async function enterProfessional(){ setScreen('dashboard'); await loadData(); }
  async function acceptRequest(id){
    const chosen=requests.find(r=>r.id===id); if(!chosen || chosen.status!=='pending') return;
    try { await api.acceptRequest(id); } catch(e){ setToast({type:'warning',title:'Could not accept',text:e.message}); loadData(); return; }
    setSelected({type:'accepted',request:chosen});
    setToast({type:'success',title:'Booking accepted',text:`${chosen.customer}'s request is confirmed. Other pending requests were automatically closed.`});
    loadData();
  }
  async function startRequest(id){
    try{await api.startRequest(id);setToast({type:'success',title:'Job started',text:'This visit is now in progress. If it runs late, request more time before the next slot.'});loadData();}
    catch(e){setToast({type:'warning',title:'Could not start job',text:e.message});}
  }
  async function extendRequest(id){
    const raw=window.prompt('How many extra minutes are needed? (15–240)','30');
    if(raw===null)return;
    const minutes=Number(raw);
    if(!Number.isInteger(minutes)||minutes<15||minutes>240){setToast({type:'warning',title:'Invalid extension',text:'Enter a whole number from 15 to 240 minutes.'});return;}
    const reason=window.prompt('Why is more time needed?','Work requires additional time.')||'Work requires additional time.';
    try{const out=await api.extendRequest(id,minutes,reason);setToast({type:'success',title:'Extra time recorded',text:'Overlapping future requests are now blocked. Pending overlapping requests were closed.'});loadData();return out;}
    catch(e){setToast({type:'warning',title:'Could not extend job',text:e.message});}
  }
  async function completeRequest(id){ try{await api.completeRequest(id);setToast({type:'success',title:'Job completed',text:'The completed visit is now included in your performance metrics.'});loadData();}catch(e){setToast({type:'warning',title:'Could not complete job',text:e.message});} }
  async function rejectRequest(id){
    const chosen=requests.find(r=>r.id===id); if(!chosen || chosen.status!=='pending') return;
    try { await api.rejectRequest(id); } catch(e){ setToast({type:'warning',title:'Could not reject',text:e.message}); loadData(); return; }
    setSelected({type:'rejected',request:chosen});
    setToast({type:'warning',title:'Request rejected',text:`${chosen.customer} is prompted to select another professional.`});
    loadData();
  }
  function signOut(){ api.signOut(); }

  return <div className="app-shell">
    <Header me={me} screen={screen} pending={pending} profileOpen={profileOpen} setProfileOpen={setProfileOpen} onSignOut={signOut} onDashboard={()=>setScreen('dashboard')} onHistory={()=>setScreen('history')} />
    <AnimatePresence mode="wait">
      {screen==='landing' && <Landing key="landing" onEnter={enterProfessional} />}
      {screen==='dashboard' && <Dashboard me={me} key="dashboard" requests={requests} pending={pending} accepted={accepted} onAccept={acceptRequest} onReject={rejectRequest} onStart={startRequest} onExtend={extendRequest} onComplete={completeRequest} onHistory={()=>setScreen('history')} />}
      {screen==='history' && <History key="history" weekly={weekly} onBack={()=>setScreen('dashboard')} />}
    </AnimatePresence>
    <AnimatePresence>
      {selected && <RequestResultModal selected={selected} onClose={()=>setSelected(null)} />}
    </AnimatePresence>
    {toast && <Toast {...toast}/>} 
  </div>
}

function Header({me,screen,pending,profileOpen,setProfileOpen,onSignOut,onDashboard,onHistory}){
  return <header className="topbar">
    <div className="brand" onClick={onDashboard}><div className="brand-pin">●</div><div><b>Local Link</b><span>Professional Network</span></div></div>
    <nav><button className={screen==='dashboard'?'active':''} onClick={onDashboard}>Dashboard</button><button className={screen==='history'?'active':''} onClick={onHistory}>History</button><button onClick={()=>document.getElementById('requests')?.scrollIntoView({behavior:'smooth'})}>Requests {pending>0&&<em>{pending}</em>}</button></nav>
    <div className="profile-wrap"><button className="profile-btn" onClick={()=>setProfileOpen(v=>!v)}><span className="avatar">{(me?.name||"Professional").split(" ").map(w=>w[0]).slice(0,2).join("").toUpperCase()}</span><span className="profile-text"><b>{me?.name||'Professional'}</b><small>Verified {me?.services?.[0]||'Service Professional'}</small></span><span>⌄</span></button>{profileOpen&&<div className="profile-menu"><div className="menu-head"><img src={BASE+"assets/electrician.svg"}/><div><b>{me?.name||'Professional'}</b><span>{me?.services?.[0]||'Service Professional'}</span></div></div><button>Profile & credentials</button><button>Skills & service area</button><button onClick={onSignOut}>Sign out</button></div>}</div>
  </header>
}

function Landing({onEnter}){ return <motion.main className="landing page" initial={{opacity:0,y:14}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-10}}>
  <section className="hero-card">
    <div className="hero-copy"><span className="eyebrow">SERVICE PROFESSIONAL PORTAL</span><h1>Work smarter.<br/><span>Serve locally.</span></h1><p>Manage nearby requests, accept the right jobs, and build a trusted professional profile — all from one clean workspace.</p><div className="hero-actions"><button className="primary big" onClick={onEnter}>Enter Professional Console <span>→</span></button><button className="ghost" onClick={()=>document.getElementById('how')?.scrollIntoView({behavior:'smooth'})}>How it works</button></div><div className="trust-row"><div><strong>4.9★</strong><span>Average rating</span></div><div><strong>184</strong><span>Jobs completed</span></div><div><strong>97%</strong><span>Response rate</span></div></div></div>
    <div className="hero-art"><div className="orb orb-a"></div><div className="orb orb-b"></div><img className="hero-worker" src={BASE+"assets/electrician.svg"}/><div className="floating-card card-top"><span className="mini-icon green">✓</span><div><b>Verified professional</b><small>Authority status active</small></div></div><div className="floating-card card-bottom"><span className="mini-icon blue">⌖</span><div><b>4 new requests</b><small>Within your service radius</small></div></div></div>
  </section>
  <section id="how" className="feature-grid"><Feature icon="⌖" title="Nearby requests" text="See customer jobs that match your profession and service area."/><Feature icon="✓" title="Smart acceptance" text="Accept one request and the queue closes cleanly so customers get clear outcomes."/><Feature icon="★" title="Reputation" text="Ratings, completed jobs and response reliability strengthen your profile."/></section>
</motion.main> }
function Feature({icon,title,text}){return <div className="feature"><div className="feature-icon">{icon}</div><div><h3>{title}</h3><p>{text}</p></div></div>}

function Dashboard({me,requests,pending,accepted,onAccept,onReject,onStart,onExtend,onComplete,onHistory}){
  const pendingRequests=requests.filter(r=>r.status==='pending');
  return <motion.main className="page dashboard" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}>
    <div className="page-heading"><div><span className="eyebrow">WORKER CONSOLE</span><h1>Good morning, {(me?.name||'Aarav').split(' ')[0]} <span>👋</span></h1><p>Here is what needs your attention today.</p></div><button className="secondary" onClick={onHistory}>View 7-day performance →</button></div>
    <div className="stats"><Stat icon="⌖" label="Open requests" value={pending} note="Waiting for response"/><Stat icon="✓" label="Today's jobs" value={accepted?1:3} note="Confirmed visits"/><Stat icon="★" label="Rating" value="4.9" note="Last 30 days"/><Stat icon="₹" label="Est. earnings" value="₹2,850" note="Today"/></div>
    <section id="requests" className="content-grid"><div className="panel requests-panel"><div className="panel-head"><div><h2>Request bucket</h2><p>Customers currently requesting your service.</p></div><span className="live"><i></i> LIVE</span></div><div className="request-list">{requests.map(r=><RequestCard key={r.id} request={r} onAccept={onAccept} onReject={onReject} onStart={onStart} onExtend={onExtend} onComplete={onComplete}/>)}</div></div><aside className="side-column"><ProfileCard me={me}/><TodayCard requests={requests} onHistory={onHistory}/></aside></section>
    <section className="insight-strip"><div className="insight-icon">◆</div><div><b>Why this queue matters</b><p>When you accept one request, Local Link closes only overlapping pending requests. If a job runs late, Request More Time extends the occupied window and blocks overlapping bookings.</p></div><span>Smart dispatch</span></section>
  </motion.main>
}
function Stat({icon,label,value,note}){return <div className="stat"><div className="stat-icon">{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{note}</small></div></div>}
function RequestCard({request,onAccept,onReject,onStart,onExtend,onComplete}){
  const occupied=request.occupiedUntilMinutes;
  const endLabel=occupied!=null?`${Math.floor(occupied/60)}:${String(occupied%60).padStart(2,'0')}`:null;
  return <motion.article layout className={`request ${request.status}`} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}}>
    <img src={request.image} className="customer-img"/>
    <div className="request-main">
      <div className="request-title"><div><h3>{request.service}</h3><p>{request.customer} · {request.area}</p></div><span className="distance">{request.distance}</span></div>
      <div className="request-meta"><span>◷ {request.time}</span><span>₹ {request.price.replace('₹','')}</span><span>⌖ {request.distance} away</span></div>
      <p className="note">“{request.note}”</p>
      {request.status==='in_progress' && <p className="note"><b>In progress.</b> Reserved until {endLabel||'the scheduled end'}{request.extensionReason?` · ${request.extensionReason}`:''}</p>}
    </div>
    <div className="request-actions">
      {request.status==='pending'?<><button className="accept" onClick={()=>onAccept(request.id)}>Accept booking</button><button className="reject" onClick={()=>onReject(request.id)}>Reject</button></>
      :request.status==='accepted'?<><button className="accept" onClick={()=>onStart(request.id)}>Start job</button><button className="secondary" onClick={()=>onComplete(request.id)}>Complete</button></>
      :request.status==='in_progress'?<><button className="secondary" onClick={()=>onExtend(request.id)}>Request more time</button><button className="accept" onClick={()=>onComplete(request.id)}>Mark completed ✓</button></>
      :<span className={`status-pill ${request.status}`}>{request.status==='auto-rejected'?'Auto-rejected':request.status==='rejected'?'Rejected':'Completed'}</span>}
    </div>
  </motion.article>
}
function ProfileCard({me}){const m=me?.metrics||{};return <div className="panel profile-card"><div className="panel-head"><div><h2>Your professional profile</h2><p>Live profile data.</p></div><span className="verified">✓ Verified</span></div><div className="pro-row"><img src={BASE+"assets/electrician.svg"}/><div><h3>{me?.name||'Professional'}</h3><p>{me?.services?.[0]||'Service Professional'}</p><div className="stars">{m.baseRating?`${m.baseRating.toFixed(2)} ★`:'No reviews yet'} <span>{m.totalFeedback||0} reviews</span></div></div></div><div className="chips"><span>{m.jobsCompleted||0} jobs completed</span><span>{Math.round((m.responseRate||0)*100)}% response</span><span>{Math.round((m.onTimeRate||0)*100)}% on-time</span></div><div className="profile-foot"><span>Assessment</span><b>{me?.assessmentPassed?'Passed ≥ 60%':'Not passed'}</b></div></div>}
function TodayCard({onHistory,requests=[]}){const active=requests.filter(r=>['pending','accepted','in_progress'].includes(r.status)).slice(0,3);return <div className="panel today-card"><div className="panel-head"><div><h2>Today's queue</h2><p>Live booking requests</p></div></div><div className="route">{active.length?active.map((r,i)=><RouteItem key={r.id} time={r.time||'—'} area={r.area||'Selected area'} service={r.service||r.note||'Service request'} active={i===0}/>):<div className="empty-console"><span>No active visits</span></div>}</div><button className="full-link" onClick={onHistory}>Open performance history →</button></div>}
function RouteItem({time,area,service,active}){return <div className={`route-item ${active?'active':''}`}><div className="route-time">{time}<small>AM</small></div><div className="route-line"><i></i></div><div><b>{service}</b><span>{area}, Pune</span></div></div>}

function History({onBack,weekly}){const history=weekly?.days||[];const total=history.reduce((s,x)=>s+(x.visits||0),0);const ratings=history.filter(x=>x.averageRating!=null);const avg=ratings.length?(ratings.reduce((s,x)=>s+Number(x.averageRating),0)/ratings.length).toFixed(2):'—';const ontime=history.filter(x=>x.onTimeRate!=null);const ontimeAvg=ontime.length?Math.round(ontime.reduce((s,x)=>s+Number(x.onTimeRate),0)/ontime.length*100):0;const completion=history.filter(x=>x.completionRate!=null);const completionAvg=completion.length?Math.round(completion.reduce((s,x)=>s+Number(x.completionRate),0)/completion.length*100):0;const max=Math.max(1,...history.map(x=>x.visits||0));return <motion.main className="page history-page" initial={{opacity:0,x:15}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-15}}><div className="page-heading"><div><button className="back" onClick={onBack}>← Back to dashboard</button><span className="eyebrow">PERFORMANCE HISTORY</span><h1>Your last 7 days</h1><p>Live metrics calculated from your completed customer work and reviews.</p></div><div className="period">Last 7 days</div></div><div className="history-grid"><div className="panel chart-panel"><div className="panel-head"><div><h2>Completed visits</h2><p>Daily completed work</p></div><span className="chart-total">{total} visits</span></div><div className="bar-chart">{history.map(x=><div className="bar-col" key={x.date}><span className="bar-value">{x.visits||0}</span><div className="bar" style={{height:`${((x.visits||0)/max)*150}px`}}></div><small>{new Date(x.date+'T00:00:00').toLocaleDateString('en-US',{weekday:'short'})}</small></div>)}</div></div><div className="panel rating-panel"><div className="panel-head"><div><h2>Customer rating</h2><p>Multifactor review average</p></div><span className="rating-big">{avg} ★</span></div><div className="summary"><span>On-time rate</span><b>{ontimeAvg}%</b><small>Based on recorded review visits</small></div><div className="summary"><span>Completion rate</span><b>{completionAvg}%</b><small>Based on recorded review visits</small></div></div></div><div className="history-grid lower"><div className="panel summary-panel"><div className="panel-head"><div><h2>Worker analysis</h2><p>Different for this professional</p></div></div><Summary label="Completed visits" value={total} note="Last 7 days"/><Summary label="Average rating" value={avg} note="Safety + professionalism + punctuality"/><Summary label="On-time rate" value={`${ontimeAvg}%`} note="Recorded reviews"/><Summary label="Completion rate" value={`${completionAvg}%`} note="Recorded reviews"/></div><div className="panel summary-panel"><div className="panel-head"><div><h2>Review quality</h2><p>Customer safety signals are included</p></div></div><p>{ratings.length?"Ratings are calculated from the customer's overall score plus punctuality, professionalism and safety—not stars alone.":'No completed customer reviews yet. Complete jobs and collect reviews to build your metrics.'}</p></div></div></motion.main>}
function Summary({label,value,note}){return <div className="summary"><span>{label}</span><b>{value}</b><small>{note}</small></div>}

function RequestResultModal({selected,onClose}){const accepted=selected.type==='accepted'; return <div className="modal-backdrop"><motion.div className="small-modal" initial={{opacity:0,y:15}} animate={{opacity:1,y:0}}><div className={`result-icon ${accepted?'success':'fail'}`}>{accepted?'✓':'×'}</div><h2>{accepted?'Booking confirmed':'Request rejected'}</h2><p>{accepted?`The request from ${selected.request.customer} is confirmed. Confirmation emails are queued for both sides.`:`${selected.request.customer} will be prompted to select another professional. The request is now closed for you.`}</p>{accepted&&<div className="email-preview"><span>✉</span><div><b>Confirmation emails</b><small>Customer + professional · booking details + time + location</small></div></div>}<button className="primary" onClick={onClose}>Back to requests</button></motion.div></div>}
function Toast({type,title,text}){return <motion.div className={`toast ${type}`} initial={{opacity:0,y:-15}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-15}}><div className="toast-icon">{type==='success'?'✓':type==='warning'?'!':'i'}</div><div><b>{title}</b><span>{text}</span></div></motion.div>}


createRoot(document.getElementById('root')).render(<App/>);
