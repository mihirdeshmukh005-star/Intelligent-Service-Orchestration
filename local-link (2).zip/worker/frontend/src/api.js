// Worker Frontend -> Worker Backend connector
const API = (import.meta.env.VITE_API_URL ?? '/svc/worker/api').replace(/\/$/, '');
// ---- Login bridge: tokens come from the Local Link login session (cookie), never from passwords in the browser ----
async function bridge(app) {
  const res = await fetch(`/api/bridge/token?app=${app}`, { credentials: 'same-origin' });
  const j = await res.json().catch(() => ({}));
  if (res.status === 401) { location.replace('/'); throw new Error('Please log in.'); }
  if (res.status === 403 && j.error === 'ASSESSMENT_REQUIRED') { location.replace('/assessment/'); throw new Error(j.message); }
  if (res.status === 403) { location.replace('/'); throw new Error(j.message); }
  if (!res.ok) throw new Error(j.message || 'Could not start your session.');
  return j;
}
export async function signOut() {
  try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch {}
  location.replace('/');
}

let token = null;
let me = null;
export const getMe = () => me;

export async function login() {            // exchanges the login session for a worker-backend token
  const j = await bridge('worker');
  token = j.token; me = j.user;
  return me;
}

async function raw(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(API + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const json = await res.json().catch(() => ({}));
  return { res, json };
}

async function call(path, opts = {}) {
  if (!token) await login();
  let { res, json } = await raw(path, opts);
  if (res.status === 401) { await login(); ({ res, json } = await raw(path, opts)); }
  if (!res.ok || json.ok === false) throw new Error(json.error || `Request failed (${res.status})`);
  return json;
}

export const getProfile = async () => (await call('/auth/me')).data;
export const getRequests = async () => (await call('/requests')).data;
export const acceptRequest = async id => (await call(`/requests/${id}/accept`, { method: 'POST' })).data;
export const rejectRequest = async id => (await call(`/requests/${id}/reject`, { method: 'POST', body: {} })).data;
export const startRequest = async id => (await call(`/requests/${id}/start`, { method: 'POST', body: {} })).data;
export const extendRequest = async (id, additionalMinutes, reason) => (await call(`/requests/${id}/extend`, { method: 'POST', body: { additionalMinutes, reason } })).data;
export const completeRequest = async id => (await call(`/requests/${id}/complete`, { method: 'POST', body: {} })).data;
export const submitAssessment = async (profession, score, autoSubmitted) =>
  (await call('/assessments/submit', { method: 'POST', body: { profession, score, total: 20, autoSubmitted } })).data;
export const getWeekly = async () => (await call('/analytics/weekly')).data;
