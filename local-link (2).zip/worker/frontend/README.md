# Local Link — Professional Console v2

A polished React/Vite prototype for the **Service Professional** side of Local Link, based on the supplied wireframes and the white/blue visual reference.

## Included
- Professional login/entry screen
- Mandatory 20-question assessment modal with 20-minute timer
- 60% technical + 40% safety questions
- Scenario-heavy MCQs with one correct option
- Electrician / Plumber assessment selector
- Demo-only **Bypass** button
- Professional dashboard
- Request bucket with multiple customer requests
- Accept / Reject actions
- Accepting one request automatically closes other pending requests
- Rejection feedback recommending another professional
- Confirmation/rejection modal
- Demo email API + optional SMTP integration
- Seven-day worker history
- Visits chart, rating line chart, earnings bars and activity summary
- Profile menu, verification badge, service skills and radius
- Local SVG illustrations so the prototype does not depend on image CDNs
- Responsive mobile layout
- Framer Motion transitions

## Run

```bash
npm install
npm run start
```

This runs Vite and the Express API together.

Frontend: http://localhost:5173
API: http://localhost:5000/api/health

Or separately:

```bash
npm run server
npm run dev
```

## Email

By default the backend runs in **demo email mode** and logs the customer + worker recipients and message to the terminal. To send real emails, copy `.env.example` to `.env` and provide SMTP credentials.

## Important prototype note

The assessment and verification UI is a prototype. Passing this website's assessment does not itself grant government authorization. A production system would need the appropriate authority/credential verification process.
