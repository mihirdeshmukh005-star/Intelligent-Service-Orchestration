// One command for the whole platform:  node scripts/run.mjs install | build | start
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const FRONTENDS = ['client', 'customer/frontend', 'assessment/frontend', 'worker/frontend'];
const ALL = ['server', ...FRONTENDS, 'customer/backend', 'assessment/backend', 'worker/backend'];

function loadEnv() {
  const f = path.join(root, '.env');
  if (!existsSync(f)) { console.error('\nMissing .env — copy .env.example to .env and fill it in.\n'); process.exit(1); }
  for (const line of readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2]; if (/^(['"]).*\1$/.test(v)) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
const sh = (cwd, args, env = process.env) => {
  const r = spawnSync(npm, args, { cwd: path.join(root, cwd), stdio: 'inherit', env, shell: process.platform === 'win32' });
  if (r.status) { console.error(`\n✖ "npm ${args.join(' ')}" failed in ${cwd}\n`); process.exit(r.status); }
};

const cmd = process.argv[2];
if (cmd === 'install') { for (const d of ALL) { console.log(`\n── npm install: ${d}`); sh(d, ['install', '--include=dev']); } }
else if (cmd === 'build') { for (const d of FRONTENDS) { console.log(`\n── build: ${d}`); sh(d, ['run', 'build']); } }
else if (cmd === 'start') start();
else { console.log('Usage: node scripts/run.mjs install | build | start'); process.exit(1); }

function start() {
  if (Number(process.versions.node.split('.')[0]) < 20) { console.error('Node 20 or newer is required.'); process.exit(1); }
  loadEnv();
  const missing = ['DATABASE_URL', 'JWT_SECRET'].filter(k => !process.env[k]);
  if (missing.length) { console.error(`\nMissing in .env: ${missing.join(', ')}\n`); process.exit(1); }
  const hasSmtp = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
  const hasResend = Boolean(process.env.RESEND_API_KEY && process.env.RESEND_API_KEY !== 'your_key_here' && process.env.MAIL_FROM_EMAIL);
  if (!hasSmtp && !hasResend && process.env.DEV_EMAIL_MODE !== 'true') { console.error('\nConfigure Gmail/SMTP (SMTP_HOST, SMTP_USER, SMTP_PASS) for real email delivery, or Resend with a verified sender, or set DEV_EMAIL_MODE=true for local OTP testing.\n'); process.exit(1); }
  for (const f of FRONTENDS) if (!existsSync(path.join(root, f, 'dist'))) { console.error(`\n${f} is not built yet. Run: npm run build\n`); process.exit(1); }

  const secret = process.env.JWT_SECRET;
  // Worker backend uses its own access/refresh secrets: derive them from JWT_SECRET unless set explicitly.
  process.env.JWT_ACCESS_SECRET ||= createHash('sha256').update(secret + ':worker-access').digest('hex');
  process.env.JWT_REFRESH_SECRET ||= createHash('sha256').update(secret + ':worker-refresh').digest('hex');
  const ports = { customer: process.env.CUSTOMER_PORT || '5001', assessment: process.env.ASSESSMENT_PORT || '5002', worker: process.env.WORKER_PORT || '5003' };
  const publicPort = process.env.PORT || '3000';

  // 1) database preparation (idempotent)
  const prep = (dir, file) => {
    const r = spawnSync(process.execPath, [file], { cwd: path.join(root, dir), stdio: 'inherit', env: process.env });
    if (r.status) { console.error(`\n✖ Database setup failed (${dir}). Check DATABASE_URL and that PostgreSQL is running.\n`); process.exit(1); }
  };
  prep('assessment/backend', 'scripts/ensure-ready.mjs');
  prep('worker/backend', 'scripts/apply-schema.js');

  // 2) the four processes
  const svc = [
    ['customer  ', 'customer/backend', ['server.js'], { PORT: ports.customer }],
    ['assessment', 'assessment/backend', ['src/server.mjs'], { PORT: ports.assessment }],
    ['worker    ', 'worker/backend', ['src/server.js'], { PORT: ports.worker }],
    ['gateway   ', 'server', ['server.js'], { PORT: publicPort }],
  ];
  const kids = svc.map(([name, dir, args, env]) => {
    const p = spawn(process.execPath, args, { cwd: path.join(root, dir), env: { ...process.env, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
    const tag = d => String(d).split('\n').filter(Boolean).forEach(l => console.log(`[${name}] ${l}`));
    p.stdout.on('data', tag); p.stderr.on('data', tag);
    p.on('exit', code => { if (!stopping) { console.error(`[${name}] exited (${code}). Stopping everything.`); stop(code || 1); } });
    return p;
  });
  let stopping = false;
  function stop(code = 0) { stopping = true; kids.forEach(k => k.kill()); setTimeout(() => process.exit(code), 300); }
  process.on('SIGINT', () => stop(0)); process.on('SIGTERM', () => stop(0));
  console.log(`\nLocal Link is starting → open http://localhost:${publicPort}\n`);
}
