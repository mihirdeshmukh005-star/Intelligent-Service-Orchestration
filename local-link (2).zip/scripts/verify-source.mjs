import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const must=[
  'server/src/routes/auth.js','server/src/bridge.js','server/src/mailer.js',
  'customer/backend/src/services/aiService.js','customer/backend/src/controllers/customerController.js',
  'assessment/backend/src/app.mjs','assessment/frontend/src/main.jsx',
  'worker/backend/src/controllers/requestController.js','worker/backend/src/controllers/analyticsController.js',
  'worker/frontend/src/main.jsx','customer/frontend/src/App.jsx'
];
for(const f of must) if(!fs.existsSync(path.join(root,f))) throw new Error(`Missing required file: ${f}`);
const text=must.map(f=>fs.readFileSync(path.join(root,f),'utf8')).join('\n');
const forbidden=['OPENAI_API_KEY','OPENAI_MODEL','OPENAI_BASE_URL','openaiKey','openaiModel','openaiBaseUrl','jsonStore.js'];
for(const x of forbidden) if(text.includes(x)) throw new Error(`Forbidden active reference: ${x}`);
if(!fs.readFileSync(path.join(root,'customer/backend/src/services/aiService.js'),'utf8').includes('GROQ_API_KEY') && !fs.readFileSync(path.join(root,'customer/backend/src/services/aiService.js'),'utf8').includes('env.groqKey')) throw new Error('Groq integration missing');
if(!fs.readFileSync(path.join(root,'server/src/routes/auth.js'),'utf8').includes("House Keeping")) throw new Error('Professional list mismatch');
if(!fs.readFileSync(path.join(root,'server/src/bridge.js'),'utf8').includes('assessmentPassPercent')) throw new Error('Assessment threshold bridge missing');
if(!fs.readFileSync(path.join(root,'worker/backend/src/controllers/requestController.js'),'utf8').includes("auto-rejected")) throw new Error('Atomic auto-rejection path missing');
if(!fs.readFileSync(path.join(root,'worker/backend/src/services/emailService.js'),'utf8').includes('Customer phone')) throw new Error('Worker confirmation email missing customer phone');
if(fs.existsSync(path.join(root,'worker/backend/data')) || fs.existsSync(path.join(root,'worker/backend/src/utils/jsonStore.js'))) throw new Error('Legacy worker JSON persistence remains');
console.log('SOURCE_VERIFY_OK');
