import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..', import.meta.url).pathname);
const checks=[
  ['server/src/mailer.js', /if\(process\.env\.SMTP_HOST && process\.env\.SMTP_USER && process\.env\.SMTP_PASS\)\{\s*return smtp/],
  ['customer/backend/src/services/emailService.js', /const t=getTransport\(\);\s*if\(t\)\{[\s\S]*provider:'smtp'/],
  ['worker/backend/src/services/emailService.js', /const t=smtp\(\);\s*if\(t\)\{[\s\S]*provider:'smtp'/],
  ['scripts/run.mjs', /const hasSmtp = Boolean\(process\.env\.SMTP_HOST && process\.env\.SMTP_USER && process\.env\.SMTP_PASS\)/],
  ['server/src/config.js', /const missing = \['DATABASE_URL', 'JWT_SECRET'\]/]
];
let failed=0;
for(const [file,re] of checks){const text=fs.readFileSync(path.join(root,file),'utf8');if(!re.test(text)){console.error('FAIL',file);failed++;}else console.log('PASS',file);}
if(failed) process.exit(1);
console.log('Email provider validation passed: SMTP is preferred for OTP and booking emails; Resend is fallback only.');
