import dotenv from 'dotenv'; dotenv.config(); import app from './app.mjs'; import {pool} from './db.mjs';
const port=Number(process.env.PORT||5000); const server=app.listen(port,()=>console.log(`Local Link Assessment API listening on ${port}`));
process.on('SIGTERM',async()=>{server.close(async()=>{await pool.end();process.exit(0);});});
