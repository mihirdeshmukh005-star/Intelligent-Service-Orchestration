import jwt from 'jsonwebtoken';
export function auth(req,res,next){ try{ const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Missing bearer token'}); req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET); next(); }catch{return res.status(401).json({error:'Invalid or expired token'});} }
export function role(...roles){ return (req,res,next)=> roles.includes(req.user?.role)?next():res.status(403).json({error:'Forbidden'}); }
export function sign(user){ return jwt.sign({id:user.id,email:user.email,role:user.role},process.env.JWT_SECRET,{expiresIn:'8h'}); }
