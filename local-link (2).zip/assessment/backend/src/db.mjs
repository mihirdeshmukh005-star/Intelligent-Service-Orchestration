import pg from 'pg';
import dotenv from 'dotenv';
dotenv.config();
export const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10, idleTimeoutMillis: 30000, connectionTimeoutMillis: 10000 });
export async function tx(fn){ const c=await pool.connect(); try{ await c.query('BEGIN'); const out=await fn(c); await c.query('COMMIT'); return out; } catch(e){ await c.query('ROLLBACK'); throw e; } finally{ c.release(); } }
