// Creates the assessment tables and loads the 80 questions ONLY if they are not there yet (safe to run on every start).
import dotenv from 'dotenv'; dotenv.config();
import pg from 'pg';
import { spawnSync } from 'node:child_process';
const run = f => { const r = spawnSync(process.execPath, [f], { stdio: 'inherit' }); if (r.status) process.exit(r.status); };
run('scripts/migrate.mjs');
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM assessment.questions');
await pool.end();
if (!rows[0].n) run('scripts/seed.mjs'); else console.log('Assessment questions already loaded.');
