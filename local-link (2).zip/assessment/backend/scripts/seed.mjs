import dotenv from 'dotenv'; dotenv.config();
import pg from 'pg'; import bcrypt from 'bcryptjs';
import fs from 'node:fs/promises';
const {Pool}=pg; const pool=new Pool({connectionString:process.env.DATABASE_URL});
const QUESTION_BANK = {
  "electrician": [
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A room light is not working, but other rooms have power. What should you check first?",
      "options": [
        "Check the room's switch and local circuit",
        "Replace the main meter",
        "Open the service pole",
        "Pour water on the switch"
      ],
      "answer": 0,
      "visual": "💡"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A 1000 W appliance is connected to 230 V. Which current is closest?",
      "options": [
        "0.23 A",
        "2.3 A",
        "4.35 A",
        "23 A"
      ],
      "answer": 2,
      "visual": "⚡"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A customer says a ceiling fan hums but does not start. What is a common first check?",
      "options": [
        "Check the fan capacitor and connections",
        "Replace the electricity meter",
        "Increase the supply voltage",
        "Remove the earthing wire"
      ],
      "answer": 0,
      "visual": "🌀"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A socket is loose in its box. What is the appropriate repair?",
      "options": [
        "Isolate supply, secure the box/socket and reconnect safely",
        "Tape over the front only",
        "Increase the fuse rating",
        "Ignore it"
      ],
      "answer": 0,
      "visual": "🔌"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "Two lamps are connected in parallel. If one lamp fails, what normally happens to the other?",
      "options": [
        "The other also stops",
        "The other can continue working",
        "The main supply becomes zero",
        "Both become short circuits"
      ],
      "answer": 1,
      "visual": "💡"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A breaker trips immediately when a particular appliance is switched on. What is the best next step?",
      "options": [
        "Repeatedly reset it",
        "Disconnect the appliance and inspect for a fault",
        "Replace it with a larger breaker",
        "Bypass the breaker"
      ],
      "answer": 1,
      "visual": "🧰"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A customer wants a new high-load appliance connected. What should you verify before installation?",
      "options": [
        "Circuit capacity, protection and suitable wiring",
        "Only the wall color",
        "Only the appliance brand",
        "Only the switch shape"
      ],
      "answer": 0,
      "visual": "🏠"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A light flickers when a nearby heavy load starts. What should you investigate?",
      "options": [
        "Supply connections and circuit loading",
        "The paint on the ceiling",
        "The room temperature only",
        "The light bulb color"
      ],
      "answer": 0,
      "visual": "💡"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A multimeter is being used to measure voltage across a live circuit. Which setting is appropriate?",
      "options": [
        "Voltage measurement with correct range and leads",
        "Current range across the supply",
        "Resistance mode on the live circuit",
        "Continuity mode on the live circuit"
      ],
      "answer": 0,
      "visual": "📏"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A customer reports one socket has no output while another socket on the same circuit works. What is a sensible diagnostic step?",
      "options": [
        "Check the socket, terminals and upstream connection safely",
        "Replace the whole meter immediately",
        "Increase the supply frequency",
        "Disconnect the earthing system"
      ],
      "answer": 0,
      "visual": "🔌"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "What is the main purpose of a fuse or circuit breaker?",
      "options": [
        "Protect the circuit from excessive current",
        "Increase voltage",
        "Store electricity",
        "Improve Wi-Fi"
      ],
      "answer": 0,
      "visual": "🛡️"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "What does a watt measure?",
      "options": [
        "Electrical power",
        "Electrical resistance",
        "Cable length",
        "Frequency only"
      ],
      "answer": 0,
      "visual": "📐"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Before working on a circuit, what should the electrician do first?",
      "options": [
        "Isolate the supply and verify it is dead",
        "Touch the conductor to test it",
        "Work faster without checking",
        "Remove the warning label"
      ],
      "answer": 0,
      "visual": "⚠️"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A wet floor is present near an electrical repair. What is safest?",
      "options": [
        "Stop and make the area dry/safe before work",
        "Continue wearing normal shoes",
        "Spray more water to find the fault",
        "Use a metal ladder"
      ],
      "answer": 0,
      "visual": "💧"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "You see damaged insulation on a cable. What should you do?",
      "options": [
        "Isolate it and repair/replace it appropriately",
        "Wrap it with paper",
        "Leave it exposed",
        "Touch it to check heat"
      ],
      "answer": 0,
      "visual": "🚧"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A customer asks you to bypass a repeatedly tripping protective device. What should you do?",
      "options": [
        "Do not bypass it; find the underlying fault",
        "Bypass it temporarily",
        "Fit a much larger device without checking",
        "Ask the customer to hold the wire"
      ],
      "answer": 0,
      "visual": "🛑"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A colleague starts work without PPE in a potentially hazardous area. What is appropriate?",
      "options": [
        "Stop and correct the safety procedure before work continues",
        "Ignore it",
        "Remove the PPE from others",
        "Speed up the job"
      ],
      "answer": 0,
      "visual": "🦺"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "You smell burning from a distribution board. What should happen?",
      "options": [
        "Isolate safely if possible and investigate the source",
        "Open it with bare hands immediately",
        "Pour water on it",
        "Keep resetting the breaker"
      ],
      "answer": 0,
      "visual": "🔥"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "What does PPE stand for?",
      "options": [
        "Personal Protective Equipment",
        "Power Protection Energy",
        "Professional Power Equipment",
        "Personal Plumbing Equipment"
      ],
      "answer": 0,
      "visual": "🦺"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Why is electrical isolation important before maintenance?",
      "options": [
        "It reduces the risk of electric shock and unintended energization",
        "It makes tools heavier",
        "It increases voltage",
        "It improves lighting"
      ],
      "answer": 0,
      "visual": "🔒"
    }
  ],
  "plumber": [
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A kitchen tap is dripping continuously after being closed. What is a likely first check?",
      "options": [
        "Inspect the washer/cartridge and valve condition",
        "Replace the water meter",
        "Increase water pressure",
        "Break the wall"
      ],
      "answer": 0,
      "visual": "🚰"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A sink drains very slowly but is not completely blocked. What is a sensible first action?",
      "options": [
        "Inspect and clear the trap/drain blockage",
        "Increase the pipe length",
        "Close the main valve permanently",
        "Paint the drain"
      ],
      "answer": 0,
      "visual": "🪠"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A toilet cistern keeps filling after the tank is full. What should you inspect?",
      "options": [
        "The fill valve/float mechanism",
        "The bathroom light switch",
        "The floor tiles",
        "The exhaust fan"
      ],
      "answer": 0,
      "visual": "🚽"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A joint on a water pipe is leaking. What is the first practical step?",
      "options": [
        "Isolate water and inspect the joint/seal",
        "Increase water pressure",
        "Cover it with paper",
        "Ignore the leak"
      ],
      "answer": 0,
      "visual": "🔧"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A shower has very low flow while other taps work normally. What should you check?",
      "options": [
        "The shower head, local valve and supply path",
        "The electrical meter",
        "The roof paint",
        "The door lock"
      ],
      "answer": 0,
      "visual": "🚿"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A customer reports water hammer when a tap closes quickly. What should you investigate?",
      "options": [
        "Pipe supports, pressure and appropriate water-hammer control",
        "The bathroom color",
        "The electricity bill",
        "The window glass"
      ],
      "answer": 0,
      "visual": "💧"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A drain smells bad even though it is flowing. What is a sensible check?",
      "options": [
        "Trap/seal condition and drain cleanliness",
        "Increase the pipe diameter without inspection",
        "Remove the trap permanently",
        "Add electrical tape"
      ],
      "answer": 0,
      "visual": "🌊"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A concealed pipe is suspected of leaking. What should you do before breaking the wall?",
      "options": [
        "Confirm the leak using appropriate inspection/testing first",
        "Immediately break the whole wall",
        "Increase water pressure greatly",
        "Turn off every electrical appliance"
      ],
      "answer": 0,
      "visual": "🏠"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "Two fixtures lose pressure when used together. What should you consider?",
      "options": [
        "Pipe sizing, supply pressure and shared-line restrictions",
        "Only the tap color",
        "The room's light level",
        "The customer's phone model"
      ],
      "answer": 0,
      "visual": "📐"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A new water heater is being connected. What should be checked?",
      "options": [
        "Correct plumbing connections, valves and manufacturer requirements",
        "Only the wall paint",
        "Only the shower head",
        "Only the room fan"
      ],
      "answer": 0,
      "visual": "♨️"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "What is the main purpose of a P-trap?",
      "options": [
        "Maintain a water seal that helps prevent sewer gases entering",
        "Increase electrical current",
        "Store drinking water permanently",
        "Increase pipe temperature"
      ],
      "answer": 0,
      "visual": "🔩"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "What is water pressure commonly measured in?",
      "options": [
        "Bar or psi",
        "Watts only",
        "Ohms only",
        "Kilograms per meter only"
      ],
      "answer": 0,
      "visual": "📏"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A pipe repair area is flooded. What should happen before work starts?",
      "options": [
        "Control the water and make the work area safe",
        "Work while standing in the water",
        "Use damaged electrical tools",
        "Ignore the flooding"
      ],
      "answer": 0,
      "visual": "⚠️"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A chemical drain cleaner is present at a job. What should the plumber do?",
      "options": [
        "Follow the product safety instructions and use appropriate PPE",
        "Mix it with another cleaner",
        "Touch it with bare hands",
        "Store it in an unlabeled bottle"
      ],
      "answer": 0,
      "visual": "🧪"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A heavy pipe is being moved. What is safest?",
      "options": [
        "Use proper lifting technique or assistance/equipment",
        "Lift it alone regardless of weight",
        "Throw it across the room",
        "Carry it over another worker"
      ],
      "answer": 0,
      "visual": "🏗️"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A worker needs to enter a potentially hazardous confined space. What should happen?",
      "options": [
        "Follow the required confined-space procedure and authorization",
        "Enter immediately alone",
        "Use a phone flashlight only",
        "Remove all ventilation"
      ],
      "answer": 0,
      "visual": "🚧"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "Hot water is suspected in a pipe being opened. What should you do?",
      "options": [
        "Isolate, relieve pressure and verify safe temperature before opening",
        "Open it quickly with bare hands",
        "Increase the temperature",
        "Stand directly in front of the outlet"
      ],
      "answer": 0,
      "visual": "♨️"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A ladder is needed near a wet area. What should you verify?",
      "options": [
        "Stable footing and a safe work position",
        "Only the ladder color",
        "That the ladder is wet",
        "That someone pushes it while climbing"
      ],
      "answer": 0,
      "visual": "🪜"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Why should protective gloves be selected appropriately for plumbing work?",
      "options": [
        "To reduce exposure to cuts, contaminants and other hazards",
        "To increase water pressure",
        "To make pipes longer",
        "To replace all other safety controls"
      ],
      "answer": 0,
      "visual": "🧤"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "What should be done with a damaged hand tool?",
      "options": [
        "Remove it from service and replace/repair it appropriately",
        "Keep using it carefully",
        "Hide the damage",
        "Give it to another worker"
      ],
      "answer": 0,
      "visual": "🛠️"
    }
  ],
  "carpenter": [
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A cabinet door does not close evenly. What should the carpenter check first?",
      "options": [
        "Alignment and hinge adjustment",
        "The electrical meter",
        "The water pressure",
        "The room temperature only"
      ],
      "answer": 0,
      "visual": "🚪"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A shelf is sagging in the middle. What is a sensible fix?",
      "options": [
        "Check span/load and provide adequate support or stronger material",
        "Remove all screws",
        "Add water to the wood",
        "Paint the shelf only"
      ],
      "answer": 0,
      "visual": "🪵"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A cut line is marked on timber. What should be done before cutting?",
      "options": [
        "Measure and verify the mark",
        "Cut immediately without checking",
        "Wet the timber",
        "Remove the safety guard"
      ],
      "answer": 0,
      "visual": "📏"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A drawer sticks while opening. What should you inspect?",
      "options": [
        "Drawer alignment and runner clearance",
        "The plumbing valve",
        "The circuit breaker",
        "The ceiling fan"
      ],
      "answer": 0,
      "visual": "🗄️"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A wooden joint has a small gap. What should you check?",
      "options": [
        "Joint fit, dimensions and suitable adhesive/fastener method",
        "The water meter",
        "The room light",
        "The doorbell"
      ],
      "answer": 0,
      "visual": "🪚"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A large panel is being installed and appears slightly out of square. What should you do?",
      "options": [
        "Measure diagonals and correct alignment before fixing permanently",
        "Force it into place with excessive force",
        "Ignore the measurement",
        "Cut randomly"
      ],
      "answer": 0,
      "visual": "📐"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A wall-mounted shelf will carry books. What should be considered before installation?",
      "options": [
        "Wall type, fixing method, load and shelf capacity",
        "Only the shelf color",
        "Only the book color",
        "Only the room size"
      ],
      "answer": 0,
      "visual": "📚"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A wooden door rubs against the frame at one corner. What is a good first step?",
      "options": [
        "Check hinges, frame alignment and clearance",
        "Remove the entire frame immediately",
        "Add water to the door",
        "Hammer the corner without inspection"
      ],
      "answer": 0,
      "visual": "🚪"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A power tool produces an uneven cut. What should be checked?",
      "options": [
        "Blade condition, setup, guide and material support",
        "Only the tool color",
        "Only the workshop lights",
        "The water supply"
      ],
      "answer": 0,
      "visual": "🪚"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A table wobbles after assembly. What should you check?",
      "options": [
        "Joint tightness, leg lengths and level surface",
        "The electrical fuse",
        "The bathroom drain",
        "The wall paint"
      ],
      "answer": 0,
      "visual": "🪑"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "What is a common purpose of a spirit level?",
      "options": [
        "Checking whether a surface is level/plumb",
        "Measuring electrical current",
        "Measuring water pressure",
        "Cutting timber"
      ],
      "answer": 0,
      "visual": "📏"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "Why are pilot holes used before some screw fixing?",
      "options": [
        "They can reduce splitting and help guide the screw",
        "They increase wood moisture",
        "They replace the screw",
        "They make timber softer"
      ],
      "answer": 0,
      "visual": "🔩"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A power saw has a damaged guard. What should you do?",
      "options": [
        "Do not use it until the guard is properly repaired/replaced",
        "Remove the guard and continue",
        "Hold the blade by hand",
        "Increase the cutting speed"
      ],
      "answer": 0,
      "visual": "⚠️"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Wood dust is building up during cutting. What is appropriate?",
      "options": [
        "Use suitable dust control/ventilation and PPE",
        "Blow dust toward other workers",
        "Ignore it",
        "Use water on an electrical saw"
      ],
      "answer": 0,
      "visual": "😷"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A timber board is unstable while cutting. What should happen?",
      "options": [
        "Secure/support the workpiece before cutting",
        "Hold it against the blade",
        "Ask someone to hold it near the blade",
        "Cut faster"
      ],
      "answer": 0,
      "visual": "🪵"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A nail is protruding from a board. What should you do?",
      "options": [
        "Remove or safely secure it before handling/installation",
        "Hit it toward your hand",
        "Ignore it",
        "Cover it with paper"
      ],
      "answer": 0,
      "visual": "🔨"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A worker is using a loud power tool for an extended period. What is appropriate?",
      "options": [
        "Use hearing protection and follow safe operating procedures",
        "Work without protection",
        "Put headphones over the tool",
        "Increase the noise"
      ],
      "answer": 0,
      "visual": "🎧"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A ladder is placed on an uneven surface to reach a high cabinet. What should happen?",
      "options": [
        "Reposition it on stable, level footing or use suitable access equipment",
        "Climb anyway",
        "Ask someone to shake it",
        "Stand on the top edge"
      ],
      "answer": 0,
      "visual": "🪜"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Why are safety glasses useful during cutting/drilling?",
      "options": [
        "They help protect eyes from flying particles",
        "They improve wood strength",
        "They reduce water pressure",
        "They replace machine guards"
      ],
      "answer": 0,
      "visual": "🥽"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "What should be done before changing a power-tool blade?",
      "options": [
        "Switch off/isolate the tool and follow the manufacturer's procedure",
        "Change it while running",
        "Hold the trigger down",
        "Ask someone to start the tool"
      ],
      "answer": 0,
      "visual": "🔒"
    }
  ],
  "housekeeping": [
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A customer asks for a bathroom to be cleaned. What should be done first?",
      "options": [
        "Assess the area and identify suitable cleaning products/tools",
        "Mix every chemical together",
        "Start spraying without checking surfaces",
        "Turn off all building power"
      ],
      "answer": 0,
      "visual": "🧹"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A glass surface has streaks after cleaning. What is a sensible improvement?",
      "options": [
        "Use the appropriate glass-cleaning method and a clean lint-free tool",
        "Add more random chemicals",
        "Scratch the glass",
        "Use sandpaper"
      ],
      "answer": 0,
      "visual": "🪟"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A floor has a visible wet patch after mopping. What should happen?",
      "options": [
        "Control the area and allow it to dry safely",
        "Leave it without warning",
        "Add more water",
        "Polish it with electrical equipment"
      ],
      "answer": 0,
      "visual": "🧼"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A customer has a wooden floor. Which approach is generally appropriate?",
      "options": [
        "Use a product and method suitable for the wood finish",
        "Flood the floor with water",
        "Use abrasive powder everywhere",
        "Use bleach without checking"
      ],
      "answer": 0,
      "visual": "🪵"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Easy",
      "text": "A vacuum loses suction. What should you check?",
      "options": [
        "Bag/bin, filter and hose for blockage",
        "The wall switch only",
        "The water heater",
        "The window lock"
      ],
      "answer": 0,
      "visual": "🧹"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A cleaning product label says it should not be used on a particular surface. What should you do?",
      "options": [
        "Use a compatible product/method instead",
        "Use it anyway",
        "Mix it with another chemical",
        "Dilute it without reading instructions"
      ],
      "answer": 0,
      "visual": "🧴"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A large room has several cleaning tasks. What is a sensible sequence?",
      "options": [
        "Plan the tasks, work systematically and avoid re-soiling cleaned areas",
        "Randomly repeat the same area",
        "Start with the dirtiest item and throw tools around",
        "Skip inspection"
      ],
      "answer": 0,
      "visual": "🗂️"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A customer reports a persistent odor after cleaning. What should you investigate?",
      "options": [
        "Source of odor, ventilation and appropriate cleaning method",
        "Add perfume only",
        "Close all ventilation",
        "Mix multiple chemicals"
      ],
      "answer": 0,
      "visual": "🌬️"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A fabric sofa needs cleaning. What should be checked before applying a product?",
      "options": [
        "Fabric care instructions and product compatibility",
        "Only the sofa color",
        "The room's electrical voltage",
        "The water meter"
      ],
      "answer": 0,
      "visual": "🛋️"
    },
    {
      "type": "scenario",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "A stain remains after the first cleaning attempt. What is appropriate?",
      "options": [
        "Identify the stain/surface and use an appropriate approved method",
        "Scrub harder without checking",
        "Use every available chemical",
        "Cut the fabric"
      ],
      "answer": 0,
      "visual": "🧽"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "Why is cleaning from cleaner areas toward dirtier areas often useful?",
      "options": [
        "It helps reduce transfer of dirt back onto cleaned surfaces",
        "It increases dust",
        "It makes chemicals stronger",
        "It removes the need for PPE"
      ],
      "answer": 0,
      "visual": "🧼"
    },
    {
      "type": "theory",
      "domain": "Technical",
      "difficulty": "Moderate",
      "text": "What is dilution?",
      "options": [
        "Mixing a concentrated product with the specified amount of another liquid",
        "Heating every chemical",
        "Freezing a cleaner",
        "Mixing all products together"
      ],
      "answer": 0,
      "visual": "🧴"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A chemical cleaner is being used. What should you check first?",
      "options": [
        "The label/instructions and required PPE",
        "Only the smell",
        "Whether it looks colorful",
        "Whether another chemical is nearby"
      ],
      "answer": 0,
      "visual": "🧪"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "A floor is wet in a walkway. What should you do?",
      "options": [
        "Place a warning sign/control access and dry it safely",
        "Leave it without warning",
        "Ask people to run across",
        "Add more water"
      ],
      "answer": 0,
      "visual": "⚠️"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Two cleaning chemicals are available. Can they be mixed freely?",
      "options": [
        "No; only mix products when the instructions explicitly allow it",
        "Yes, always",
        "Only if both smell pleasant",
        "Yes, to make them stronger"
      ],
      "answer": 0,
      "visual": "🧪"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A cleaning task is above normal reach. What is safest?",
      "options": [
        "Use suitable access equipment and follow safe access procedures",
        "Stand on an unstable chair",
        "Climb furniture",
        "Ask the customer to hold the chair"
      ],
      "answer": 0,
      "visual": "🪜"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A sharp broken item is found during cleaning. What should happen?",
      "options": [
        "Isolate it and handle/dispose of it using an appropriate safe method",
        "Pick it up with bare hands",
        "Hide it under a rug",
        "Kick it away"
      ],
      "answer": 0,
      "visual": "🧤"
    },
    {
      "type": "scenario",
      "domain": "Safety",
      "difficulty": "Moderate",
      "text": "A worker feels dizzy after using a cleaning product. What should they do?",
      "options": [
        "Stop, move to fresh air if safe and follow the product/emergency guidance",
        "Continue working faster",
        "Mix another product",
        "Ignore the symptoms"
      ],
      "answer": 0,
      "visual": "🌬️"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "Why is hand hygiene important after cleaning work?",
      "options": [
        "It reduces transfer of contaminants and residues",
        "It increases chemical strength",
        "It replaces all PPE",
        "It makes surfaces dry"
      ],
      "answer": 0,
      "visual": "🧼"
    },
    {
      "type": "theory",
      "domain": "Safety",
      "difficulty": "Easy",
      "text": "What should be done with an unlabeled chemical container?",
      "options": [
        "Do not use it until its contents are safely identified and properly labeled",
        "Use it carefully",
        "Mix it with water immediately",
        "Give it to a customer"
      ],
      "answer": 0,
      "visual": "🏷️"
    }
  ]
};

const professions=[['plumber','Plumber','🔧'],['electrician','Electrician','⚡'],['carpenter','Carpenter','🪚'],['housekeeping','House Keeping','🧹']];
const c=await pool.connect();
try{await c.query('BEGIN');
for(const [slug,name,icon] of professions){const p=(await c.query(`INSERT INTO assessment.professions(slug,name,icon) VALUES($1,$2,$3) ON CONFLICT(slug) DO UPDATE SET name=EXCLUDED.name,icon=EXCLUDED.icon RETURNING id`,[slug,name,icon])).rows[0];
 await c.query('DELETE FROM assessment.questions WHERE profession_id=$1',[p.id]);
 for(let i=0;i<QUESTION_BANK[slug].length;i++){const q=QUESTION_BANK[slug][i];const qr=(await c.query(`INSERT INTO assessment.questions(profession_id,question_number,type,domain,difficulty,text,visual) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,[p.id,i+1,q.type,q.domain,q.difficulty,q.text,q.visual])).rows[0]; for(let j=0;j<q.options.length;j++) await c.query(`INSERT INTO assessment.options(question_id,option_index,option_text,is_correct) VALUES($1,$2,$3,$4)`,[qr.id,j,q.options[j],j===q.answer]);}}
const hash=await bcrypt.hash('DemoWorker@123',12); await c.query(`INSERT INTO assessment.users(name,email,password_hash,role) VALUES('Demo Worker','worker@example.com',$1,'worker') ON CONFLICT(email) DO NOTHING`,[hash]); const adminHash=await bcrypt.hash('Admin@123456',12); await c.query(`INSERT INTO assessment.users(name,email,password_hash,role) VALUES('Assessment Admin','admin@example.com',$1,'admin') ON CONFLICT(email) DO NOTHING`,[adminHash]);
await c.query('COMMIT'); console.log('Seeded professions, 80 questions, options and demo worker.');}catch(e){await c.query('ROLLBACK');console.error(e);process.exitCode=1;}finally{c.release();await pool.end();}
