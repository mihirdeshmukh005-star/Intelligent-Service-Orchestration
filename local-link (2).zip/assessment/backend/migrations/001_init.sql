CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE SCHEMA IF NOT EXISTS assessment;
CREATE SCHEMA IF NOT EXISTS assessment_media;

CREATE TABLE IF NOT EXISTS assessment.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'worker' CHECK (role IN ('worker','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assessment.professions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE,
  icon TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assessment_media.images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  byte_size INTEGER NOT NULL CHECK (byte_size >= 0),
  data BYTEA NOT NULL,
  alt_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assessment.questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  profession_id UUID NOT NULL REFERENCES assessment.professions(id) ON DELETE CASCADE,
  question_number INTEGER NOT NULL CHECK (question_number > 0),
  type TEXT NOT NULL CHECK (type IN ('scenario','theory')),
  domain TEXT NOT NULL CHECK (domain IN ('Technical','Safety')),
  difficulty TEXT NOT NULL CHECK (difficulty IN ('Easy','Moderate')),
  text TEXT NOT NULL,
  visual TEXT,
  image_id UUID REFERENCES assessment_media.images(id) ON DELETE SET NULL,
  UNIQUE(profession_id, question_number)
);

CREATE TABLE IF NOT EXISTS assessment.options (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id UUID NOT NULL REFERENCES assessment.questions(id) ON DELETE CASCADE,
  option_index SMALLINT NOT NULL CHECK (option_index BETWEEN 0 AND 25),
  option_text TEXT NOT NULL,
  is_correct BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE(question_id, option_index)
);

CREATE UNIQUE INDEX IF NOT EXISTS one_correct_option_per_question
  ON assessment.options(question_id) WHERE is_correct;

CREATE TABLE IF NOT EXISTS assessment.attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES assessment.users(id) ON DELETE CASCADE,
  profession_id UUID NOT NULL REFERENCES assessment.professions(id),
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  deadline_at TIMESTAMPTZ NOT NULL,
  submitted_at TIMESTAMPTZ,
  submit_reason TEXT CHECK (submit_reason IN ('manual','timeout')),
  status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress','submitted')),
  current_question_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS one_active_attempt_per_user_profession
  ON assessment.attempts(user_id, profession_id) WHERE status='in_progress';

CREATE TABLE IF NOT EXISTS assessment.attempt_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID NOT NULL REFERENCES assessment.attempts(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES assessment.questions(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'not_visited' CHECK (status IN ('not_visited','visited','answered')),
  visited BOOLEAN NOT NULL DEFAULT FALSE,
  visited_at TIMESTAMPTZ,
  selected_option_id UUID REFERENCES assessment.options(id) ON DELETE RESTRICT,
  answered_at TIMESTAMPTZ,
  UNIQUE(attempt_id, question_id)
);

CREATE TABLE IF NOT EXISTS assessment.answers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attempt_id UUID NOT NULL REFERENCES assessment.attempts(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES assessment.questions(id) ON DELETE RESTRICT,
  option_id UUID NOT NULL REFERENCES assessment.options(id) ON DELETE RESTRICT,
  selected_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(attempt_id, question_id)
);

CREATE TABLE IF NOT EXISTS assessment.events (
  id BIGSERIAL PRIMARY KEY,
  attempt_id UUID NOT NULL REFERENCES assessment.attempts(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  question_id UUID REFERENCES assessment.questions(id) ON DELETE SET NULL,
  metadata_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_questions_profession ON assessment.questions(profession_id, question_number);
CREATE INDEX IF NOT EXISTS idx_attempt_questions_attempt ON assessment.attempt_questions(attempt_id);
CREATE INDEX IF NOT EXISTS idx_answers_attempt ON assessment.answers(attempt_id);
CREATE INDEX IF NOT EXISTS idx_events_attempt ON assessment.events(attempt_id, created_at);
