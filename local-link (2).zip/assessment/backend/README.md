# Local Link Assessment Backend — PostgreSQL

Backend for the uploaded Local Link Professional Assessment UI. It uses PostgreSQL for **all assessment state**. No JSON files are used for application persistence.

## Source assessment preserved
- Plumber, Electrician, Carpenter, House Keeping
- 20 questions per profession
- 12 Technical / 8 Safety
- 14 scenario / 6 theory
- 20-minute limit
- Early submit + automatic submit at zero
- Current / attempted / visited-unanswered / not-visited state
- Final score, correct, incorrect, attempted, unanswered

## PostgreSQL model
- `assessment` schema: users, professions, questions, options, attempts, attempt_questions, answers, events
- `assessment_media` schema: images stored as PostgreSQL `BYTEA` with MIME type and metadata
- Attempt state is relational: current question + per-question status + selected option are stored in PostgreSQL.
- No JSON/JSONB persistence is used; API responses may of course be JSON because they are HTTP responses.

The server never stores question/answer state in local JSON.

## Setup
1. Create PostgreSQL database `local_link`.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and `JWT_SECRET`.
3. `npm install`
4. `npm run migrate`
5. `npm run seed`
6. `npm start`

## API
- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/professions`
- `GET /api/professions/:slug/questions` (never exposes correct answers)
- `POST /api/attempts` start an attempt
- `GET /api/attempts/:id` current server state including palette state
- `PUT /api/attempts/:id/questions/:questionId/visit` mark visited
- `PUT /api/attempts/:id/questions/:questionId/answer` save selected option
- `POST /api/attempts/:id/submit` submit early
- `GET /api/attempts/:id/result` final result after submission
- `PUT /api/attempts/:id/current-question` persist current question
- `POST /api/admin/images` admin image upload
- `PUT /api/admin/questions/:questionId/image/:imageId` attach image to a question
- `GET /api/images/:id` serve stored image

Demo accounts after seed:
- Worker: `worker@example.com` / `DemoWorker@123`
- Admin: `admin@example.com` / `Admin@123456`

Every answer write is transactional and uses row locks. The server calculates the authoritative score from PostgreSQL; clients cannot submit a score.

## Test
`npm test` runs unit tests that do not require a live database. For live integration, run the migration/seed steps and exercise the API with Postman.
