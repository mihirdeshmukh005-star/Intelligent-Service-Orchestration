import test from 'node:test'; import assert from 'node:assert/strict';
test('assessment contract constants',()=>{assert.equal(20,20); assert.equal(20*60,1200);});
test('no JSON persistence paths are used',async()=>{const fs=await import('node:fs/promises');const text=await fs.readFile(new URL('../src/app.mjs',import.meta.url),'utf8');assert.equal(text.includes('writeFile'),false);assert.equal(text.includes('JSON.stringify'),false);});
