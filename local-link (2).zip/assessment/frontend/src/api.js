// Assessment Frontend -> Assessment Backend connector
const API = (import.meta.env.VITE_API_URL ?? '/svc/assessment').replace(/\/$/, '');
// ---- Login bridge: tokens come from the Local Link login session (cookie), never from passwords in the browser ----
async function bridge(app) {
  const res = await fetch(`/api/bridge/token?app=${app}`, { credentials: 'same-origin' });
  const j = await res.json().catch(() => ({}));
  if (res.status === 401) { location.replace('/'); throw new Error('Please log in.'); }
  if (res.status === 403 && j.error === 'ASSESSMENT_REQUIRED') { location.replace('/assessment/'); throw new Error(j.message); }
  if (res.status === 403) { location.replace('/'); throw new Error(j.message); }
  if (!res.ok) throw new Error(j.message || 'Could not start your session.');
  return j;
}
export async function signOut() {
  try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch {}
  location.replace('/');
}



let token = null;
let passedBefore = false;
export const alreadyPassed = () => passedBefore;

async function call(path, { method = 'GET', body, auth = true } = {}, retry = true) {
  if (auth && !token) await login();
  const headers = { 'Content-Type': 'application/json' };
  if (auth && token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(API + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const json = await res.json().catch(() => ({}));
  if (res.status === 401 && auth && retry) { token = null; return call(path, { method, body, auth }, false); }
  if (!res.ok) throw new Error(json.error || `Request failed (${res.status})`);
  return json;
}

export async function login() {
  const j = await bridge('assessment');
  token = j.token; passedBefore = !!j.passed;
  return j;
}

export const getProfessions = () => call('/api/professions', { auth: false });
export const getQuestions = slug => call(`/api/professions/${slug}/questions`, { auth: false });
export const createAttempt = professionId => call('/api/attempts', { method: 'POST', body: { professionId } });
export const getAttempt = id => call(`/api/attempts/${id}`);
export const visit = (id, qid) => call(`/api/attempts/${id}/questions/${qid}/visit`, { method: 'PUT' });
export const answer = (id, qid, optionId) => call(`/api/attempts/${id}/questions/${qid}/answer`, { method: 'PUT', body: { optionId } });
export const setCurrent = (id, questionId) => call(`/api/attempts/${id}/current-question`, { method: 'PUT', body: { questionId } });
export const submit = id => call(`/api/attempts/${id}/submit`, { method: 'POST' });
export const getResult = id => call(`/api/attempts/${id}/result`);
