
import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import * as api from "./api.js";

const PROFESSIONS = [
  { id: "plumber", label: "Plumber", icon: "🔧", tone: "blue" },
  { id: "electrician", label: "Electrician", icon: "⚡", tone: "amber" },
  { id: "carpenter", label: "Carpenter", icon: "🪚", tone: "brown" },
  { id: "housekeeping", label: "House Keeping", icon: "🧹", tone: "green" }
];

function App() {
  const [profession, setProfession] = useState("");
  const [started, setStarted] = useState(false);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [visited, setVisited] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(20 * 60);
  const [list, setList] = useState([]);
  const [attemptId, setAttemptId] = useState(null);
  const [deadline, setDeadline] = useState(0);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Already passed earlier? Go straight to the worker console.
  useEffect(() => { api.login().then((j) => { if (j.passed) location.replace("/worker/"); }).catch(() => {}); }, []);

  useEffect(() => {
    if (!started || submitted || !deadline) return;
    const tick = () => {
      const left = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      setTimeLeft(left);
      if (left === 0) { clearInterval(timer); finish(); }
    };
    const timer = setInterval(tick, 1000);
    tick();
    return () => clearInterval(timer);
  }, [started, submitted, deadline]);

  useEffect(() => {
    if (started && !submitted && attemptId && list[current]) {
      setVisited((v) => ({ ...v, [current]: true }));
      api.visit(attemptId, list[current].id).catch(() => {});
      api.setCurrent(attemptId, list[current].id).catch(() => {});
    }
  }, [started, submitted, current, attemptId]);

  const start = async (selectedProfession = profession) => {
    if (!selectedProfession || loading) return;
    setLoading(true); setError("");
    try {
      const profs = await api.getProfessions();
      const prof = profs.find((x) => x.slug === selectedProfession);
      if (!prof) throw new Error("Profession not found");
      let created = await api.createAttempt(prof.id);
      let state = await api.getAttempt(created.id);
      if (state.attempt.status === "submitted") { created = await api.createAttempt(prof.id); state = await api.getAttempt(created.id); }
      const raw = await api.getQuestions(selectedProfession);
      const qs = raw.map((r) => ({ id: r.id, type: r.type, domain: r.domain, difficulty: r.difficulty, text: r.text, visual: r.visual || "", options: r.options.map((o) => o.text), optionIds: r.options.map((o) => o.id) }));
      const ans = {}, vis = {}; let cur = 0;
      state.questions.forEach((sq, i) => {
        const qi = qs.findIndex((x) => x.id === sq.question_id);
        if (qi < 0) return;
        if (sq.visited) vis[qi] = true;
        if (sq.selected_option_id) ans[qi] = qs[qi].optionIds.indexOf(sq.selected_option_id);
        if (sq.current) cur = qi;
      });
      vis[cur] = true;
      setList(qs); setAttemptId(created.id); setAnswers(ans); setVisited(vis); setCurrent(cur);
      setDeadline(new Date(state.attempt.deadline_at).getTime());
      setTimeLeft(Math.max(0, Math.ceil((new Date(state.attempt.deadline_at).getTime() - Date.now()) / 1000)));
      setResult(null); setSubmitted(false); setStarted(true);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const finish = async () => {
    if (!attemptId) return;
    try {
      await api.submit(attemptId);
      setResult(await api.getResult(attemptId));
      setSubmitted(true);
    } catch (e) { setError(e.message); }
  };

  const choose = (index) => {
    if (submitted || timeLeft <= 0) return;
    setAnswers((a) => ({ ...a, [current]: index }));
    api.answer(attemptId, list[current].id, list[current].optionIds[index]).catch((e) => setError(e.message));
  };

  const manualSubmit = () => {
    if (!submitted && timeLeft > 0) finish();
  };

  const reset = () => {
    setProfession("");
    setResult(null); setAttemptId(null); setList([]); setDeadline(0);
    setStarted(false);
    setSubmitted(false);
    setCurrent(0);
    setAnswers({});
    setVisited({});
    setTimeLeft(20 * 60);
  };

  const score = result ? result.score : 0;
  const attempted = result ? result.attempted : Object.keys(answers).length;
  const percentage = result ? result.percentage : 0;
  const passed = result ? result.passed : false;

  const formatTime = (seconds) => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  const statusOf = (i) => {
    if (i === current && !submitted) return "current";
    if (answers[i] !== undefined) return "answered";
    if (visited[i]) return "visited";
    return "not-visited";
  };

  if (!profession) {
    return (
      <div className="page selection-page">
        <header className="topbar">
          <div className="brand"><span className="brand-pin">●</span> Local Link</div>
        </header>
        <main className="selection-wrap">
          <div className="intro">
            <span className="eyebrow">PROFESSIONAL VERIFICATION</span>
            <h1>Select your profession</h1>
            <p>Select a profession to begin its 20-question assessment.</p>
          </div>

          <div className="profession-grid">
            {PROFESSIONS.map((p) => (
              <button
                key={p.id}
                className={`profession-card ${profession === p.id ? "selected" : ""}`}
                onClick={() => { setProfession(p.id); start(p.id); }}
              >
                <span className={`profession-icon ${p.tone}`}>{p.icon}</span>
                <span className="profession-name">{p.label}</span>
                <span className="profession-meta">20-question assessment</span>
              </button>
            ))}
          </div>

          <div className="selection-footer">
            <div className="test-rule"><span>20</span> Questions &nbsp;•&nbsp; <span>20:00</span> Time Limit</div>
            <button className="start-btn" disabled={!profession || loading} onClick={start}>{loading ? "Starting…" : "Start Test →"}</button>
          </div>
        </main>
      </div>
    );
  }

  if (!started) {
    const p = PROFESSIONS.find((x) => x.id === profession);
    return (
      <div className="page selection-page">
        <header className="topbar">
          <div className="brand"><span className="brand-pin">●</span> Local Link</div>
        </header>
        <main className="prestart">
          <div className="pre-card">
            <div className={`large-icon ${p.tone}`}>{p.icon}</div>
            <span className="eyebrow">SELECTED PROFESSION</span>
            <h1>{p.label}</h1>
            <p>20 MCQs • 20 minutes • submit anytime before the timer reaches zero.</p>
            {error && <p style={{color:"#d92d20",fontSize:14}}>{error}</p>}
            <button className="start-btn" disabled={loading} onClick={start}>{loading ? "Starting…" : "Start Test"}</button>
            <button className="text-btn" onClick={() => setProfession("")}>Change Profession</button>
          </div>
        </main>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="page result-page">
        <header className="topbar">
          <div className="brand"><span className="brand-pin">●</span> Local Link</div>
          <div className="result-tag">Assessment Submitted</div>
        </header>
        <main className="result-wrap">
          <section className="result-card">
            <div className={`result-ring ${passed ? "pass" : "fail"}`}>
              <strong>{percentage}%</strong>
              <span>{score}/{list.length}</span>
            </div>
            <span className="eyebrow">FINAL RESULT</span>
            <h1>{passed ? "Assessment Completed" : "Assessment Completed"}</h1>
            <p className="result-message">
              {result?.submitReason === "timeout"
                ? "The 20-minute time limit ended, so the test was automatically submitted."
                : "Your test was submitted successfully before the time limit."}
            </p>

            <div className="result-stats">
              <div><strong>{score}</strong><span>Correct</span></div>
              <div><strong>{attempted}</strong><span>Attempted</span></div>
              <div><strong>{list.length - attempted}</strong><span>Unanswered</span></div>
              <div><strong>{list.length - score}</strong><span>Incorrect</span></div>
            </div>

            <div className="answer-key">
              <h2>Answer Summary</h2>
              <div className="answer-list">
                {result.answers.map((item, i) => (
                  <div className={`answer-row ${item.selected_index === item.correct_index ? "correct" : "wrong"}`} key={i}>
                    <span>Q{i + 1}</span>
                    <span>{item.selected_index === null ? "Not attempted" : item.selected_index === item.correct_index ? "Correct" : "Incorrect"}</span>
                    <span>Correct answer: {String.fromCharCode(65 + item.correct_index)}</span>
                  </div>
                ))}
              </div>
            </div>

            {passed && <a className="start-btn" href="/worker/" style={{display:"inline-block",textDecoration:"none",textAlign:"center",marginBottom:12}}>Continue to Worker Console →</a>}
            <button className="start-btn" onClick={reset}>Back to Profession Selection</button>
          </section>
        </main>
      </div>
    );
  }

  const item = list[current];
  const progress = ((current + 1) / list.length) * 100;

  return (
    <div className="page exam-page">
      <header className="exam-header">
        <div className="brand"><span className="brand-pin">●</span> Local Link</div>
        <div className="exam-title">
          <span>{PROFESSIONS.find((p) => p.id === profession)?.label}</span>
          <b>Professional Assessment</b>
        </div>
        <div className={`timer ${timeLeft <= 120 ? "danger" : ""}`}>
          <span>TIME LEFT</span>
          <strong>{formatTime(timeLeft)}</strong>
        </div>
      </header>

      {error && <div style={{background:"#fef3f2",color:"#b42318",padding:"8px 16px",fontSize:14}}>{error}</div>}
      <div className="progress-line"><span style={{width: `${progress}%`}} /></div>

      <main className="exam-layout">
        <section className="question-area">
          <div className="question-top">
            <div>
              <span className="question-number">Question {current + 1} of {list.length}</span>
              <span className={`domain-badge ${item.domain.toLowerCase()}`}>{item.domain}</span>
              <span className="scenario-badge">{item.type === "scenario" ? "Scenario" : "Theory"}</span>
            </div>
            <span className="saved-note">{answers[current] !== undefined ? "Answer selected" : "Not answered"}</span>
          </div>

          <article className="question-card">
            <div className="visual">{item.visual}</div>
            <h2>{item.text}</h2>
            <div className="options">
              {item.options.map((option, i) => (
                <button
                  key={option}
                  className={`option ${answers[current] === i ? "chosen" : ""}`}
                  disabled={submitted || timeLeft <= 0}
                  onClick={() => choose(i)}
                >
                  <span className="option-letter">{String.fromCharCode(65 + i)}</span>
                  <span>{option}</span>
                </button>
              ))}
            </div>
          </article>

          <div className="exam-actions">
            <button className="secondary-btn" disabled={current === 0 || submitted || timeLeft <= 0} onClick={() => setCurrent((c) => Math.max(0, c - 1))}>← Previous</button>
            <button className="submit-btn" disabled={submitted || timeLeft <= 0} onClick={manualSubmit}>Submit Test</button>
            <button className="primary-btn" disabled={current === list.length - 1 || submitted || timeLeft <= 0} onClick={() => setCurrent((c) => Math.min(list.length - 1, c + 1))}>Next →</button>
          </div>
        </section>

        <aside className="palette">
          <div className="palette-head">
            <h2>Question Palette</h2>
            <span>{attempted}/{list.length} attempted</span>
          </div>

          <div className="legend">
            <Legend color="current" label="Current question" />
            <Legend color="answered" label="Attempted" />
            <Legend color="visited" label="Visited, not answered" />
            <Legend color="not-visited" label="Not visited" />
          </div>

          <div className="numbers">
            {list.map((_, i) => (
              <button
                key={i}
                className={`q-number ${statusOf(i)}`}
                onClick={() => setCurrent(i)}
              >
                {i + 1}
              </button>
            ))}
          </div>

          <div className="palette-info">
            <strong>20 Questions • 20 Minutes</strong>
            <span>Submit anytime before the timer ends.</span>
          </div>
        </aside>
      </main>
    </div>
  );
}

function Legend({color, label}) {
  return <div className="legend-item"><i className={color}></i><span>{label}</span></div>;
}

createRoot(document.getElementById("root")).render(<App />);
