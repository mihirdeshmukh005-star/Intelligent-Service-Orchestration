# Local Link — Professional Assessment (Final)

A clean React/Vite assessment-only interface for Local Link.

## Flow

1. Select exactly one profession:
   - Plumber
   - Electrician
   - Carpenter
   - House Keeping
2. Click **Start Test**.
3. A 20-question assessment starts with a 20-minute timer.
4. Questions can be answered, revisited, or left unanswered.
5. The test can be submitted at any time before the timer ends.
6. At 00:00 the test automatically submits and all answer controls are disabled.
7. A final result/answer summary is displayed.

## Question structure

- 20 questions per profession
- 12 Technical (60%)
- 8 Safety (40%)
- 14 scenario-based
- 6 theory-based
- No difficult questions are included.
- Technical questions use easy/moderate difficulty only.
- Every question has exactly one correct answer.

## Question palette

- Blue: current question
- Green: attempted
- Amber: visited but not answered
- Gray: not visited

## Run

```bash
npm install
npm run dev
```

Then open the Vite localhost URL.

## Build

```bash
npm run build
```

The project intentionally contains only the requested assessment flow and result screen; no dashboard, booking, map, worker console, email, or other unrelated features are included.
