export default { base: '/assessment/' };
