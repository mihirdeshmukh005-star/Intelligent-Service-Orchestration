// Server-side sessions. The browser only holds a random, unguessable token in an HttpOnly cookie;
// PostgreSQL holds its SHA-256 plus expiry/idle info, so sessions can be revoked at any time.
const crypto = require('crypto');
const config = require('./config');
const db = require('./db');
const { sha256 } = require('./security/crypto');
const { ua } = require('./security/audit');

// "__Host-" prefix (production) = browser refuses the cookie unless it is Secure, Path=/ and has no Domain attribute.
const COOKIE = config.isProd ? '__Host-ll_sid' : 'll_sid';
const cookieOpts = () => ({ httpOnly: true, sameSite: 'strict', secure: config.isProd, path: '/' });
const TOKEN_RE = /^[A-Za-z0-9_-]{43}$/;

const dashboardFor = (role) => (role === 'PROFESSIONAL' ? '/dashboard/professional' : '/dashboard/customer');

const publicUser = (u) => ({
  id: u.id, name: u.name, email: u.email, role: u.role,
  profession: u.profession, phone: u.phone || null, emailVerified: u.email_verified, lastLogin: u.last_login,
});

/** Creates a brand-new session (a fresh token on every login, so session fixation is impossible). */
async function startSession(req, res, user) {
  const token = crypto.randomBytes(32).toString('base64url');
  await db.query(
    `INSERT INTO sessions (user_id, token_hash, ip, user_agent, expires_at)
     VALUES ($1, $2, $3, $4, NOW() + make_interval(days => $5))`,
    [user.id, sha256(token), req.ip || null, ua(req), config.sessionDays]);
  // keep only the newest N sessions per user
  await db.query(
    `DELETE FROM sessions WHERE user_id = $1 AND id NOT IN
       (SELECT id FROM sessions WHERE user_id = $1 ORDER BY created_at DESC LIMIT $2)`,
    [user.id, config.maxSessionsPerUser]);
  res.cookie(COOKIE, token, { ...cookieOpts(), maxAge: config.sessionDays * 86400000 });
}

async function endSession(req, res) {
  const token = req.cookies && req.cookies[COOKIE];
  if (typeof token === 'string' && TOKEN_RE.test(token)) await db.query('DELETE FROM sessions WHERE token_hash = $1', [sha256(token)]);
  res.clearCookie(COOKIE, cookieOpts());
}

const endAllSessions = (userId) => db.query('DELETE FROM sessions WHERE user_id = $1', [userId]);

/** Returns the logged-in user (fresh from the database) or null. */
async function currentUser(req) {
  const token = req.cookies && req.cookies[COOKIE];
  if (typeof token !== 'string' || !TOKEN_RE.test(token)) return null;
  const r = await db.query(
    `SELECT u.*, s.id AS session_id FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = $1 AND s.expires_at > NOW()
       AND s.last_seen_at > NOW() - make_interval(hours => $2) AND u.email_verified`,
    [sha256(token), config.sessionIdleHours]);
  const user = r.rows[0];
  if (!user) return null;
  db.query("UPDATE sessions SET last_seen_at = NOW() WHERE id = $1 AND last_seen_at < NOW() - INTERVAL '1 minute'", [user.session_id]).catch(() => {});
  return user;
}

module.exports = { startSession, endSession, endAllSessions, currentUser, dashboardFor, publicUser };
