const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const config = require('./config');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: config.dbSsl ? { rejectUnauthorized: false } : undefined,
});
pool.on('error', (err) => console.error('Unexpected database error:', err.message));

async function initSchema() {
  await pool.query(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
}

module.exports = { pool, query: (...a) => pool.query(...a), initSchema };
