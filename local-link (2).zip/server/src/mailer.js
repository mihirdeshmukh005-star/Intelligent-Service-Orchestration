const nodemailer = require('nodemailer');

const API_URL = process.env.RESEND_API_URL || 'https://api.resend.com/emails';
let transport;

function smtpTransport(){
  if(!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  if(!transport){
    transport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: String(process.env.SMTP_SECURE) === 'true',
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
  }
  return transport;
}

async function smtp(m){
  const t=smtpTransport();
  if(!t) return null;
  await t.sendMail({
    from: process.env.SMTP_FROM || process.env.MAIL_FROM_EMAIL || process.env.SMTP_USER,
    to: m.to, subject: m.subject, html: m.html, text: m.text
  });
  return {delivered:true,provider:'smtp'};
}

async function resend(m){
  const r=await fetch(API_URL,{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'content-type':'application/json'},body:JSON.stringify({from:process.env.MAIL_FROM_EMAIL,to:[m.to],subject:m.subject,html:m.html,text:m.text}),signal:AbortSignal.timeout(10000)});
  if(!r.ok)throw new Error(`Resend ${r.status}: ${(await r.text()).slice(0,300)}`);
  return {delivered:true,provider:'resend'};
}

async function sendMail(m){
  if(process.env.DEV_EMAIL_MODE==='true' && !process.env.SMTP_HOST && !process.env.RESEND_API_KEY){
    console.log(`\n[LOCAL LINK DEV EMAIL] to=${m.to}\n${m.text}\n`);
    return {delivered:false,devMode:true,provider:'dev'};
  }
  // Prefer explicitly configured SMTP. This allows Gmail SMTP without any Resend domain.
  if(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS){
    return smtp(m);
  }
  if(process.env.RESEND_API_KEY && process.env.RESEND_API_KEY!=='your_key_here' && process.env.MAIL_FROM_EMAIL){
    return resend(m);
  }
  throw new Error('No email provider configured. Set SMTP_HOST, SMTP_USER, SMTP_PASS (recommended) or Resend settings.');
}

async function sendOtpEmail(to,otp){
  const text=`Your Local Link verification OTP is: ${otp}. This OTP expires in 5 minutes.`;
  const html=`<div style="font-family:Arial;padding:24px"><h2>Local Link</h2><p>Your verification OTP is:</p><p style="font-size:32px;font-weight:700;letter-spacing:6px">${otp}</p><p>This OTP expires in 5 minutes.</p></div>`;
  return sendMail({to,subject:'Your Local Link verification OTP',text,html});
}

module.exports={sendOtpEmail,sendMail};
