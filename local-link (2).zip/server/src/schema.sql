-- Local Link authentication schema (PostgreSQL). Safe to run repeatedly.

CREATE TABLE IF NOT EXISTS users (
  id              BIGSERIAL    PRIMARY KEY,
  name            VARCHAR(80)  NOT NULL,
  email           VARCHAR(254) NOT NULL,
  password_hash   TEXT         NOT NULL,
  role            VARCHAR(12)  NOT NULL CHECK (role IN ('CUSTOMER', 'PROFESSIONAL')),
  profession      VARCHAR(40),
  email_verified  BOOLEAN      NOT NULL DEFAULT FALSE,
  phone           VARCHAR(30),
  last_login      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  -- profession is stored for professionals only
  CONSTRAINT users_profession_chk CHECK (
    (role = 'PROFESSIONAL' AND profession IS NOT NULL) OR
    (role = 'CUSTOMER'     AND profession IS NULL)
  )
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_uq ON users (LOWER(email));

ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(30);

-- One row per OTP that was emailed. Only a keyed hash of the code is stored.
CREATE TABLE IF NOT EXISTS email_otps (
  id                BIGSERIAL    PRIMARY KEY,
  email             VARCHAR(254) NOT NULL,
  otp_hash          TEXT         NOT NULL,
  expires_at        TIMESTAMPTZ  NOT NULL,
  attempts          INTEGER      NOT NULL DEFAULT 0,
  verified_at       TIMESTAMPTZ,
  verify_token_hash TEXT,
  consumed_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS email_otps_email_idx ON email_otps (email, created_at DESC);

-- ---------------------------------------------------------------------------
-- Security tables
-- ---------------------------------------------------------------------------

-- Server-side sessions: the cookie holds a random token, only its SHA-256 is stored.
-- Logging out (or "log out everywhere") really invalidates the session.
CREATE TABLE IF NOT EXISTS sessions (
  id           BIGSERIAL    PRIMARY KEY,
  user_id      BIGINT       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   TEXT         NOT NULL UNIQUE,
  ip           TEXT,
  user_agent   VARCHAR(200),
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  expires_at   TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions (user_id);

-- One row per login attempt (keyed by a keyed hash of the email, so unknown emails are throttled
-- exactly like real ones and raw emails are not kept). Rows are deleted on a successful login.
CREATE TABLE IF NOT EXISTS login_attempts (
  id         BIGSERIAL   PRIMARY KEY,
  email_hash TEXT        NOT NULL,
  ip         TEXT        NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS login_attempts_email_idx ON login_attempts (email_hash, created_at DESC);
CREATE INDEX IF NOT EXISTS login_attempts_ip_idx    ON login_attempts (ip, created_at DESC);

-- Security audit trail (who/what/when/where). No secrets are ever stored here.
CREATE TABLE IF NOT EXISTS auth_events (
  id         BIGSERIAL    PRIMARY KEY,
  user_id    BIGINT       REFERENCES users(id) ON DELETE SET NULL,
  email_hash TEXT,
  event      VARCHAR(40)  NOT NULL,
  ip         TEXT,
  user_agent VARCHAR(200),
  created_at TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS auth_events_user_idx ON auth_events (user_id, created_at DESC);
