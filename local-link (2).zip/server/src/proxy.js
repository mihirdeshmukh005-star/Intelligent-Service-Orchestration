// Tiny reverse proxy: /svc/<name>/... -> the internal backend for that app (no extra dependency).
// The browser only ever talks to this one server, so the login cookie and all apps share one origin.
const http = require('http');

const HOP = new Set(['connection', 'keep-alive', 'transfer-encoding', 'upgrade', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailer']);

function proxyTo(port) {
  return (req, res) => {
    const headers = { ...req.headers, host: `127.0.0.1:${port}`, 'x-forwarded-for': req.ip || '' };
    // The login session cookie must never reach the app backends; they only accept their own bearer tokens.
    delete headers.cookie; delete headers.origin; delete headers.referer;
    const up = http.request({ host: '127.0.0.1', port, method: req.method, path: req.url, headers }, (ur) => {
      const out = {};
      for (const [k, v] of Object.entries(ur.headers)) if (!HOP.has(k) && !k.startsWith('access-control-')) out[k] = v;
      res.writeHead(ur.statusCode, out);
      ur.pipe(res);
    });
    up.on('error', () => {
      if (res.headersSent) return res.end();
      res.status(502).json({ error: 'SERVICE_UNAVAILABLE', message: 'This part of Local Link is starting or unavailable. Please try again in a moment.' });
    });
    req.pipe(up);
  };
}

module.exports = { proxyTo };
