// Bridge: turns the verified login session into a short-lived token for ONE of the app backends.
// Login stays the only place where people sign in; the apps never see passwords or the session cookie.
const crypto = require('crypto');
const express = require('express');
const config = require('./config');
const db = require('./db');
const { HttpError } = require('./errors');
const { currentUser } = require('./session');

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
function signJwt(payload, secret, ttlSeconds) {
  const now = Math.floor(Date.now() / 1000);
  const head = b64({ alg: 'HS256', typ: 'JWT' });
  const body = b64({ ...payload, iat: now, exp: now + ttlSeconds });
  const sig = crypto.createHmac('sha256', secret).update(`${head}.${body}`).digest('base64url');
  return `${head}.${body}.${sig}`;
}
const UNUSABLE = '!login-bridge'; // never matches a bcrypt hash: these rows can only be reached through the bridge

/** Has this person passed the assessment (>= pass mark) in at least one submitted attempt? */
async function hasPassedAssessment(email) {
  try {
    const r = await db.query(
      `SELECT COUNT(*)::int AS total, COUNT(*) FILTER (WHERE aq.selected_option_id = co.id)::int AS score
         FROM assessment.users u
         JOIN assessment.attempts a ON a.user_id = u.id AND a.status = 'submitted'
         JOIN assessment.attempt_questions aq ON aq.attempt_id = a.id
         JOIN assessment.options co ON co.question_id = aq.question_id AND co.is_correct
        WHERE LOWER(u.email) = $1
        GROUP BY a.id`, [email]);
    return r.rows.some((x) => x.total > 0 && x.score * 100 >= config.assessmentPassPercent * x.total);
  } catch (e) { return false; } // assessment tables not created yet
}

const APPS = {
  async customer(user) {
    if (user.role !== 'CUSTOMER') throw new HttpError(403, 'WRONG_ROLE', 'This area is for customers.');
    const email = user.email.toLowerCase();
    let row = (await db.query('SELECT id FROM customers WHERE LOWER(email) = $1 LIMIT 1', [email])).rows[0];
    if (!row) {
      row = (await db.query('INSERT INTO customers (id, name, email, phone, password_hash) VALUES ($1,$2,$3,$4,$5) RETURNING id',
        [`customer_login_${user.id}`, user.name, email, user.phone || null, UNUSABLE])).rows[0];
    } else {
      await db.query('UPDATE customers SET name=$2,phone=$3,updated_at=NOW() WHERE id=$1',[row.id,user.name,user.phone||null]);
    }
    const token = signJwt({ sub: row.id, role: 'customer', name: user.name, email }, config.jwtSecret, 25 * 60);
    return { token, passed: null };
  },
  async assessment(user) {
    if (user.role !== 'PROFESSIONAL') throw new HttpError(403, 'WRONG_ROLE', 'This area is for service professionals.');
    const email = user.email.toLowerCase();
    const row = (await db.query(
      `INSERT INTO assessment.users (name, email, password_hash, role) VALUES ($1,$2,$3,'worker')
       ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name RETURNING id, role`, [user.name, email, UNUSABLE])).rows[0];
    const token = signJwt({ id: row.id, email, role: row.role }, config.jwtSecret, 25 * 60);
    return { token, passed: await hasPassedAssessment(email) };
  },
  async worker(user) {
    if (user.role !== 'PROFESSIONAL') throw new HttpError(403, 'WRONG_ROLE', 'This area is for service professionals.');
    const email = user.email.toLowerCase();
    if (!(await hasPassedAssessment(email))) {
      throw new HttpError(403, 'ASSESSMENT_REQUIRED', `Pass the assessment (${config.assessmentPassPercent}% or more) to open the worker console.`);
    }
    // Passing the assessment is what unlocks the worker backend (verified + assessment_passed).
    const customerWorker = (await db.query('SELECT id, profession FROM workers WHERE LOWER(email)=$1 LIMIT 1',[email])).rows[0];
    const workerId = customerWorker?.id || `wrk_login_${user.id}`;
    if (!customerWorker) {
      await db.query(`INSERT INTO workers(id,name,email,password_hash,profession,lat,lng,service_radius_km,rating,reviews,status,available,availability,response_rate,completion_rate,punctuality,professionalism,safety,success_rate,jobs_completed,price_range,verif_identity,verif_credential,verif_assessment,verif_authorization,verif_eligible)
        VALUES($1,$2,$3,$4,$5,20.0059,73.7904,5,0,0,'active',TRUE,$6::text[],0,0,0,0,0,0,0,'Set by professional',TRUE,TRUE,TRUE,'platform-assessment',TRUE)
        ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,email=EXCLUDED.email,profession=EXCLUDED.profession,verif_assessment=TRUE,verif_eligible=TRUE,updated_at=NOW()`,
        [workerId,user.name,email,UNUSABLE,user.profession,Array.from({length:17},(_,i)=>`${String(i+6).padStart(2,'0')}:00–${String(i+7).padStart(2,'0')}`)]);
    }
    const row = (await db.query(
      `INSERT INTO worker_profiles (id, user_id, name, email, password_hash, role, services, verified, assessment_passed, active)
       VALUES ($1,$2,$3,$4,$5,'worker',$6::jsonb,TRUE,TRUE,TRUE)
       ON CONFLICT (email) DO UPDATE SET id=EXCLUDED.id,name=EXCLUDED.name,services=EXCLUDED.services,verified=TRUE,assessment_passed=TRUE,active=TRUE,updated_at=NOW(),user_id=COALESCE(worker_profiles.user_id,EXCLUDED.user_id)
       RETURNING id`,
      [workerId, String(user.id), user.name, email, UNUSABLE, JSON.stringify([String(user.profession || customerWorker?.profession || '').toLowerCase()])])).rows[0];
    const token = signJwt({ sub: row.id, role: 'worker', type: 'access' }, config.workerAccessSecret, 14 * 60);
    return { token, passed: true };
  },
};

const router = express.Router();
router.get('/token', (req, res, next) => (async () => {
  const user = await currentUser(req);
  if (!user) throw new HttpError(401, 'NOT_AUTHENTICATED', 'Please log in.');
  const make = APPS[String(req.query.app || '')];
  if (!make) throw new HttpError(400, 'UNKNOWN_APP', 'Unknown app.');
  let out;
  try { out = await make(user); } catch (e) {
    if (e instanceof HttpError) throw e;
    console.error('Bridge error:', e.message);
    throw new HttpError(503, 'SERVICE_NOT_READY', 'That part of Local Link is not ready yet. Please try again in a moment.');
  }
  res.json({ token: out.token, passed: out.passed, user: { id: user.id, name: user.name, email: user.email, role: user.role, profession: user.profession } });
})().catch(next));

module.exports = router;
