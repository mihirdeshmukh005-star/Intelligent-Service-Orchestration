// Brute-force protection for /login, stored in PostgreSQL (survives restarts, shared across instances).
//   per account : 5 failures / 15 min  -> locked until the 5th-newest failure is 15 min old
//                 10 failures / 60 min -> locked until the 10th-newest failure is 60 min old
//   per IP      : 30 failures / 15 min -> blocked (shields against one machine trying many accounts)
// Accounts are keyed by hash(email) whether or not the account exists, so responses never reveal which emails are registered.
const db = require('../db');
const { emailHash } = require('./crypto');

const ACCOUNT_SHORT = { limit: 5, windowS: 15 * 60 };
const ACCOUNT_LONG = { limit: 10, windowS: 60 * 60 };
const IP_LIMIT = { limit: 30, windowS: 15 * 60 };

const ages = async (client, col, value, windowS, limit) => (await client.query(
  `SELECT EXTRACT(EPOCH FROM (NOW() - created_at))::float AS age FROM login_attempts
   WHERE ${col} = $1 AND created_at > NOW() - make_interval(secs => $2) ORDER BY created_at DESC LIMIT $3`,
  [value, windowS, limit])).rows.map((r) => r.age);

/**
 * Atomically: check lock state, and if allowed, record the attempt BEFORE the password is checked,
 * so a burst of parallel guesses is counted immediately. Returns { locked, retryAfter, attemptId }.
 * Call clearFailures() after a successful login.
 */
async function beginAttempt(email, ip) {
  const key = emailHash(email);
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [key]);   // serialise attempts per account
    const e = await ages(client, 'email_hash', key, ACCOUNT_LONG.windowS, ACCOUNT_LONG.limit);
    let wait = 0;
    if (e.length >= ACCOUNT_SHORT.limit && e[ACCOUNT_SHORT.limit - 1] < ACCOUNT_SHORT.windowS) {
      wait = Math.max(wait, ACCOUNT_SHORT.windowS - e[ACCOUNT_SHORT.limit - 1]);
    }
    if (e.length >= ACCOUNT_LONG.limit) wait = Math.max(wait, ACCOUNT_LONG.windowS - e[ACCOUNT_LONG.limit - 1]);
    const i = await ages(client, 'ip', ip, IP_LIMIT.windowS, IP_LIMIT.limit);
    if (i.length >= IP_LIMIT.limit) wait = Math.max(wait, IP_LIMIT.windowS - i[IP_LIMIT.limit - 1]);
    if (wait > 0) { await client.query('COMMIT'); return { locked: true, retryAfter: Math.ceil(wait) }; }
    const ins = await client.query('INSERT INTO login_attempts (email_hash, ip) VALUES ($1, $2) RETURNING id', [key, ip]);
    await client.query('COMMIT');
    return { locked: false, attemptId: ins.rows[0].id };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally { client.release(); }
}

const clearFailures = (email) => db.query('DELETE FROM login_attempts WHERE email_hash = $1', [emailHash(email)]);

module.exports = { beginAttempt, clearFailures };
