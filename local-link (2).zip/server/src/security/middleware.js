const config = require('../config');
const { HttpError } = require('../errors');

const SAFE = new Set(['GET', 'HEAD', 'OPTIONS']);
const extraOrigins = (process.env.CLIENT_ORIGIN || '').split(',').map((o) => o.trim()).filter(Boolean);

/** Never let browsers/proxies cache API responses (they can contain personal data). */
function noStore(req, res, next) { res.set('Cache-Control', 'no-store'); next(); }

/**
 * CSRF defence for state-changing requests (in addition to SameSite=Strict cookies):
 *   1. Content-Type must be application/json (a cross-site HTML <form> cannot send that without a CORS pre-flight)
 *   2. Origin header, when present, must be our own site
 *   3. Fetch-Metadata: browsers say whether the request came from another site; reject cross-site
 */
function csrfGuard(req, res, next) {
  if (SAFE.has(req.method)) return next();
  if (!req.is('application/json')) return next(new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Requests must be sent as JSON.'));

  const origin = req.get('origin');
  let originTrusted = false;
  if (origin) {
    originTrusted = extraOrigins.includes(origin);
    try {
      const u = new URL(origin);
      originTrusted = originTrusted || u.host === req.get('host') || (!config.isProd && ['localhost', '127.0.0.1'].includes(u.hostname));
    } catch (_) { /* invalid Origin header */ }
    if (!originTrusted) return next(new HttpError(403, 'BAD_ORIGIN', 'Request blocked.'));
  }
  const site = req.get('sec-fetch-site');
  if (site && !originTrusted && !['same-origin', 'none'].includes(site)) {
    return next(new HttpError(403, 'CROSS_SITE', 'Request blocked.'));
  }
  next();
}

module.exports = { noStore, csrfGuard };
