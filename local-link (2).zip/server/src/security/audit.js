const db = require('../db');
const { emailHash } = require('./crypto');

const ua = (req) => String(req.get('user-agent') || '').slice(0, 200);

/** Fire-and-forget security audit log; never lets logging break a request. */
function audit(req, event, { userId = null, email = null } = {}) {
  db.query('INSERT INTO auth_events (user_id, email_hash, event, ip, user_agent) VALUES ($1, $2, $3, $4, $5)',
    [userId, email ? emailHash(email) : null, event, req.ip || null, ua(req)]).catch((e) => console.error('audit failed:', e.message));
}
module.exports = { audit, ua };
