const crypto = require('crypto');

const COMMON = new Set(`password password1 password12 password123 passw0rd p@ssw0rd p@ssword qwerty qwerty1 qwerty12 qwerty123 qwertyuiop
letmein welcome welcome1 welcome123 admin admin123 administrator iloveyou monkey dragon football baseball master login abc123 abcd1234
abcdef12 111111 123123 123456 1234567 12345678 123456789 1234567890 12341234 1q2w3e4r 1qaz2wsx zaq12wsx trustno1 sunshine princess
superman batman starwars whatever freedom shadow michael jennifer hunter secret changeme default test1234 locallink`.split(/\s+/));

class PasswordError extends Error {
  constructor(message) { super(message); this.code = 'WEAK_PASSWORD'; }
}

/** Synchronous rules. `context` = { email, name } so a password can't just be the user's own details. */
function checkPassword(pw, context = {}) {
  const fail = (m) => { throw new PasswordError(m); };
  if (typeof pw !== 'string') fail('Please enter a password.');
  if (pw.length < 10) fail('Password must be at least 10 characters.');
  if (Buffer.byteLength(pw) > 72) fail('Password is too long (max 72 bytes).');           // bcrypt silently truncates past 72
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) fail('Password must include at least one letter and one number.');
  if (/^(.)\1+$/.test(pw)) fail('Password cannot be a single repeated character.');
  const lower = pw.toLowerCase();
  const letters = lower.replace(/[^a-z]/g, '');
  if (COMMON.has(lower) || COMMON.has(letters) || /(password|qwerty|letmein|iloveyou|12345678|abcdefg)/.test(lower)) {
    fail('That password is too common. Please choose something less guessable.');
  }
  const local = String(context.email || '').split('@')[0].toLowerCase();
  if (local.length >= 4 && lower.includes(local)) fail('Password must not contain your email name.');
  for (const part of String(context.name || '').toLowerCase().split(/\s+/)) {
    if (part.length >= 4 && lower.includes(part)) fail('Password must not contain your name.');
  }
}

/**
 * Have I Been Pwned "range" API (k-anonymity: only the first 5 chars of the SHA-1 leave this server).
 * Fails OPEN (returns false) on any network problem.
 */
async function isPwned(pw, { fetchImpl = fetch, timeoutMs = 2500 } = {}) {
  try {
    const sha1 = crypto.createHash('sha1').update(pw).digest('hex').toUpperCase();
    const res = await fetchImpl(`https://api.pwnedpasswords.com/range/${sha1.slice(0, 5)}`, {
      headers: { 'Add-Padding': 'true', 'User-Agent': 'local-link-auth' }, signal: AbortSignal.timeout(timeoutMs),
    });
    if (!res.ok) return false;
    const suffix = sha1.slice(5);
    for (const line of (await res.text()).split('\n')) {
      const [s, n] = line.trim().split(':');
      if (s === suffix && Number(n) > 0) return true;
    }
    return false;
  } catch (_) { return false; }
}

async function assertStrongPassword(pw, context, { pwnedCheck = true, fetchImpl } = {}) {
  checkPassword(pw, context);
  if (pwnedCheck && (await isPwned(pw, { fetchImpl }))) {
    throw new PasswordError('This password appeared in a known data breach. Please choose a different one.');
  }
}

module.exports = { checkPassword, assertStrongPassword, isPwned, PasswordError };
