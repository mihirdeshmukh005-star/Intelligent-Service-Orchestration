const crypto = require('crypto');
const config = require('../config');

const sha256 = (v) => crypto.createHash('sha256').update(String(v)).digest('hex');
const safeEqual = (a, b) => {
  const x = Buffer.from(String(a)); const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
// Keyed hashes: separate keys per purpose, all derived from the server secret.
const keyFor = (label) => crypto.createHmac('sha256', config.jwtSecret).update(label).digest();
const OTP_KEY = keyFor('otp-key');
const EMAIL_KEY = keyFor('email-key');
const hashOtp = (email, otp) => crypto.createHmac('sha256', OTP_KEY).update(`${email}:${otp}`).digest('hex');
/** Stable, non-reversible identifier for an email (used in rate-limit + audit tables, so raw emails aren't kept there). */
const emailHash = (email) => crypto.createHmac('sha256', EMAIL_KEY).update(email).digest('hex');

module.exports = { sha256, safeEqual, hashOtp, emailHash };
