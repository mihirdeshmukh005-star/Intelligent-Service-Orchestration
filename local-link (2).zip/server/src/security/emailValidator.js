// "Is this a genuine email address?" in three layers:
//   1. strict syntax (exactly one @, legal local part, real domain with a valid TLD, ASCII only)
//   2. reject disposable / reserved / test domains
//   3. DNS: the domain must actually be able to receive mail (MX, or A/AAAA fallback per RFC 5321)
// The OTP email then proves the *mailbox* is the user's.
const dns = require('dns').promises;

const LOCAL_RE = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
const LABEL_RE = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
const TLD_RE = /^(?:[a-z]{2,24}|xn--[a-z0-9-]{2,59})$/;

// Common throw-away inbox providers. Not exhaustive: extend with EXTRA_BLOCKED_EMAIL_DOMAINS.
const DISPOSABLE = new Set([
  'mailinator.com', 'guerrillamail.com', 'guerrillamail.net', 'guerrillamail.org', 'guerrillamailblock.com',
  'sharklasers.com', 'grr.la', 'spam4.me', '10minutemail.com', '10minutemail.net', '20minutemail.com',
  'tempmail.com', 'temp-mail.org', 'temp-mail.io', 'tempmailo.com', 'tempr.email', 'tmpmail.org', 'tmpmail.net',
  'yopmail.com', 'yopmail.net', 'yopmail.fr', 'trashmail.com', 'trashmail.net', 'trashmail.de', 'getnada.com',
  'nada.email', 'throwawaymail.com', 'maildrop.cc', 'dispostable.com', 'fakeinbox.com', 'mohmal.com',
  'emailondeck.com', 'mintemail.com', 'spamgourmet.com', 'mailnesia.com', 'burnermail.io', 'moakt.com',
  'mytemp.email', 'discard.email', 'discardmail.com', 'getairmail.com', 'mailcatch.com', 'mailnull.com',
  'inboxkitten.com', 'emailfake.com', 'fakemail.net', 'harakirimail.com', 'tempinbox.com', 'owlymail.com',
  'dropmail.me', 'mail.tm', 'internxt.com', 'minuteinbox.com', 'luxusmail.org', 'crazymailing.com',
]);
// Reserved by RFC 2606 / 6761 or obviously fake.
const RESERVED = new Set(['example.com', 'example.org', 'example.net', 'localhost', 'test.com', 'domain.com', 'email.com']);
const RESERVED_TLDS = new Set(['test', 'example', 'invalid', 'local', 'localhost', 'internal', 'lan', 'home', 'corp', 'onion']);

const extra = () => (process.env.EXTRA_BLOCKED_EMAIL_DOMAINS || '').split(',').map((d) => d.trim().toLowerCase()).filter(Boolean);
const inSet = (set, domain) => { for (const d of set) if (domain === d || domain.endsWith(`.${d}`)) return true; return false; };

class EmailError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

/** Normalises and strictly validates syntax. Returns the lower-cased address or throws EmailError. */
function parseEmail(value, { blockDisposable = false } = {}) {
  const bad = (m = 'Please enter a valid email address.') => new EmailError('INVALID_EMAIL', m);
  if (typeof value !== 'string') throw bad();
  const email = value.trim().toLowerCase();
  if (!email || email.length > 254 || !/^[\x21-\x7e]+$/.test(email)) throw bad();   // printable ASCII only: blocks homograph / control-char tricks
  const parts = email.split('@');
  if (parts.length !== 2) throw bad('An email address must contain exactly one "@".');
  const [local, domain] = parts;
  if (!local || local.length > 64 || !LOCAL_RE.test(local)) throw bad('The part before "@" in your email is not valid.');
  if (!domain || domain.length > 253) throw bad('The part after "@" in your email is not valid.');
  const labels = domain.split('.');
  if (labels.length < 2 || !labels.every((l) => LABEL_RE.test(l))) throw bad('The domain in your email (after "@") is not valid.');
  if (!TLD_RE.test(labels[labels.length - 1])) throw bad('The domain ending in your email (like .com) is not valid.');
  if (RESERVED_TLDS.has(labels[labels.length - 1]) || RESERVED.has(domain)) throw bad('Please use your real email address.');
  if (blockDisposable && (inSet(DISPOSABLE, domain) || inSet(new Set(extra()), domain))) {
    throw new EmailError('DISPOSABLE_EMAIL', 'Temporary / disposable email addresses are not allowed. Please use your permanent email.');
  }
  return email;
}

// ---- DNS check (cached; fails OPEN on timeouts so a DNS hiccup never blocks real users) ----
const cache = new Map();                          // domain -> { ok, until }
const TTL_MS = 60 * 60 * 1000;
const UNKNOWN = Symbol('unknown');
const DEFINITIVE = new Set(['ENODATA', 'ENOTFOUND']);

const attempt = (promise, ms = 3000) => {
  let timer;
  const timeout = new Promise((r) => { timer = setTimeout(() => r(UNKNOWN), ms); });
  return Promise.race([promise.catch((e) => (DEFINITIVE.has(e.code) ? [] : UNKNOWN)), timeout]).finally(() => clearTimeout(timer));
};

async function domainCanReceiveMail(domain, resolver = dns) {
  const hit = cache.get(domain);
  if (hit && hit.until > Date.now()) return hit.ok;
  const done = (ok) => { cache.set(domain, { ok, until: Date.now() + TTL_MS }); if (cache.size > 5000) cache.clear(); return ok; };

  const mx = await attempt(resolver.resolveMx(domain));
  if (mx === UNKNOWN) return true;
  if (mx.length) {
    const nullMx = mx.length === 1 && (mx[0].exchange === '' || mx[0].exchange === '.');   // RFC 7505: domain explicitly accepts no mail
    return done(!nullMx);
  }
  for (const fn of ['resolve4', 'resolve6']) {           // RFC 5321 implicit MX
    const a = await attempt(resolver[fn](domain));
    if (a === UNKNOWN) return true;
    if (a.length) return done(true);
  }
  return done(false);
}

/** Full check used when an email is about to receive an OTP / create an account. */
async function assertGenuineEmail(value, { resolver, mxCheck = true } = {}) {
  const email = parseEmail(value, { blockDisposable: true });
  if (mxCheck && !(await domainCanReceiveMail(email.split('@')[1], resolver))) {
    throw new EmailError('EMAIL_DOMAIN_UNREACHABLE', "That email's domain can't receive mail. Please check for typos (for example gmial.com).");
  }
  return email;
}

module.exports = { parseEmail, assertGenuineEmail, domainCanReceiveMail, EmailError, _cache: cache };
