const path = require('path');
const fs = require('fs');
const config = require('./config');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const { HttpError } = require('./errors');
const { noStore, csrfGuard } = require('./security/middleware');
const authRoutes = require('./routes/auth');
const bridgeRoutes = require('./bridge');
const { proxyTo } = require('./proxy');

const app = express();
app.disable('x-powered-by');
// Behind Render/Heroku-style proxy: trust exactly one hop so req.ip (used by every rate limit) is the real client.
if (config.isProd) app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https://*.tile.openstreetmap.org'],   // map tiles used by the customer app
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: config.isProd ? [] : null,
    },
  },
  hsts: { maxAge: 63072000, includeSubDomains: true, preload: true },   // 2 years; only honoured over HTTPS
  referrerPolicy: { policy: 'no-referrer' },
  crossOriginOpenerPolicy: { policy: 'same-origin' },
  crossOriginResourcePolicy: { policy: 'same-origin' },
}));
app.use((req, res, next) => {
  res.set('Permissions-Policy', 'camera=(), microphone=(), payment=(), usb=(), geolocation=(self)');
  next();
});
// App backends (customer / assessment / worker) are reached through this one origin. Mounted BEFORE the JSON parser so bodies stream through untouched.
for (const name of ['customer', 'assessment', 'worker']) app.use(`/svc/${name}`, proxyTo(config.ports[name]));

app.use(express.json({ limit: '10kb', strict: true }));
app.use(cookieParser());

app.use('/api', noStore, csrfGuard);
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 * config.rateLimitScale, standardHeaders: true, legacyHeaders: false,
  message: { error: 'RATE_LIMITED', message: 'Too many requests. Please slow down.' } }));

app.use('/api/auth', authRoutes);
app.use('/api/bridge', bridgeRoutes);
app.use('/api', (req, res) => res.status(404).json({ error: 'NOT_FOUND', message: 'Unknown API route.' }));

// The three app frontends, built with base paths /customer/, /assessment/ and /worker/.
const root = path.join(__dirname, '..', '..');
for (const name of ['customer', 'assessment', 'worker']) {
  const appDist = path.join(root, name, 'frontend', 'dist');
  if (!fs.existsSync(appDist)) continue;
  app.use(`/${name}`, express.static(appDist));
  app.get([`/${name}`, `/${name}/*`], (req, res) => res.sendFile(path.join(appDist, 'index.html')));
}

// Production: serve the built React app (run `npm run build` first).
const dist = path.join(__dirname, '..', '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) {
    if (err.extra && err.extra.retryAfter) res.set('Retry-After', String(err.extra.retryAfter));
    return res.status(err.status).json({ error: err.code, message: err.message, ...err.extra });
  }
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'BAD_JSON', message: 'Invalid request body.' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'TOO_LARGE', message: 'Request body is too large.' });
  console.error(err);
  res.status(500).json({ error: 'SERVER_ERROR', message: 'Something went wrong on our side. Please try again.' });
});

module.exports = app;
