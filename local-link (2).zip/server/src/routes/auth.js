const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const db = require('../db');
const { HttpError } = require('../errors');
const { sendOtpEmail } = require('../mailer');
const { startSession, endSession, endAllSessions, currentUser, dashboardFor, publicUser } = require('../session');
const { sha256, safeEqual, hashOtp } = require('../security/crypto');
const { parseEmail, assertGenuineEmail, EmailError } = require('../security/emailValidator');
const { assertStrongPassword, PasswordError } = require('../security/passwordPolicy');
const { beginAttempt, clearFailures } = require('../security/loginGuard');
const { audit } = require('../security/audit');

const OTP_TTL_MS = 5 * 60 * 1000;          // OTP lifetime
const COOLDOWN_S = 30;                      // minimum gap between two OTP emails
const MAX_ATTEMPTS = 5;                     // wrong guesses allowed per OTP
const MAX_SENDS_PER_HOUR = 5;               // OTP emails per address per hour
const VERIFIED_WINDOW_MS = 15 * 60 * 1000;  // time allowed between verifying and registering
const VERIFY_COOKIE = 'll_verify';
const PROFESSIONS = ['Electrician', 'Plumber', 'Carpenter', 'House Keeping'];

const DUMMY_HASH = bcrypt.hashSync('local-link-dummy-password', 12); // equalises login timing for unknown emails

const verifyCookieOpts = () => ({ httpOnly: true, sameSite: 'strict', secure: config.isProd, path: '/api/auth' });

// Turn validator errors into the API's HttpError shape.
const wrap = (fn) => async (...args) => {
  try { return await fn(...args); } catch (e) {
    if (e instanceof EmailError || e instanceof PasswordError) throw new HttpError(400, e.code, e.message);
    throw e;
  }
};
/** Syntax only (login / verify): the account either exists or it doesn't. */
const lenientEmail = (v) => { try { return parseEmail(v); } catch (e) { throw new HttpError(400, e.code, e.message); } };
/** Full "is this a genuine, permanent mailbox?" check (syntax + disposable + DNS) for sign-up. */
const genuineEmail = wrap((v) => assertGenuineEmail(v, { mxCheck: config.emailMxCheck }));
const strongPassword = wrap((pw, ctx) => assertStrongPassword(pw, ctx, { pwnedCheck: config.pwnedCheck }));
const cleanPhone = (v) => {
  const phone = typeof v === 'string' ? v.trim().replace(/[^0-9+()\-\s]/g, '') : '';
  if (!phone || phone.replace(/\D/g, '').length < 10 || phone.replace(/\D/g, '').length > 15) throw new HttpError(400, 'INVALID_PHONE', 'Please enter a valid phone number.');
  return phone;
};

const cleanName = (v) => {
  const name = typeof v === 'string' ? v.normalize('NFKC').replace(/[\u0000-\u001f\u007f]/g, '').trim().replace(/\s+/g, ' ') : '';
  if (name.length < 2 || name.length > 80 || /[<>]/.test(name)) throw new HttpError(400, 'INVALID_NAME', 'Please enter your name (2–80 characters, without < or >).');
  return name;
};

const limiter = (minutes, limit, message, extra = {}) => rateLimit({
  windowMs: minutes * 60 * 1000, limit: limit * config.rateLimitScale, standardHeaders: true, legacyHeaders: false,
  message: { error: 'RATE_LIMITED', message }, ...extra,
});
const otpLimiter = limiter(15, 15, 'Too many code requests. Please try again in a few minutes.');
const verifyLimiter = limiter(15, 30, 'Too many attempts. Please try again in a few minutes.');
const loginLimiter = limiter(15, 20, 'Too many login attempts. Please try again in a few minutes.', { skipSuccessfulRequests: true });
const registerLimiter = limiter(60, 10, 'Too many sign-up attempts. Please try again later.');

const h = (fn) => (req, res, next) => fn(req, res, next).catch(next);

/** Creates a new OTP, stores only its hash, and emails it using the configured email provider. */
async function issueOtp(req, email, requirePrevious) {
  const existing = await db.query('SELECT 1 FROM users WHERE LOWER(email) = $1', [email]);
  if (existing.rowCount) {
    throw new HttpError(409, 'EMAIL_EXISTS', 'An account with this email already exists. Leave the OTP empty and log in with your password.');
  }
  const last = await db.query(
    'SELECT EXTRACT(EPOCH FROM (NOW() - created_at)) AS age FROM email_otps WHERE email = $1 ORDER BY created_at DESC LIMIT 1', [email]);
  if (requirePrevious && !last.rowCount) {
    throw new HttpError(400, 'NO_PENDING_OTP', 'Please request a code first using the Verify button.');
  }
  if (last.rowCount) {
    const wait = Math.ceil(COOLDOWN_S - Number(last.rows[0].age));
    if (wait > 0) throw new HttpError(429, 'COOLDOWN', `Please wait ${wait}s before requesting another code.`, { retryAfter: wait });
  }
  const sent = await db.query("SELECT COUNT(*)::int AS n FROM email_otps WHERE email = $1 AND created_at > NOW() - INTERVAL '1 hour'", [email]);
  if (sent.rows[0].n >= MAX_SENDS_PER_HOUR) {
    throw new HttpError(429, 'TOO_MANY_CODES', 'Too many codes requested for this email. Please try again in an hour.', { retryAfter: 3600 });
  }

  const otp = String(crypto.randomInt(0, 1000000)).padStart(6, '0'); // cryptographically secure
  await db.query('UPDATE email_otps SET consumed_at = NOW() WHERE email = $1 AND consumed_at IS NULL', [email]);
  const row = await db.query('INSERT INTO email_otps (email, otp_hash, expires_at) VALUES ($1, $2, $3) RETURNING id',
    [email, hashOtp(email, otp), new Date(Date.now() + OTP_TTL_MS)]);
  try {
    await sendOtpEmail(email, otp);
  } catch (err) {
    console.error('Email send failed:', err.message);
    await db.query('DELETE FROM email_otps WHERE id = $1', [row.rows[0].id]);
    throw new HttpError(502, 'EMAIL_SEND_FAILED', 'We could not send the verification email. Please try again.');
  }
  audit(req, 'otp_sent', { email });
  return { sent: true, cooldown: COOLDOWN_S, expiresIn: OTP_TTL_MS / 1000 };
}

const router = express.Router();

router.post('/send-otp', otpLimiter, h(async (req, res) => res.json(await issueOtp(req, await genuineEmail(req.body.email), false))));
router.post('/resend-otp', otpLimiter, h(async (req, res) => res.json(await issueOtp(req, await genuineEmail(req.body.email), true))));

router.post('/verify-otp', verifyLimiter, h(async (req, res) => {
  const email = lenientEmail(req.body.email);
  const otp = typeof req.body.otp === 'string' ? req.body.otp.trim() : '';
  if (!/^\d{6}$/.test(otp)) throw new HttpError(400, 'INVALID_OTP', 'Enter the 6-digit code from your email.');

  const r = await db.query('SELECT * FROM email_otps WHERE email = $1 AND consumed_at IS NULL ORDER BY created_at DESC LIMIT 1', [email]);
  if (!r.rowCount) throw new HttpError(400, 'NO_PENDING_OTP', 'No active code for this email. Please request a new one.');
  const row = r.rows[0];

  if (row.verified_at) { // already verified in this browser? then it's a harmless repeat
    const token = req.cookies[VERIFY_COOKIE];
    if (token && row.verify_token_hash && safeEqual(sha256(token), row.verify_token_hash)) return res.json({ verified: true });
    throw new HttpError(409, 'OTP_ALREADY_USED', 'This code was already used. Please request a new one.');
  }
  if (new Date(row.expires_at) < new Date()) throw new HttpError(400, 'OTP_EXPIRED', 'This code has expired. Please request a new one.');

  // Count the attempt atomically BEFORE comparing, so parallel guesses cannot sneak past the 5-attempt cap.
  const counted = await db.query(
    'UPDATE email_otps SET attempts = attempts + 1 WHERE id = $1 AND attempts < $2 AND verified_at IS NULL RETURNING attempts', [row.id, MAX_ATTEMPTS]);
  if (!counted.rowCount) throw new HttpError(429, 'TOO_MANY_ATTEMPTS', 'Too many incorrect attempts. Please request a new code.');

  if (!safeEqual(hashOtp(email, otp), row.otp_hash)) {
    const left = MAX_ATTEMPTS - counted.rows[0].attempts;
    audit(req, 'otp_failed', { email });
    throw new HttpError(400, 'INVALID_OTP', left > 0
      ? `Incorrect code. ${left} attempt${left === 1 ? '' : 's'} left.`
      : 'Too many incorrect attempts. Please request a new code.');
  }

  // Correct: mark verified and bind that fact to this browser with a one-time token.
  const token = crypto.randomBytes(32).toString('hex');
  await db.query('UPDATE email_otps SET verified_at = NOW(), verify_token_hash = $2 WHERE id = $1', [row.id, sha256(token)]);
  res.cookie(VERIFY_COOKIE, token, { ...verifyCookieOpts(), maxAge: VERIFIED_WINDOW_MS });
  res.json({ verified: true });
}));

router.post('/register', registerLimiter, h(async (req, res) => {
  const email = await genuineEmail(req.body.email);
  const name = cleanName(req.body.name);
  const password = req.body.password;
  const phone = cleanPhone(req.body.phone);
  await strongPassword(password, { email, name });   // throws WEAK_PASSWORD (length, common, breached, contains name/email)
  const role = String(req.body.role || '').toUpperCase();
  if (!['CUSTOMER', 'PROFESSIONAL'].includes(role)) throw new HttpError(400, 'INVALID_ROLE', 'Please choose Customer or Service Professional.');
  let profession = null;
  if (role === 'PROFESSIONAL') {
    profession = PROFESSIONS.find((p) => p.toLowerCase() === String(req.body.profession || '').toLowerCase());
    if (!profession) throw new HttpError(400, 'INVALID_PROFESSION', 'Please select your profession.');
  }

  const client = await db.pool.connect();
  let user;
  try {
    await client.query('BEGIN');
    const o = await client.query(
      'SELECT * FROM email_otps WHERE email = $1 AND consumed_at IS NULL AND verified_at IS NOT NULL ORDER BY created_at DESC LIMIT 1 FOR UPDATE', [email]);
    const row = o.rows[0];
    const token = req.cookies[VERIFY_COOKIE];
    if (!row || !token || !row.verify_token_hash || !safeEqual(sha256(token), row.verify_token_hash)
        || Date.now() - new Date(row.verified_at).getTime() > VERIFIED_WINDOW_MS) {
      throw new HttpError(403, 'EMAIL_NOT_VERIFIED', 'Please verify your email with the OTP first.');
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const u = await client.query(
      `INSERT INTO users (name, email, password_hash, role, profession, phone, email_verified, last_login)
       VALUES ($1, $2, $3, $4, $5, $6, TRUE, NOW()) RETURNING *`, [name, email, passwordHash, role, profession, phone]);
    await client.query('UPDATE email_otps SET consumed_at = NOW() WHERE id = $1', [row.id]);
    await client.query('COMMIT');
    user = u.rows[0];
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    if (err.code === '23505') throw new HttpError(409, 'EMAIL_EXISTS', 'An account with this email already exists. Please log in.');
    throw err;
  } finally {
    client.release();
  }
  res.clearCookie(VERIFY_COOKIE, verifyCookieOpts());
  await startSession(req, res, user);
  audit(req, 'register', { userId: user.id, email });
  res.status(201).json({ user: publicUser(user), redirect: dashboardFor(role) });
}));

router.post('/login', loginLimiter, h(async (req, res) => {
  const email = lenientEmail(req.body.email);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!password) throw new HttpError(400, 'INVALID_CREDENTIALS', 'Please enter your password.');
  if (password.length > 1024) throw new HttpError(400, 'INVALID_CREDENTIALS', 'Invalid email or password.');   // don't hash megabytes

  // Brute-force guard: checked (and the attempt recorded) before touching the password.
  const guard = await beginAttempt(email, req.ip || 'unknown');
  if (guard.locked) {
    audit(req, 'login_locked', { email });
    const mins = Math.ceil(guard.retryAfter / 60);
    throw new HttpError(429, 'TOO_MANY_LOGIN_ATTEMPTS',
      `Too many failed login attempts. Please try again in ${mins} minute${mins === 1 ? '' : 's'}.`, { retryAfter: guard.retryAfter });
  }

  const r = await db.query('SELECT * FROM users WHERE LOWER(email) = $1', [email]);
  const user = r.rows[0];
  const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);   // always runs: same timing for unknown emails
  if (!user || !ok) {
    audit(req, 'login_failed', { userId: user ? user.id : null, email });
    throw new HttpError(401, 'INVALID_CREDENTIALS', 'Invalid email or password.');
  }
  if (!user.email_verified) throw new HttpError(403, 'EMAIL_NOT_VERIFIED', 'Please verify your email before logging in.');

  await clearFailures(email);
  const upd = await db.query('UPDATE users SET last_login = NOW() WHERE id = $1 RETURNING *', [user.id]);
  await startSession(req, res, upd.rows[0]);
  audit(req, 'login_success', { userId: user.id, email });
  res.json({ user: publicUser(upd.rows[0]), redirect: dashboardFor(user.role) });
}));

router.post('/logout', h(async (req, res) => {
  const user = await currentUser(req);
  await endSession(req, res);
  if (user) audit(req, 'logout', { userId: user.id });
  res.json({ ok: true });
}));

// "Log out everywhere": revokes every session of this account (e.g. lost phone, shared computer).
router.post('/logout-all', h(async (req, res) => {
  const user = await currentUser(req);
  if (!user) throw new HttpError(401, 'NOT_AUTHENTICATED', 'Please log in.');
  await endAllSessions(user.id);
  await endSession(req, res);
  audit(req, 'logout_all', { userId: user.id });
  res.json({ ok: true });
}));

router.get('/me', h(async (req, res) => {
  const user = await currentUser(req);
  if (!user) throw new HttpError(401, 'NOT_AUTHENTICATED', 'Please log in.');
  res.json({ user: publicUser(user), redirect: dashboardFor(user.role) });
}));

module.exports = router;
