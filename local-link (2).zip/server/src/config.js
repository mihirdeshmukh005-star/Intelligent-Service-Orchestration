require('dotenv').config();

const hasSmtp = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
const hasResend = Boolean(process.env.RESEND_API_KEY && process.env.RESEND_API_KEY !== 'your_key_here' && process.env.MAIL_FROM_EMAIL);
const missing = ['DATABASE_URL', 'JWT_SECRET'].filter((k) => !process.env[k]);
if (missing.length) {
  console.error(`\nMissing required environment variable(s): ${missing.join(', ')}\nCopy .env.example to .env and fill them in.\n`);
  process.exit(1);
}
const secret = process.env.JWT_SECRET;
if (secret.length < 32 || /^replace-with|changeme|change-me|secret$/i.test(secret)) {
  console.error('\nJWT_SECRET must be a long random value (32+ characters), not the example placeholder.\nGenerate one: node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'base64url\'))"\n');
  process.exit(1);
}

const flag = (name, dflt) => (process.env[name] === undefined ? dflt : process.env[name] !== 'false');

const crypto = require('crypto');
module.exports = {
  // ---- app backends behind this gateway ----
  ports: { customer: Number(process.env.CUSTOMER_PORT) || 5001, assessment: Number(process.env.ASSESSMENT_PORT) || 5002, worker: Number(process.env.WORKER_PORT) || 5003 },
  assessmentPassPercent: Number(process.env.ASSESSMENT_MIN_PASS_PERCENT) || 60,
  workerAccessSecret: process.env.JWT_ACCESS_SECRET || crypto.createHash('sha256').update(secret + ':worker-access').digest('hex'),
  isProd: process.env.NODE_ENV === 'production',
  port: Number(process.env.PORT) || 3000,
  // Server secret. Used to derive the keyed hashes for OTPs and email identifiers (not for browser tokens any more).
  jwtSecret: secret,
  mailFromEmail: process.env.MAIL_FROM_EMAIL || process.env.SMTP_FROM || process.env.SMTP_USER || '',
  mailFromName: process.env.MAIL_FROM_NAME || 'Local Link',
  smtp: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE) === 'true',
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    from: process.env.SMTP_FROM || process.env.MAIL_FROM_EMAIL || process.env.SMTP_USER || ''
  },
  emailProvider: hasSmtp ? 'smtp' : (hasResend ? 'resend' : 'none'),
  dbSsl: process.env.DATABASE_SSL === 'true',
  // ---- security knobs ----
  sessionDays: Number(process.env.SESSION_DAYS) || 7,              // absolute session lifetime
  sessionIdleHours: Number(process.env.SESSION_IDLE_HOURS) || 24,  // logged out after this long without activity
  maxSessionsPerUser: 10,
  emailMxCheck: flag('EMAIL_MX_CHECK', true),                      // DNS check that the email domain can receive mail
  rateLimitScale: Number(process.env.RATE_LIMIT_MULTIPLIER) || 1,    // multiply every per-IP limit (only used by the automated tests)
  pwnedCheck: flag('PWNED_PASSWORD_CHECK', true),                  // reject passwords found in known breaches
};
