process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-0123456789';
process.env.RESEND_API_KEY = 'x'; process.env.MAIL_FROM_EMAIL = 'a@b.co'; process.env.DATABASE_URL = 'postgresql://x';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseEmail, assertGenuineEmail, domainCanReceiveMail, _cache } = require('../src/security/emailValidator');
const { checkPassword, isPwned } = require('../src/security/passwordPolicy');

const bad = (e, opts) => assert.throws(() => parseEmail(e, opts), (x) => x.code === 'INVALID_EMAIL' || x.code === 'DISPOSABLE_EMAIL', `should reject: ${e}`);

test('email: accepts normal addresses and normalises case/whitespace', () => {
  assert.equal(parseEmail('  Asha.Patel+work@Gmail.COM '), 'asha.patel+work@gmail.com');
  assert.equal(parseEmail("o'brien@sub.example-mail.co.in"), "o'brien@sub.example-mail.co.in");
});

test('email: rejects malformed addresses (the "@" rules)', () => {
  for (const e of ['', 'plain', '@gmail.com', 'a@', 'a@@gmail.com', 'a@b@gmail.com', 'a b@gmail.com', 'a@gmail', 'a@gmail.c',
    'a@.gmail.com', 'a@gmail..com', 'a@-gmail.com', 'a@gmail-.com', '.a@gmail.com', 'a.@gmail.com', 'a..b@gmail.com',
    'a@gmail.123', 'a@[127.0.0.1]', 'a@127.0.0.1', 'тест@gmail.com', 'a@gmаil.com', 'a\u0000@gmail.com', 'a<b>@gmail.com',
    `${'x'.repeat(65)}@gmail.com`, `a@${'x'.repeat(64)}.com`, `a@${'x.'.repeat(130)}com`]) bad(e);
  for (const v of [null, undefined, 42, {}, [], ['a@gmail.com']]) bad(v);
});

test('email: rejects reserved/test and disposable domains', () => {
  bad('a@example.com'); bad('a@foo.test'); bad('a@localhost');
  bad('a@mailinator.com', { blockDisposable: true });
  bad('a@sub.mailinator.com', { blockDisposable: true });
  bad('a@YOPMAIL.com', { blockDisposable: true });
  assert.equal(parseEmail('a@mailinator.com'), 'a@mailinator.com');       // lenient mode (login) doesn't block
});

test('email: DNS check - MX, A fallback, null-MX, missing domain, and fail-open', async () => {
  const mk = (o) => ({
    resolveMx: async () => { if (o.mx instanceof Error) throw o.mx; return o.mx; },
    resolve4: async () => { if (o.a instanceof Error) throw o.a; return o.a || []; },
    resolve6: async () => [],
  });
  const nx = Object.assign(new Error('x'), { code: 'ENOTFOUND' });
  const nd = Object.assign(new Error('x'), { code: 'ENODATA' });
  const to = Object.assign(new Error('x'), { code: 'ETIMEOUT' });
  _cache.clear();
  assert.equal(await domainCanReceiveMail('has-mx.com', mk({ mx: [{ exchange: 'mx.has-mx.com', priority: 10 }] })), true);
  assert.equal(await domainCanReceiveMail('a-only.com', mk({ mx: nd, a: ['1.2.3.4'] })), true);
  assert.equal(await domainCanReceiveMail('null-mx.com', mk({ mx: [{ exchange: '', priority: 0 }] })), false);
  assert.equal(await domainCanReceiveMail('gmial.com', mk({ mx: nx, a: nx })), false);
  assert.equal(await domainCanReceiveMail('slow.com', mk({ mx: to })), true, 'DNS outage must not block real users');
  await assert.rejects(assertGenuineEmail('a@typo-domain.com', { resolver: mk({ mx: nx, a: nx }) }), (e) => e.code === 'EMAIL_DOMAIN_UNREACHABLE');
});

test('password: policy', () => {
  const ctx = { email: 'asha.patel@gmail.com', name: 'Asha Patel' };
  const weak = ['short1', 'password123', 'Password1234', 'qwerty12345', '1234567890', 'aaaaaaaaaaaa', 'onlyletterspassword',
    '12345678901', 'MyPassword99', 'asha.patel2024', 'patel-family-1', 'x'.repeat(80) + '1'];
  for (const p of weak) assert.throws(() => checkPassword(p, ctx), (e) => e.code === 'WEAK_PASSWORD', `should reject: ${p.slice(0, 20)}`);
  for (const p of ['Zebra-Lamp-47x', 'correct horse battery 9', 'tR9!vXk2#Lm0']) checkPassword(p, ctx);
});

test('password: breach check uses k-anonymity and fails open', async () => {
  let seen;
  const sha1 = require('crypto').createHash('sha1').update('hunter2hunter2').digest('hex').toUpperCase();
  const f = async (url) => { seen = url; return { ok: true, text: async () => `ABCDEF:3\n${sha1.slice(5)}:42\n` }; };
  assert.equal(await isPwned('hunter2hunter2', { fetchImpl: f }), true);
  assert.equal(seen, `https://api.pwnedpasswords.com/range/${sha1.slice(0, 5)}`);   // only 5 hash chars leave the server
  assert.equal(await isPwned('hunter2hunter2', { fetchImpl: async () => { throw new Error('offline'); } }), false);
  assert.equal(await isPwned('hunter2hunter2', { fetchImpl: async () => ({ ok: false }) }), false);
});
