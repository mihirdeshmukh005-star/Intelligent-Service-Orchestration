const test = require('node:test');
const assert = require('node:assert/strict');
const T = require('./helpers');

let db;
test.before(async () => { ({ db } = await T.start()); });
test.after(async () => { await T.stop(); });

const A = '/api/auth';

test('security headers + no-store on API', async () => {
  const b = T.browser();
  const r = await b.get(`${A}/me`);
  assert.equal(r.status, 401);
  assert.equal(r.headers['cache-control'], 'no-store');
  assert.match(r.headers['content-security-policy'], /frame-ancestors 'none'/);
  assert.match(r.headers['strict-transport-security'], /max-age=\d+/);
  assert.equal(r.headers['x-content-type-options'], 'nosniff');
  assert.equal(r.headers['referrer-policy'], 'no-referrer');
  assert.equal(r.headers['x-powered-by'], undefined);
});

test('CSRF: non-JSON, foreign Origin and cross-site fetch-metadata are rejected', async () => {
  const b = T.browser();
  const email = T.uniqueEmail();
  assert.equal((await b.raw('POST', `${A}/send-otp`, undefined, { 'content-type': 'text/plain' })).status, 415);
  assert.equal((await b.post(`${A}/send-otp`, { email }, { origin: 'https://evil.example' })).status, 403);
  assert.equal((await b.post(`${A}/send-otp`, { email }, { 'sec-fetch-site': 'cross-site' })).status, 403);
  assert.equal((await b.post(`${A}/send-otp`, { email }, { 'sec-fetch-site': 'same-site' })).status, 403);
  assert.equal((await b.post(`${A}/send-otp`, { email }, { 'sec-fetch-site': 'same-origin' })).status, 200);
});

test('malformed bodies never crash the server', async () => {
  const b = T.browser();
  assert.equal((await b.raw('POST', `${A}/login`, undefined, { 'content-type': 'application/json' })).status, 400);
  for (const body of [{}, { email: 5 }, { email: ['a@gmail.com'], password: {} }, { email: 'a@gmail.com', password: 123 }]) {
    const r = await b.post(`${A}/login`, body);
    assert.ok([400, 401].includes(r.status), JSON.stringify(body) + ' -> ' + r.status);
  }
  const big = await b.post(`${A}/login`, { email: 'a@gmail.com', password: 'x'.repeat(20000) });
  assert.equal(big.status, 413);
});

test('send-otp: rejects fake / disposable / malformed emails before anything is emailed', async () => {
  const b = T.browser(); const before = T.mails.length;
  for (const email of ['nope', 'a@@gmail.com', 'a@gmail', 'x@example.com']) {
    const r = await b.post(`${A}/send-otp`, { email });
    assert.equal(r.status, 400, email); assert.equal(r.body.error, 'INVALID_EMAIL');
  }
  const d = await b.post(`${A}/send-otp`, { email: 'x@mailinator.com' });
  assert.equal(d.status, 400); assert.equal(d.body.error, 'DISPOSABLE_EMAIL');
  assert.equal(T.mails.length, before, 'no email may be sent for invalid addresses');
});

test('full sign-up: OTP -> register -> HttpOnly strict session -> /me -> logout invalidates server-side', async () => {
  const b = T.browser();
  const s = await T.signup(b, { role: 'professional', profession: 'Plumber' });
  assert.equal(s.verify.status, 200); assert.equal(s.register.status, 201);
  assert.equal(s.register.body.redirect, '/dashboard/professional');
  const cookie = s.register.setCookie.find((c) => c.startsWith('ll_sid='));
  assert.match(cookie, /HttpOnly/i); assert.match(cookie, /SameSite=Strict/i);
  assert.ok(!JSON.stringify(s.register.body).includes('password'), 'no password hash in responses');
  const token = b.jar.ll_sid;
  assert.equal((await b.get(`${A}/me`)).body.user.email, s.email);
  const stored = await db.query('SELECT token_hash FROM sessions');
  assert.ok(stored.rows.every((r) => r.token_hash !== token), 'raw token is never stored');
  await b.post(`${A}/logout`);
  // replay the stolen cookie after logout: must fail (this was impossible to enforce with the old stateless JWT)
  const replay = T.browser(); replay.jar.ll_sid = token;
  assert.equal((await replay.get(`${A}/me`)).status, 401);
});

test('register is impossible without a verified OTP in the same browser', async () => {
  const a = T.browser(), other = T.browser();
  const email = T.uniqueEmail();
  await a.post(`${A}/send-otp`, { email });
  await a.post(`${A}/verify-otp`, { email, otp: T.lastOtp(email) });
  const r = await other.post(`${A}/register`, { name: 'Mallory Q', phone: '+919999999999', email, password: 'Zebra-Lamp-47x', role: 'customer' });
  assert.equal(r.status, 403); assert.equal(r.body.error, 'EMAIL_NOT_VERIFIED');
});

test('register enforces the password policy and name sanitising', async () => {
  const b = T.browser(); const email = T.uniqueEmail();
  await b.post(`${A}/send-otp`, { email });
  await b.post(`${A}/verify-otp`, { email, otp: T.lastOtp(email) });
  for (const password of ['short1', 'password1234', 'allletterslongenough']) {
    const r = await b.post(`${A}/register`, { name: 'Asha Patel', phone: '+919999999999', email, password, role: 'customer' });
    assert.equal(r.status, 400, password); assert.equal(r.body.error, 'WEAK_PASSWORD');
  }
  assert.equal((await b.post(`${A}/register`, { name: '<script>', phone: '+919999999999', email, password: 'Zebra-Lamp-47x', role: 'customer' })).status, 400);
  const ok = await b.post(`${A}/register`, { name: 'Asha  Patel', phone: '+919999999999', email, password: 'Zebra-Lamp-47x', role: 'customer' });
  assert.equal(ok.status, 201); assert.equal(ok.body.user.name, 'Asha Patel');
});

test('OTP: 5-attempt cap holds even under parallel guessing', async () => {
  const b = T.browser(); const email = T.uniqueEmail();
  await b.post(`${A}/send-otp`, { email });
  const real = T.lastOtp(email);
  const wrong = String((Number(real) + 1) % 1000000).padStart(6, '0');
  const rs = await Promise.all(Array.from({ length: 12 }, () => b.post(`${A}/verify-otp`, { email, otp: wrong })));
  const counted = (await db.query('SELECT attempts FROM email_otps WHERE email=$1', [email])).rows[0].attempts;
  assert.equal(counted, 5, 'exactly 5 guesses may be evaluated');
  assert.equal(rs.filter((r) => r.status === 400).length, 5);
  assert.equal(rs.filter((r) => r.status === 429).length, 7);
  const good = await b.post(`${A}/verify-otp`, { email, otp: real });
  assert.equal(good.status, 429, 'even the right code is refused once the cap is hit');
});

test('OTP: cooldown between sends', async () => {
  const b = T.browser(); const email = T.uniqueEmail();
  assert.equal((await b.post(`${A}/send-otp`, { email })).status, 200);
  const r = await b.post(`${A}/resend-otp`, { email });
  assert.equal(r.status, 429); assert.equal(r.body.error, 'COOLDOWN'); assert.ok(r.headers['retry-after']);
});

test('login: wrong password gives the same answer for real and unknown accounts', async () => {
  const b = T.browser();
  const s = await T.signup(T.browser());
  const real = await b.post(`${A}/login`, { email: s.email, password: 'wrong-Password-1' });
  const ghost = await b.post(`${A}/login`, { email: T.uniqueEmail(), password: 'wrong-Password-1' });
  assert.equal(real.status, 401); assert.equal(ghost.status, 401);
  assert.deepEqual(real.body, ghost.body);
});

test('login: account lockout after 5 failures, identical for unknown emails, lifted by time; success clears counter', async () => {
  const b = T.browser();
  const s = await T.signup(T.browser());
  for (let i = 0; i < 5; i++) assert.equal((await b.post(`${A}/login`, { email: s.email, password: 'wrong-Password-1' })).status, 401);
  const locked = await b.post(`${A}/login`, { email: s.email, password: s.password });       // even the CORRECT password is refused
  assert.equal(locked.status, 429); assert.equal(locked.body.error, 'TOO_MANY_LOGIN_ATTEMPTS');
  assert.ok(locked.body.retryAfter > 0 && locked.body.retryAfter <= 900); assert.ok(locked.headers['retry-after']);

  const ghost = T.uniqueEmail();
  for (let i = 0; i < 5; i++) await b.post(`${A}/login`, { email: ghost, password: 'wrong-Password-1' });
  const ghostLocked = await b.post(`${A}/login`, { email: ghost, password: 'x-Password-1' });
  assert.equal(ghostLocked.status, 429, 'unknown emails are throttled exactly like real ones (no enumeration)');

  // time passes: age the failures by 16 minutes -> login works again
  await db.query("UPDATE login_attempts SET created_at = created_at - INTERVAL '16 minutes'");
  const ok = await b.post(`${A}/login`, { email: s.email, password: s.password });
  assert.equal(ok.status, 200);
  assert.equal((await db.query('SELECT 1 FROM login_attempts WHERE email_hash=$1', [require('../src/security/crypto').emailHash(s.email)])).rowCount, 0, 'success clears failures');
});

test('login: parallel password guessing is counted atomically (no burst past the limit)', async () => {
  const s = await T.signup(T.browser());
  const rs = await Promise.all(Array.from({ length: 12 }, () => T.browser().post(`${A}/login`, { email: s.email, password: 'wrong-Password-1' })));
  assert.equal(rs.filter((r) => r.status === 401).length, 5);
  assert.equal(rs.filter((r) => r.status === 429).length, 7);
});

test('login: per-IP guard blocks one machine spraying many accounts', async () => {
  const ip = '::ffff:10.9.8.7';
  const rows = Array.from({ length: 30 }, (_, i) => `('h${i}', '${ip}')`).join(',');
  await db.query(`INSERT INTO login_attempts (email_hash, ip) VALUES ${rows}`);
  const { beginAttempt } = require('../src/security/loginGuard');
  const g = await beginAttempt('fresh-account@gmail.com', ip);
  assert.equal(g.locked, true);
  assert.equal((await beginAttempt('fresh-account@gmail.com', '::ffff:10.1.1.1')).locked, false, 'other IPs unaffected');
});

test('sessions: idle timeout, absolute expiry, new token each login, log out everywhere', async () => {
  const s = await T.signup(T.browser());
  const b1 = T.browser(), b2 = T.browser();
  assert.equal((await b1.post(`${A}/login`, { email: s.email, password: s.password })).status, 200);
  assert.equal((await b2.post(`${A}/login`, { email: s.email, password: s.password })).status, 200);
  assert.notEqual(b1.jar.ll_sid, b2.jar.ll_sid);

  await db.query("UPDATE sessions SET last_seen_at = NOW() - INTERVAL '25 hours' WHERE token_hash = $1", [require('../src/security/crypto').sha256(b1.jar.ll_sid)]);
  assert.equal((await b1.get(`${A}/me`)).status, 401, 'idle session is dead');
  await db.query("UPDATE sessions SET expires_at = NOW() - INTERVAL '1 second' WHERE token_hash = $1", [require('../src/security/crypto').sha256(b2.jar.ll_sid)]);
  assert.equal((await b2.get(`${A}/me`)).status, 401, 'expired session is dead');

  const c1 = T.browser(), c2 = T.browser();
  await c1.post(`${A}/login`, { email: s.email, password: s.password });
  await c2.post(`${A}/login`, { email: s.email, password: s.password });
  assert.equal((await c1.post(`${A}/logout-all`)).status, 200);
  assert.equal((await c2.get(`${A}/me`)).status, 401, 'other devices are signed out too');
  assert.equal((await T.browser().post(`${A}/logout-all`)).status, 401);
});

test('sessions: forged / malformed cookies are ignored', async () => {
  for (const v of ['garbage', 'x'.repeat(43), "' OR 1=1 --", 'A'.repeat(500)]) {
    const b = T.browser(); b.jar.ll_sid = encodeURIComponent(v);
    assert.equal((await b.get(`${A}/me`)).status, 401);
  }
});

test('audit log records security events without secrets', async () => {
  const ev = (await db.query('SELECT DISTINCT event FROM auth_events')).rows.map((r) => r.event);
  for (const e of ['otp_sent', 'register', 'login_success', 'login_failed', 'login_locked', 'logout', 'logout_all']) assert.ok(ev.includes(e), `missing ${e}`);
  const all = JSON.stringify((await db.query('SELECT * FROM auth_events')).rows);
  assert.ok(!/@gmail\.com/.test(all), 'raw emails are not stored in the audit log');
});
