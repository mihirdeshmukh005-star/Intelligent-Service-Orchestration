// Test harness: real PostgreSQL + a mock of the Resend HTTP API (captures the OTP emails).
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || 'postgresql://locallink:locallink@localhost:5432/locallink_auth_test';
process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-0123456789';
process.env.RESEND_API_KEY = 're_test';
process.env.MAIL_FROM_EMAIL = 'noreply@locallink.test';
process.env.EMAIL_MX_CHECK = 'false';        // no DNS in tests (the DNS logic is unit-tested with a fake resolver)
process.env.PWNED_PASSWORD_CHECK = 'false';  // no internet in tests
process.env.RATE_LIMIT_MULTIPLIER = '100';   // every test shares 127.0.0.1; the DB-backed guards are what we test

const http = require('http');

const mails = [];
const mailServer = http.createServer((req, res) => {
  let b = ''; req.on('data', (c) => { b += c; });
  req.on('end', () => { mails.push(JSON.parse(b)); res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"id":"x"}'); });
});

let server; let base; let db;
async function start() {
  await new Promise((r) => mailServer.listen(0, r));
  process.env.RESEND_API_URL = `http://127.0.0.1:${mailServer.address().port}/emails`;
  db = require('../src/db');
  await db.initSchema();
  await db.query('TRUNCATE users, email_otps, sessions, login_attempts, auth_events RESTART IDENTITY CASCADE');
  server = require('../src/app').listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  return { db };
}
async function stop() { server.close(); mailServer.close(); await db.pool.end(); }

/** Tiny browser: keeps cookies between calls. */
function browser() {
  const jar = {};
  const call = (method, path, body, headers = {}) => new Promise((resolve, reject) => {
    const data = body === undefined ? undefined : JSON.stringify(body);
    const cookie = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const req = http.request(base + path, {
      method, headers: { ...(data ? { 'content-type': 'application/json', 'content-length': Buffer.byteLength(data) } : {}), ...(cookie ? { cookie } : {}), ...headers },
    }, (res) => {
      let out = ''; res.on('data', (c) => { out += c; });
      res.on('end', () => {
        for (const c of res.headers['set-cookie'] || []) {
          const [kv] = c.split(';'); const i = kv.indexOf('=');
          const name = kv.slice(0, i); const val = kv.slice(i + 1);
          if (/expires=thu, 01 jan 1970/i.test(c) || val === '') delete jar[name]; else jar[name] = val;
        }
        let json = {}; try { json = JSON.parse(out); } catch (_) { /* not json */ }
        resolve({ status: res.statusCode, body: json, headers: res.headers, setCookie: res.headers['set-cookie'] || [] });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
  return { jar, post: (p, b, h) => call('POST', p, b ?? {}, h), get: (p, h) => call('GET', p, undefined, h), raw: call };
}

const lastOtp = (to) => { const m = [...mails].reverse().find((x) => x.to.includes(to)); return m && /\b(\d{6})\b/.exec(m.text)[1]; };

let n = 0;
const uniqueEmail = () => `user${++n}${Date.now() % 100000}@gmail.com`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Full signup through the real API. */
async function signup(b, { email = uniqueEmail(), password = 'Zebra-Lamp-47x', role = 'customer', profession, name = 'Asha Patel' } = {}) {
  await b.post('/api/auth/send-otp', { email });
  const v = await b.post('/api/auth/verify-otp', { email, otp: lastOtp(email) });
  const r = await b.post('/api/auth/register', { name, phone: '+919999999999', email, password, role, profession });
  return { email, password, verify: v, register: r };
}

module.exports = { start, stop, browser, lastOtp, uniqueEmail, signup, sleep, mails };
