const config = require('./src/config');
const db = require('./src/db');
const app = require('./src/app');

const CLEANUP = [
  "DELETE FROM email_otps WHERE created_at < NOW() - INTERVAL '1 day'",
  "DELETE FROM sessions WHERE expires_at < NOW() OR last_seen_at < NOW() - INTERVAL '30 days'",
  "DELETE FROM login_attempts WHERE created_at < NOW() - INTERVAL '1 day'",
  "DELETE FROM auth_events WHERE created_at < NOW() - INTERVAL '90 days'",
];

(async () => {
  try {
    await db.initSchema();
  } catch (err) {
    console.error(`\nCould not connect to the database: ${err.message}\nCheck DATABASE_URL in server/.env and that PostgreSQL is running.\n`);
    process.exit(1);
  }
  const sweep = () => CLEANUP.forEach((q) => db.query(q).catch(() => {}));
  sweep();
  setInterval(sweep, 60 * 60 * 1000).unref();
  const server = app.listen(config.port, () => console.log(`Local Link API running on http://localhost:${config.port}`));
  const stop = () => server.close(() => db.pool.end().then(() => process.exit(0)));
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
})();
