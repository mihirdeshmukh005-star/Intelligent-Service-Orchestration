-- Local Link PostgreSQL schema (idempotent; safe to run on every start)

CREATE TABLE IF NOT EXISTS customers (
  id               TEXT PRIMARY KEY,
  name             TEXT NOT NULL,
  email            TEXT NOT NULL,
  phone            TEXT,
  password_hash    TEXT NOT NULL,
  last_lat         DOUBLE PRECISION,
  last_lng         DOUBLE PRECISION,
  last_radius_km   DOUBLE PRECISION,
  last_label       TEXT,
  last_location_at TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS customers_email_uq ON customers (lower(email));

CREATE TABLE IF NOT EXISTS workers (
  id                      TEXT PRIMARY KEY,
  name                    TEXT NOT NULL,
  email                   TEXT NOT NULL,
  password_hash           TEXT NOT NULL,
  profession              TEXT NOT NULL,
  lat                     DOUBLE PRECISION NOT NULL,
  lng                     DOUBLE PRECISION NOT NULL,
  service_radius_km       DOUBLE PRECISION NOT NULL DEFAULT 5 CHECK (service_radius_km >= 0),
  rating                  NUMERIC(3,2) NOT NULL DEFAULT 0,
  reviews                 INTEGER NOT NULL DEFAULT 0,
  avatar                  TEXT,
  status                  TEXT NOT NULL DEFAULT 'active',
  available               BOOLEAN NOT NULL DEFAULT TRUE,
  availability            TEXT[] NOT NULL DEFAULT '{}',
  response_rate           DOUBLE PRECISION NOT NULL DEFAULT 0,
  completion_rate         DOUBLE PRECISION NOT NULL DEFAULT 0,
  punctuality             DOUBLE PRECISION NOT NULL DEFAULT 0,
  professionalism         DOUBLE PRECISION NOT NULL DEFAULT 0,
  safety                  DOUBLE PRECISION NOT NULL DEFAULT 0,
  success_rate            DOUBLE PRECISION NOT NULL DEFAULT 0,
  jobs_completed          INTEGER NOT NULL DEFAULT 0,
  price_range             TEXT,
  verif_identity          BOOLEAN NOT NULL DEFAULT FALSE,
  verif_credential        BOOLEAN NOT NULL DEFAULT FALSE,
  verif_assessment        BOOLEAN NOT NULL DEFAULT FALSE,
  verif_authorization     TEXT,
  verif_eligible          BOOLEAN NOT NULL DEFAULT FALSE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS workers_email_uq ON workers (lower(email));
CREATE INDEX IF NOT EXISTS workers_match_idx ON workers (lower(profession), status, verif_eligible);

CREATE TABLE IF NOT EXISTS requests (
  id             TEXT PRIMARY KEY,
  customer_id    TEXT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  worker_id      TEXT NOT NULL REFERENCES workers(id)   ON DELETE CASCADE,
  profession     TEXT NOT NULL,
  problem        TEXT NOT NULL DEFAULT '',
  slot           TEXT NOT NULL,
  mode           TEXT NOT NULL DEFAULT 'self' CHECK (mode IN ('self','ai')),
  lat            DOUBLE PRECISION NOT NULL,
  lng            DOUBLE PRECISION NOT NULL,
  location_label TEXT NOT NULL DEFAULT 'Selected service location',
  status         TEXT NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending','accepted','in_progress','rejected','auto-rejected','completed')),
  started_at     TIMESTAMPTZ,
  occupied_until_minutes INTEGER,
  extension_reason TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS requests_worker_idx   ON requests (worker_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS requests_customer_idx ON requests (customer_id, created_at DESC);
-- Booking lifecycle/overrun migration. Safe to execute repeatedly.
ALTER TABLE requests ADD COLUMN IF NOT EXISTS started_at TIMESTAMPTZ;
ALTER TABLE requests ADD COLUMN IF NOT EXISTS occupied_until_minutes INTEGER;
ALTER TABLE requests ADD COLUMN IF NOT EXISTS extension_reason TEXT;
ALTER TABLE requests DROP CONSTRAINT IF EXISTS requests_status_check;
ALTER TABLE requests ADD CONSTRAINT requests_status_check
  CHECK (status IN ('pending','accepted','in_progress','rejected','auto-rejected','completed'));
UPDATE requests
SET occupied_until_minutes = (
  (regexp_match(replace(replace(replace(slot,'–','-'),'—','-'),'−','-'), '^[0-9]{1,2}:([0-9]{2})-([0-9]{1,2}):([0-9]{2})$'))[3]::int
  + (regexp_match(replace(replace(replace(slot,'–','-'),'—','-'),'−','-'), '^[0-9]{1,2}:([0-9]{2})-([0-9]{1,2}):([0-9]{2})$'))[2]::int * 60
)
WHERE occupied_until_minutes IS NULL
  AND regexp_match(replace(replace(replace(slot,'–','-'),'—','-'),'−','-'), '^[0-9]{1,2}:[0-9]{2}-[0-9]{1,2}:[0-9]{2}$') IS NOT NULL;

-- DB-level guarantee: one active request per customer/worker/slot
DROP INDEX IF EXISTS requests_active_uq;
CREATE UNIQUE INDEX requests_active_uq
  ON requests (customer_id, worker_id, slot) WHERE status IN ('pending','accepted','in_progress');

CREATE TABLE IF NOT EXISTS feedback (
  id              TEXT PRIMARY KEY,
  request_id      TEXT NOT NULL UNIQUE REFERENCES requests(id) ON DELETE CASCADE,
  worker_id       TEXT NOT NULL REFERENCES workers(id)   ON DELETE CASCADE,
  customer_id     TEXT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  rating          SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment         TEXT NOT NULL DEFAULT '',
  punctuality     DOUBLE PRECISION NOT NULL,
  professionalism DOUBLE PRECISION NOT NULL,
  safety          DOUBLE PRECISION NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS feedback_worker_idx ON feedback (worker_id);

CREATE TABLE IF NOT EXISTS assessments (
  id           TEXT PRIMARY KEY,
  worker_id    TEXT NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
  profession   TEXT NOT NULL,
  score        DOUBLE PRECISION NOT NULL,
  total        DOUBLE PRECISION NOT NULL,
  passed       BOOLEAN NOT NULL,
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- user_id is polymorphic (customer or worker, see role), so no FK
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id         TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  user_id    TEXT NOT NULL,
  role       TEXT NOT NULL CHECK (role IN ('customer','worker')),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked    BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS refresh_tokens_user_idx ON refresh_tokens (user_id);

CREATE TABLE IF NOT EXISTS ai_sessions (
  id          TEXT NOT NULL,
  customer_id TEXT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  messages    JSONB NOT NULL DEFAULT '[]',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (customer_id, id)
);

CREATE TABLE IF NOT EXISTS metrics (
  id         BIGSERIAL PRIMARY KEY,
  name       TEXT NOT NULL,
  value      JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
