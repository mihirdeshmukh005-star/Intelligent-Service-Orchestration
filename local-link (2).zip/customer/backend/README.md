# Local Link Backend v2

Pure backend for the Local Link customer + worker booking platform. This version is designed around the project requirements in the supplied prototype and context document.

## Core guarantees

1. **Customer and worker roles are separated.** Customer APIs cannot open the worker console/request APIs, and worker APIs cannot use customer booking APIs.
2. **Exact customer location is persisted server-side.** A pending worker request never exposes the exact latitude/longitude to the worker API.
3. **Exact location is disclosed after worker acceptance.** The acceptance response contains the exact location and acceptance emails to both customer and worker contain the service location and coordinates.
4. **One worker cannot accept competing pending requests.** Acceptance runs in one PostgreSQL transaction that locks the worker row (`FOR UPDATE`), so concurrent accepts cannot both win. The selected request becomes `accepted`; every other pending request for that worker becomes `auto-rejected`.
5. **Eligibility is filtered before ranking.** Workers must be active, eligible/verified, profession-compatible, available for the requested slot and inside their service radius.
6. **Ranking is multi-factor.** It uses verification, service compatibility, availability, distance, Bayesian-style rating quality, and reliability signals including response, completion, punctuality, professionalism and safety.
7. **AI is provider-optional.** If `GROQ_API_KEY` is configured, the backend uses the Groq Groq chat completions API. If it is not configured or the provider fails, a deterministic local service classifier keeps the booking flow usable.
8. **Email is provider-optional.** Without SMTP credentials, acceptance and request emails are logged in demo mode. With SMTP, real messages are sent.

## Architecture

```text
server.js
└── src/
    ├── config/       environment
    ├── controllers/  HTTP orchestration
    ├── middleware/   auth, rate limiting, errors
    ├── routes/       role-specific HTTP endpoints
    ├── services/     matching, AI, email, seed
    └── utils/        PostgreSQL pool/transactions, JWT, password, validation, geo
├── db/schema.sql     PostgreSQL schema (applied automatically on start)
└── scripts/          one-off JSON → PostgreSQL migration
```

## Main API

### Auth

- `POST /api/auth/register` customer registration
- `POST /api/auth/login` `{email,password,role:"customer"|"worker"}`
- `POST /api/auth/refresh`
- `POST /api/auth/logout`
- `GET /api/auth/me`

### Customer (Bearer access token)

- `PATCH /api/customer/profile`
- `POST /api/customer/location` — persists selected service location
- `POST /api/customer/match` — self-booking matching
- `POST /api/customer/ai/message` — AI intake + recommendations
- `POST /api/customer/bookings` — create pending booking request
- `GET /api/customer/bookings` — customer history/status; exact location appears only after acceptance

Example AI request:

```json
{
  "message": "My kitchen tap is leaking badly and I need a plumber tomorrow morning.",
  "sessionId": "optional-session-id"
}
```

Example self-match request:

```json
{
  "lat": 20.005,
  "lng": 73.795,
  "radiusKm": 5,
  "profession": "Plumber",
  "slot": "09:00–10:00"
}
```

### Worker (Bearer access token)

- `GET /api/worker/profile`
- `GET /api/worker/requests` — exact pending location is hidden
- `POST /api/worker/requests/:id/accept` — reveals location and sends both confirmation emails
- `POST /api/worker/requests/:id/reject`
- `POST /api/worker/requests/:id/complete`
- `POST /api/worker/requests/:id/feedback`
- `POST /api/worker/assessment`

### Location

- `GET /api/locations/search?q=...` — authenticated customer-only proxy to Nominatim.

## Demo worker login

Seeded worker accounts all use password:

`DemoWorker@123`

Example worker emails:

- `worker.1@example.com`
- `worker.2@example.com`
- ...

Workers are seeded with mock verification. The API deliberately represents authorization as `mock`; this must not be presented as government certification.

## Database (PostgreSQL)

All data (customers, workers, requests, feedback, assessments, refresh tokens, AI sessions) is stored permanently in PostgreSQL. Integrity is enforced by the database: foreign keys, a unique index on customer email and worker email, a partial unique index preventing duplicate active requests for the same customer/worker/slot, and a `CHECK` on request status.

```bash
createdb locallink          # or: CREATE DATABASE locallink;
cp .env.example .env        # set DATABASE_URL
npm install
npm start                   # creates tables from db/schema.sql and seeds demo workers if empty
```

Hosted Postgres (Neon, Supabase, Render, RDS...): set `DATABASE_URL` and `DATABASE_SSL=true`.

### Importing old JSON data

If you have `data/*.json` from the v1/v2 prototype:

```bash
npm run migrate:json -- ./data   # idempotent; existing rows are skipped
```

### Tests

```bash
TEST_DATABASE_URL=postgresql://user:pass@localhost:5432/locallink_test npm test
```

The integration tests **truncate all tables** in the target database, so point them at a separate test DB.

## Run

```bash
npm install
cp .env.example .env
npm test
npm start
```

The health endpoint is:

`GET http://localhost:5000/api/health`

## AI configuration

Set `GROQ_API_KEY` to enable the model-backed intake. The implementation uses the **Groq chat completions API**, not the retired Assistants API. The backend asks the model for structured JSON describing profession, urgency, preferred time and clarification needs. If the provider is unavailable, the fallback classifier is used.

## Production notes

Storage is PostgreSQL. Still to do before real production use: real credential/authority integrations, a PostGIS/geospatial index if the worker count grows large (matching currently pre-filters by profession in SQL and computes distance in JS), a production map/geocoding provider, and a migration tool (e.g. node-pg-migrate) once the schema starts evolving.
