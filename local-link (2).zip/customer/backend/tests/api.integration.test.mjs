// End-to-end tests against a real PostgreSQL database.
// Uses TEST_DATABASE_URL (falls back to DATABASE_URL). WARNING: truncates all tables.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || process.env.DATABASE_URL || 'postgresql://locallink:locallink@localhost:5432/locallink_test';
process.env.NODE_ENV = 'test';

const { default: app } = await import('../src/app.js');
const { initDb, query, closeDb } = await import('../src/utils/db.js');
const { seed } = await import('../src/services/seedService.js');

let server, base;
const call = async (method, path, { token, body } = {}) => {
  const r = await fetch(base + path, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined
  });
  return { status: r.status, body: await r.json() };
};

before(async () => {
  await initDb();
  await query('TRUNCATE customers, workers, requests, feedback, assessments, refresh_tokens, ai_sessions, metrics CASCADE');
  await seed();
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { server.close(); await closeDb(); });

const register = async n => (await call('POST', '/api/auth/register', { body: { name: `Cust ${n}`, email: `c${n}@t.com`, password: 'password123' } })).body;
const workerLogin = async n => (await call('POST', '/api/auth/login', { body: { email: `worker.${n}@example.com`, password: 'DemoWorker@123', role: 'worker' } })).body;
const loc = { lat: 20.005, lng: 73.795, label: 'Home' };
const book = (token, workerId, slot = '09:00–10:00') =>
  call('POST', '/api/customer/bookings', { token, body: { workerId, slot, problem: 'leak', location: loc } });

test('data is persisted in PostgreSQL, health reports it', async () => {
  const h = await call('GET', '/api/health');
  assert.equal(h.body.storage, 'postgresql');
  assert.equal(h.body.database, 'up');
  const { rows } = await query('SELECT count(*)::int AS n FROM workers');
  assert.equal(rows[0].n, 8);
});

test('registration, duplicate email, login, refresh rotation', async () => {
  const reg = await register(1);
  assert.ok(reg.accessToken);
  assert.equal((await call('POST', '/api/auth/register', { body: { name: 'Dup', email: 'C1@t.com', password: 'password123' } })).status, 409);
  const login = await call('POST', '/api/auth/login', { body: { email: 'c1@t.com', password: 'password123' } });
  assert.equal(login.status, 200);
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'c1@t.com', password: 'wrong-pass' } })).status, 401);
  const r1 = await call('POST', '/api/auth/refresh', { body: { refreshToken: login.body.refreshToken } });
  assert.equal(r1.status, 200);
  assert.equal((await call('POST', '/api/auth/refresh', { body: { refreshToken: login.body.refreshToken } })).status, 401, 'old token must be revoked');
  assert.equal((await call('GET', '/api/auth/me', { token: r1.body.accessToken })).body.user.email, 'c1@t.com');
});

test('location save + matching returns ranked eligible workers', async () => {
  const { accessToken } = await register(2);
  assert.equal((await call('POST', '/api/customer/location', { token: accessToken, body: loc })).body.saved, true);
  const m = await call('POST', '/api/customer/match', { token: accessToken, body: { ...loc, radiusKm: 5, profession: 'Plumber', slot: '09:00–10:00' } });
  assert.equal(m.body.count, 1);
  assert.equal(m.body.workers[0].id, 'worker_2');
  const ai = await call('POST', '/api/customer/ai/message', { token: accessToken, body: { message: 'my tap is leaking, need a plumber' } });
  assert.equal(ai.body.analysis.profession, 'Plumber');
  assert.equal(ai.body.workers[0].id, 'worker_2');
  const again = await call('POST', '/api/customer/ai/message', { token: accessToken, body: { message: 'tomorrow morning', sessionId: ai.body.sessionId } });
  assert.equal(again.body.sessionId, ai.body.sessionId);
  const { rows } = await query('SELECT jsonb_array_length(messages) AS n FROM ai_sessions WHERE id=$1', [ai.body.sessionId]);
  assert.equal(rows[0].n, 4);
});

test('booking hides exact location from worker until acceptance; duplicates blocked', async () => {
  const { accessToken } = await register(3);
  const b = await book(accessToken, 'worker_2');
  assert.equal(b.status, 201);
  assert.equal(b.body.request.location.disclosed, false);
  assert.equal((await book(accessToken, 'worker_2')).status, 409);
  const w = await workerLogin(2);
  const list = await call('GET', '/api/worker/requests', { token: w.accessToken });
  const item = list.body.requests.find(r => r.id === b.body.request.id);
  assert.equal(item.location.lat, undefined);
  assert.equal(item.location.disclosed, false);
  const mine = await call('GET', '/api/customer/bookings', { token: accessToken });
  assert.equal(mine.body.requests[0].location.lat, undefined);
});

test('accept auto-rejects the worker\'s other pending requests; exact location revealed after', async () => {
  const a = await register(4), b = await register(5);
  const r1 = (await book(a.accessToken, 'worker_1')).body.request.id;
  const r2 = (await book(b.accessToken, 'worker_1')).body.request.id;
  const w = await workerLogin(1);
  const acc = await call('POST', `/api/worker/requests/${r1}/accept`, { token: w.accessToken });
  assert.equal(acc.status, 200);
  assert.deepEqual(acc.body.autoRejectedRequestIds, [r2]);
  assert.equal((await call('POST', `/api/worker/requests/${r1}/accept`, { token: w.accessToken })).status, 409);
  assert.equal((await call('POST', `/api/worker/requests/${r2}/accept`, { token: w.accessToken })).status, 409);
  const mine = await call('GET', '/api/customer/bookings', { token: a.accessToken });
  assert.equal(mine.body.requests[0].status, 'accepted');
  assert.equal(mine.body.requests[0].location.lat, 20.005);
  const other = await call('GET', '/api/customer/bookings', { token: b.accessToken });
  assert.equal(other.body.requests[0].status, 'auto-rejected');
});

test('concurrent accepts: exactly one wins', async () => {
  const cs = await Promise.all([6, 7, 8].map(register));
  const ids = [];
  for (const c of cs) ids.push((await book(c.accessToken, 'worker_3', '10:00–11:00')).body.request?.id);
  const w = await workerLogin(3);
  const results = await Promise.all(ids.map(id => call('POST', `/api/worker/requests/${id}/accept`, { token: w.accessToken })));
  assert.equal(results.filter(r => r.status === 200).length, 1);
  const { rows } = await query(`SELECT count(*)::int AS n FROM requests WHERE worker_id='worker_3' AND status='accepted'`);
  assert.equal(rows[0].n, 1);
});

test('reject, complete and feedback update rating atomically', async () => {
  const a = await register(9), b = await register(10);
  const rA = (await book(a.accessToken, 'worker_4')).body.request.id;
  const rB = (await book(b.accessToken, 'worker_4', '11:00–12:00')).body.request.id;
  const w = await workerLogin(4);
  assert.equal((await call('POST', `/api/worker/requests/${rB}/reject`, { token: w.accessToken })).body.request.status, 'rejected');
  assert.equal((await call('POST', `/api/worker/requests/${rA}/complete`, { token: w.accessToken })).status, 409, 'must accept first');
  await call('POST', `/api/worker/requests/${rA}/accept`, { token: w.accessToken });
  assert.equal((await call('POST', `/api/worker/requests/${rA}/complete`, { token: w.accessToken })).body.request.status, 'completed');
  assert.equal((await call('POST', `/api/customer/bookings/${rA}/feedback`, { token: a.accessToken, body: { rating: 3 } })).status, 201);
  assert.equal((await call('POST', `/api/customer/bookings/${rA}/feedback`, { token: a.accessToken, body: { rating: 5 } })).status, 409);
  assert.equal((await call('POST', `/api/customer/bookings/${rA}/feedback`, { token: b.accessToken, body: { rating: 5 } })).status, 404);
  const { rows } = await query(`SELECT rating, reviews FROM workers WHERE id='worker_4'`);
  assert.equal(rows[0].reviews, 1);
  assert.equal(rows[0].rating, 3);
});

test('role separation and worker assessment', async () => {
  const c = await register(11), w = await workerLogin(5);
  assert.equal((await call('GET', '/api/worker/requests', { token: c.accessToken })).status, 403);
  assert.equal((await call('GET', '/api/customer/bookings', { token: w.accessToken })).status, 403);
  const r = await call('POST', '/api/worker/assessment', { token: w.accessToken, body: { profession: 'Painter', score: 18, passed: true } });
  assert.equal(r.status, 201);
  const { rows } = await query(`SELECT verif_eligible FROM workers WHERE id='worker_5'`);
  assert.equal(rows[0].verif_eligible, true);
});

test('data survives a restart of the app (permanent storage)', async () => {
  const before = (await query('SELECT count(*)::int AS n FROM customers')).rows[0].n;
  await seed(); // idempotent: must not duplicate or wipe
  assert.equal((await query('SELECT count(*)::int AS n FROM workers')).rows[0].n, 8);
  assert.equal((await query('SELECT count(*)::int AS n FROM customers')).rows[0].n, before);
});
