import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { env } from '../config/env.js';

// NUMERIC -> number (ratings are NUMERIC(3,2)); BIGINT -> number
pg.types.setTypeParser(1700, v => (v === null ? null : parseFloat(v)));
pg.types.setTypeParser(20, v => (v === null ? null : parseInt(v, 10)));

export const pool = new pg.Pool({
  connectionString: env.databaseUrl,
  ssl: env.databaseSsl ? { rejectUnauthorized: false } : undefined,
  max: env.databasePoolMax
});
pool.on('error', e => console.error('Unexpected PostgreSQL pool error', e));

export const query = (text, params) => pool.query(text, params);

/** Run fn(client) inside a transaction; rolls back on any error. */
export async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (e) {
    try { await client.query('ROLLBACK'); } catch {}
    throw e;
  } finally { client.release(); }
}

export async function initDb() {
  const dir = path.dirname(fileURLToPath(import.meta.url));
  const sql = await fs.readFile(path.join(dir, '../../db/schema.sql'), 'utf8');
  // advisory lock so concurrent app instances don't race on DDL
  const client = await pool.connect();
  try {
    await client.query('SELECT pg_advisory_lock(727001)');
    await client.query(sql);
  } finally {
    try { await client.query('SELECT pg_advisory_unlock(727001)'); } catch {}
    client.release();
  }
}
export const closeDb = () => pool.end();

// ---- row -> API object mappers (keep the same shapes the services expect) ----
const iso = d => (d instanceof Date ? d.toISOString() : d ?? null);

export const mapCustomer = r => r && ({
  id: r.id, name: r.name, email: r.email, phone: r.phone || null, passwordHash: r.password_hash,
  lastLocation: r.last_lat === null ? undefined : {
    lat: r.last_lat, lng: r.last_lng, radiusKm: r.last_radius_km, label: r.last_label, updatedAt: iso(r.last_location_at)
  },
  createdAt: iso(r.created_at), updatedAt: iso(r.updated_at)
});

export const mapWorker = r => r && ({
  id: r.id, name: r.name, email: r.email, phone: r.phone || null, passwordHash: r.password_hash, profession: r.profession,
  location: { lat: r.lat, lng: r.lng, serviceRadiusKm: r.service_radius_km },
  rating: r.rating, reviews: r.reviews, avatar: r.avatar, status: r.status,
  available: r.available, availability: r.availability,
  responseRate: r.response_rate, completionRate: r.completion_rate, punctuality: r.punctuality,
  professionalism: r.professionalism, safety: r.safety, successRate: r.success_rate,
  jobsCompleted: r.jobs_completed, priceRange: r.price_range,
  verification: {
    identity: r.verif_identity, credential: r.verif_credential, assessment: r.verif_assessment,
    authorization: r.verif_authorization, eligible: r.verif_eligible
  },
  createdAt: iso(r.created_at), updatedAt: iso(r.updated_at)
});

export const mapRequest = r => r && ({
  id: r.id, customerId: r.customer_id, workerId: r.worker_id, profession: r.profession,
  problem: r.problem, slot: r.slot, mode: r.mode,
  location: { lat: r.lat, lng: r.lng, label: r.location_label },
  status: r.status, createdAt: iso(r.created_at), updatedAt: iso(r.updated_at)
});
