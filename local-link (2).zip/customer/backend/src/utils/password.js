import crypto from 'node:crypto';
import { promisify } from 'node:util';
const scrypt = promisify(crypto.scrypt);
export async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const key = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${key.toString('hex')}`;
}
export async function verifyPassword(password, encoded) {
  try {
    const [,salt,hex] = String(encoded).split(':');
    const key = await scrypt(password, salt, 64);
    return crypto.timingSafeEqual(key, Buffer.from(hex,'hex'));
  } catch { return false; }
}
