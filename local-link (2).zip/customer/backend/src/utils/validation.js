export function assert(condition, message, status=400) {
  if (!condition) { const e = new Error(message); e.status = status; throw e; }
}
export const isEmail = value => typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
export const num = (v, fallback=NaN) => Number.isFinite(Number(v)) ? Number(v) : fallback;
export function cleanText(v, max=2000) { return typeof v === 'string' ? v.trim().slice(0,max) : ''; }
