import crypto from 'node:crypto';
import { env } from '../config/env.js';
const b64 = x => Buffer.from(JSON.stringify(x)).toString('base64url');
const sign = input => crypto.createHmac('sha256', env.jwtSecret).update(input).digest('base64url');
export function signAccessToken(payload) {
  const header = b64({alg:'HS256',typ:'JWT'});
  const body = b64({...payload, iat:Math.floor(Date.now()/1000), exp:Math.floor(Date.now()/1000)+env.accessTokenMinutes*60});
  return `${header}.${body}.${sign(`${header}.${body}`)}`;
}
export function verifyAccessToken(token) {
  const [h,p,s] = String(token||'').split('.');
  if (!h || !p || !s || sign(`${h}.${p}`) !== s) throw new Error('Invalid token');
  const body = JSON.parse(Buffer.from(p,'base64url').toString());
  if (!body.exp || body.exp < Math.floor(Date.now()/1000)) throw new Error('Token expired');
  return body;
}
