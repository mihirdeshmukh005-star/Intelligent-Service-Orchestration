const normalize = value => String(value || '').replace(/[–—−]/g, '-').replace(/\s+/g, '');
export function parseSlot(slot) {
  const m = normalize(slot).match(/^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  const start = Number(m[1]) * 60 + Number(m[2]);
  const end = Number(m[3]) * 60 + Number(m[4]);
  if (![start,end].every(Number.isInteger) || start < 0 || end > 24*60 || end <= start) return null;
  return { start, end };
}
export function overlaps(slotA, occupiedUntilMinutes, slotB) {
  const a = parseSlot(slotA), b = parseSlot(slotB);
  if (!a || !b) return false;
  const endA = Number(occupiedUntilMinutes) > a.end ? Number(occupiedUntilMinutes) : a.end;
  return a.start < endA && b.start < endA && b.end > a.start;
}
export function slotRange(slot) { return parseSlot(slot); }
