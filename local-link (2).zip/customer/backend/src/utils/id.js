import crypto from 'node:crypto';
export const id = (prefix='id') => `${prefix}_${crypto.randomUUID()}`;
export const now = () => new Date().toISOString();
