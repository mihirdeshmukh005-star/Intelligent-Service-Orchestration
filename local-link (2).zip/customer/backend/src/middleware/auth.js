import { verifyAccessToken } from '../utils/jwt.js';
export function auth(req,res,next){
  try {
    const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');
    if(!token) return res.status(401).json({ok:false,error:'Authentication required.'});
    req.user=verifyAccessToken(token); next();
  } catch { return res.status(401).json({ok:false,error:'Invalid or expired access token.'}); }
}
export const role = (...roles) => (req,res,next) => roles.includes(req.user?.role) ? next() : res.status(403).json({ok:false,error:'Insufficient permissions.'});
