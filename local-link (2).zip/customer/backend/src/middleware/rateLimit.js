const buckets=new Map();
export function rateLimit({windowMs=60_000,max=100}={}){
  return (req,res,next)=>{
    const key=`${req.ip}:${req.path}`; const now=Date.now(); let b=buckets.get(key);
    if(!b||now-b.start>=windowMs)b={start:now,count:0}; b.count++; buckets.set(key,b);
    res.setHeader('X-RateLimit-Limit',max); res.setHeader('X-RateLimit-Remaining',Math.max(0,max-b.count));
    if(b.count>max)return res.status(429).json({ok:false,error:'Too many requests. Please try again later.'}); next();
  };
}
