export function notFound(req,res){res.status(404).json({ok:false,error:`Route not found: ${req.method} ${req.path}`});}
export function errorHandler(err,req,res,_next){
  console.error(err);
  const status=Number(err.status)||500;
  res.status(status).json({ok:false,error:status>=500?'Internal server error':err.message});
}
