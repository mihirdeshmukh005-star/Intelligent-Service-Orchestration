import dotenv from 'dotenv';
dotenv.config();

const bool = (v, d=false) => v === undefined ? d : String(v).toLowerCase() === 'true';
export const env = {
  port: Number(process.env.PORT || 5000),
  nodeEnv: process.env.NODE_ENV || 'development',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  databaseUrl: process.env.DATABASE_URL || 'postgresql://locallink:locallink@localhost:5432/locallink',
  databaseSsl: bool(process.env.DATABASE_SSL),
  databasePoolMax: Number(process.env.DATABASE_POOL_MAX || 10),
  jwtSecret: process.env.JWT_SECRET || 'local-link-development-secret-change-me',
  accessTokenMinutes: Number(process.env.ACCESS_TOKEN_MINUTES || 30),
  refreshTokenDays: Number(process.env.REFRESH_TOKEN_DAYS || 30),
  groqKey: process.env.GROQ_API_KEY || '',
  groqModel: process.env.GROQ_MODEL || 'openai/gpt-oss-120b',
  groqBaseUrl: (process.env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/$/, ''),
  aiMaxOutputTokens: Number(process.env.AI_MAX_OUTPUT_TOKENS || 700),
  resendKey: process.env.RESEND_API_KEY || '',
  resendUrl: process.env.RESEND_API_URL || 'https://api.resend.com/emails',
  mailFromEmail: process.env.MAIL_FROM_EMAIL || '',
  mailFromName: process.env.MAIL_FROM_NAME || 'Local Link',
  smtpHost: process.env.SMTP_HOST || '',
  smtpPort: Number(process.env.SMTP_PORT || 587),
  smtpSecure: bool(process.env.SMTP_SECURE),
  smtpUser: process.env.SMTP_USER || '',
  smtpPass: process.env.SMTP_PASS || '',
  mailFrom: process.env.MAIL_FROM || '',
  nominatimUrl: process.env.NOMINATIM_URL || 'https://nominatim.openstreetmap.org/search',
  nominatimUserAgent: process.env.NOMINATIM_USER_AGENT || 'LocalLink/2.0 (prototype)'
};

if (env.nodeEnv === 'production' && env.jwtSecret.length < 32) throw new Error('JWT_SECRET must be at least 32 characters in production.');
