import { query, tx, mapCustomer, mapWorker } from '../utils/db.js';
import { id } from '../utils/id.js';
import { assert, cleanText, isEmail, num } from '../utils/validation.js';
import { validCoordinates } from '../utils/geo.js';
import { matchWorkers } from '../services/matchingService.js';
import { understandProblem } from '../services/aiService.js';
import { sendRequestNotification } from '../services/emailService.js';
import { parseSlot, overlaps } from '../utils/slots.js';

const getCustomer = async cid => mapCustomer((await query('SELECT * FROM customers WHERE id=$1', [cid])).rows[0]);

// Pre-filter in SQL (profession / active / eligible); ranking and radius logic stay in matchingService.
async function candidateWorkers(profession) {
  const { rows } = await query(
    `SELECT w.* FROM workers w JOIN worker_profiles wp ON wp.id=w.id AND wp.active=TRUE AND wp.verified=TRUE AND wp.assessment_passed=TRUE WHERE w.status='active' AND w.verif_eligible=TRUE AND lower(w.profession)=lower($1)`,
    [profession]
  );
  return rows.map(mapWorker);
}

async function availableWorkersForSlot(workers, slot) {
  const range = parseSlot(slot);
  if (!range) return workers;
  const ids = workers.map(w => w.id);
  if (!ids.length) return [];
  const { rows } = await query(
    `SELECT worker_id,slot,occupied_until_minutes
       FROM requests
      WHERE worker_id=ANY($1::text[]) AND status IN ('accepted','in_progress')`,
    [ids]
  );
  const busy = new Set(
    rows.filter(r => overlaps(r.slot, r.occupied_until_minutes, slot)).map(r => r.worker_id)
  );
  return workers.filter(w => !busy.has(w.id));
}

export async function saveProfile(req, res) {
  const b = req.body || {};
  assert(cleanText(b.name, 120).length >= 2, 'Name is required.');
  assert(isEmail(b.email), 'Valid email is required.');
  let row;
  try {
    row = (await query(
      'UPDATE customers SET name=$2, email=$3, updated_at=now() WHERE id=$1 RETURNING *',
      [req.user.sub, cleanText(b.name, 120), b.email.trim().toLowerCase()]
    )).rows[0];
  } catch (e) {
    if (e.code === '23505') assert(false, 'Email is already registered.', 409);
    throw e;
  }
  assert(row, 'Customer not found.', 404);
  res.json({ ok: true, user: { id: row.id, name: row.name, email: row.email, role: 'customer' } });
}

export async function saveLocation(req, res) {
  const b = req.body || {}, lat = num(b.lat), lng = num(b.lng), radius = num(b.radiusKm, 5);
  assert(validCoordinates(lat, lng), 'Valid latitude and longitude are required.');
  assert(radius >= 1 && radius <= 50, 'Radius must be between 1 and 50 km.');
  const r = await query(
    `UPDATE customers SET last_lat=$2,last_lng=$3,last_radius_km=$4,last_label=$5,last_location_at=now(),updated_at=now()
     WHERE id=$1`,
    [req.user.sub, lat, lng, radius, cleanText(b.label, 300) || 'Selected service location']
  );
  assert(r.rowCount, 'Customer not found.', 404);
  res.json({ ok: true, saved: true });
}

export async function match(req, res) {
  const b = req.body || {}, lat = num(b.lat), lng = num(b.lng), radius = num(b.radiusKm, 5);
  assert(validCoordinates(lat, lng), 'Valid latitude and longitude are required.');
  assert(radius >= 1 && radius <= 50, 'Radius must be between 1 and 50 km.');
  const profession = cleanText(b.profession, 80);
  assert(profession, 'Profession is required.');
  const slot = cleanText(b.slot, 40); assert(!slot || parseSlot(slot), 'Invalid time slot.');
  const workers = matchWorkers(await availableWorkersForSlot(await candidateWorkers(profession), slot), { lat, lng, radiusKm: radius, profession, slot });
  res.json({ ok: true, count: workers.length, workers });
}

export async function aiMessage(req, res) {
  const message = cleanText(req.body?.message, 3000);
  assert(message, 'Message is required.');
  const sessionId = cleanText(req.body?.sessionId, 100) || id('ai');
  const existing = (await query('SELECT messages FROM ai_sessions WHERE id=$1 AND customer_id=$2', [sessionId, req.user.sub])).rows[0];
  const history = existing?.messages || [];
  const analysis = await understandProblem(message, history);
  const messages = [...history, { role: 'user', content: message }, { role: 'assistant', content: JSON.stringify(analysis) }].slice(-20);
  await query(
    `INSERT INTO ai_sessions (id,customer_id,messages) VALUES ($1,$2,$3)
     ON CONFLICT (customer_id,id) DO UPDATE SET messages=EXCLUDED.messages, updated_at=now()`,
    [sessionId, req.user.sub, JSON.stringify(messages)]
  );
  const u = await getCustomer(req.user.sub);
  let workers = [];
  if (analysis.profession && u?.lastLocation) {
    const slot = /^(?:\d{2}:00–\d{2}:00)$/.test(analysis.preferredTime || '') ? analysis.preferredTime : '';
    workers = matchWorkers(await availableWorkersForSlot(await candidateWorkers(analysis.profession), slot), {
      lat: u.lastLocation.lat, lng: u.lastLocation.lng, radiusKm: u.lastLocation.radiusKm, profession: analysis.profession, slot
    });
  }
  res.json({
    ok: true, sessionId,
    reply: analysis.needsClarification
      ? analysis.clarifyingQuestion
      : `I understood this as a ${analysis.profession} request. I ranked eligible professionals using service fit, availability, distance, reputation and reliability.`,
    analysis, workers
  });
}

export async function createBooking(req, res) {
  const b = req.body || {};
  const u = await getCustomer(req.user.sub);
  assert(u, 'Customer not found.', 404);
  const lat = num(b.location?.lat), lng = num(b.location?.lng);
  assert(validCoordinates(lat, lng), 'Exact service latitude and longitude are required.');
  const workerId = cleanText(b.workerId, 100);
  assert(workerId, 'workerId is required.');
  const slot = cleanText(b.slot, 40);
  const range = parseSlot(slot);
  assert(range, 'Invalid time slot.');
  const radiusKm = num(b.radiusKm, 5);

  let request;
  const w = await tx(async db => {
    // Lock the worker row so two customers cannot race into the same occupied slot.
    const wr = (await db.query(
      `SELECT w.* FROM workers w
       JOIN worker_profiles wp ON wp.id=w.id AND wp.active=TRUE AND wp.verified=TRUE AND wp.assessment_passed=TRUE
       WHERE w.id=$1 AND w.status='active' AND w.verif_eligible=TRUE
       FOR UPDATE`,
      [workerId]
    )).rows[0];
    const worker = mapWorker(wr);
    assert(worker, 'Worker not found or not eligible.', 404);

    const dup = await db.query(
      `SELECT 1 FROM requests WHERE customer_id=$1 AND worker_id=$2 AND slot=$3 AND status IN ('pending','accepted','in_progress')`,
      [u.id, worker.id, slot]
    );
    assert(!dup.rows.length, 'You already have an active request with this worker for this time slot.', 409);

    const active = (await db.query(
      `SELECT slot,occupied_until_minutes FROM requests
       WHERE worker_id=$1 AND status IN ('accepted','in_progress')`,
      [worker.id]
    )).rows;
    assert(!active.some(r => overlaps(r.slot, r.occupied_until_minutes, slot)),
      'This worker is busy during that time slot. Please choose another worker or time.');

    const candidate = matchWorkers([worker], {
      lat, lng, radiusKm, profession: worker.profession, slot
    })[0];
    assert(candidate, 'Selected worker is unavailable, outside the service area, or not eligible.', 409);

    request = {
      id: id('request'), customerId: u.id, workerId: worker.id, profession: worker.profession,
      problem: cleanText(b.problem, 3000), slot, mode: b.mode === 'ai' ? 'ai' : 'self',
      location: { lat, lng, label: cleanText(b.location?.label, 300) || 'Selected service location' },
      status: 'pending', occupiedUntilMinutes: range.end
    };
    await db.query(
      `INSERT INTO requests
       (id,customer_id,worker_id,profession,problem,slot,mode,lat,lng,location_label,status,occupied_until_minutes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'pending',$11)`,
      [request.id, u.id, worker.id, worker.profession, request.problem, slot, request.mode,
       lat, lng, request.location.label, range.end]
    );
    return worker;
  });

  let notification = { emailSent:false, demoMode:true };
  try {
    notification = await sendRequestNotification({ request, worker:w, customer:u });
  } catch (e) {
    console.error('Request notification email failed:', e.message);
    notification = { emailSent:false, demoMode:false, error:'Worker notification email failed; request was still created.' };
  }
  res.status(201).json({
    ok: true,
    request: {
      id: request.id, status: 'pending',
      worker: { id: w.id, name: w.name, profession: w.profession },
      slot, location: { label: request.location.label, disclosed: false }
    },
    notification
  });
}

export async function myBookings(req, res) {
  const { rows } = await query(
    `SELECT r.*, w.name AS w_name, w.profession AS w_profession, w.rating AS w_rating
     FROM requests r LEFT JOIN workers w ON w.id=r.worker_id
     WHERE r.customer_id=$1 ORDER BY r.created_at DESC`,
    [req.user.sub]
  );
  res.json({
    ok: true,
    requests: rows.map(row => {
      const x = { id: row.id, customerId: row.customer_id, workerId: row.worker_id, profession: row.profession, problem: row.problem, slot: row.slot, mode: row.mode, status: row.status, startedAt: row.started_at || null, occupiedUntilMinutes: row.occupied_until_minutes == null ? null : Number(row.occupied_until_minutes), extensionReason: row.extension_reason || null, createdAt: row.created_at.toISOString(), updatedAt: row.updated_at.toISOString() };
      const full = { lat: row.lat, lng: row.lng, label: row.location_label };
      return {
        ...x,
        worker: { id: row.worker_id, name: row.w_name, profession: row.w_profession, rating: row.w_rating },
        location: ['accepted', 'in_progress', 'completed'].includes(row.status) ? full : { label: row.location_label, disclosed: false },
        startedAt: row.started_at || null, occupiedUntilMinutes: row.occupied_until_minutes == null ? null : Number(row.occupied_until_minutes), extensionReason: row.extension_reason || null
      };
    })
  });
}
