import { query, tx, mapWorker, mapRequest, mapCustomer } from '../utils/db.js';
import { id } from '../utils/id.js';
import { assert, cleanText } from '../utils/validation.js';
import { sendAcceptanceEmails, sendRejectionEmail } from '../services/emailService.js';

const pub = w => ({
  id: w.id, name: w.name, profession: w.profession, email: w.email, rating: w.rating, reviews: w.reviews, avatar: w.avatar,
  location: { serviceRadiusKm: w.location.serviceRadiusKm }, available: w.available, availability: w.availability,
  responseRate: w.responseRate, completionRate: w.completionRate, punctuality: w.punctuality, professionalism: w.professionalism,
  safety: w.safety, jobsCompleted: w.jobsCompleted, priceRange: w.priceRange, verification: w.verification
});

export async function profile(req, res) {
  const w = mapWorker((await query('SELECT * FROM workers WHERE id=$1', [req.user.sub])).rows[0]);
  assert(w, 'Worker not found.', 404);
  res.json({ ok: true, worker: pub(w) });
}

export async function requests(req, res) {
  const { rows } = await query(
    `SELECT r.*, c.name AS c_name, c.email AS c_email
     FROM requests r LEFT JOIN customers c ON c.id=r.customer_id
     WHERE r.worker_id=$1 AND r.status IN ('pending','accepted','completed')
     ORDER BY r.created_at DESC`,
    [req.user.sub]
  );
  res.json({
    ok: true,
    requests: rows.map(row => ({
      id: row.id, status: row.status, profession: row.profession, problem: row.problem, slot: row.slot, mode: row.mode,
      createdAt: row.created_at.toISOString(),
      customer: { id: row.customer_id, name: row.c_name, email: row.c_email },
      location: { label: row.location_label, disclosed: false } // exact coordinates never exposed here
    }))
  });
}

export async function accept(req, res) {
  const requestId = cleanText(req.params.id, 100);
  const workerId = req.user.sub;
  const { accepted, autoRejected } = await tx(async db => {
    // Lock the worker row: concurrent accepts by the same worker are serialized by PostgreSQL.
    const lock = await db.query('SELECT id FROM workers WHERE id=$1 FOR UPDATE', [workerId]);
    assert(lock.rows.length, 'Worker not found.', 404);
    const target = (await db.query('SELECT * FROM requests WHERE id=$1 FOR UPDATE', [requestId])).rows[0];
    assert(target, 'Request not found.', 404);
    assert(target.worker_id === workerId, 'Request does not belong to this worker.', 403);
    assert(target.status === 'pending', `Request is already ${target.status}.`, 409);
    const acc = (await db.query(`UPDATE requests SET status='accepted', updated_at=now() WHERE id=$1 RETURNING *`, [requestId])).rows[0];
    const others = await db.query(
      `UPDATE requests SET status='auto-rejected', updated_at=now()
       WHERE worker_id=$1 AND status='pending' AND id<>$2 RETURNING id`,
      [workerId, requestId]
    );
    return { accepted: mapRequest(acc), autoRejected: others.rows.map(r => r.id) };
  });

  const w = mapWorker((await query('SELECT * FROM workers WHERE id=$1', [workerId])).rows[0]);
  const c = mapCustomer((await query('SELECT * FROM customers WHERE id=$1', [accepted.customerId])).rows[0]);
  assert(w && c, 'Booking participants no longer exist.', 500);
  let emailResult = { emailSent: false, demoMode: true };
  try {
    emailResult = await sendAcceptanceEmails({ request: { ...accepted, workerName: w.name }, customer: c, worker: w });
  } catch (e) {
    console.error('Acceptance email failure', e);
    emailResult = { emailSent: false, demoMode: false, error: 'Email delivery failed after acceptance. The booking remains accepted.' };
  }
  res.json({
    ok: true,
    request: {
      id: accepted.id, status: 'accepted', worker: { id: w.id, name: w.name, profession: w.profession },
      customer: { name: c.name, email: c.email }, slot: accepted.slot,
      location: { label: accepted.location.label, disclosed: false, emailOnly: true }
    },
    autoRejectedRequestIds: autoRejected, email: emailResult
  });
}

// Atomic status transition: only succeeds if the request belongs to this worker and is in `from`.
async function transition(requestId, workerId, from, to, conflictMsg) {
  const r = await query(
    `UPDATE requests SET status=$4, updated_at=now() WHERE id=$1 AND worker_id=$2 AND status=$3 RETURNING *`,
    [requestId, workerId, from, to]
  );
  if (r.rows[0]) return mapRequest(r.rows[0]);
  const cur = (await query('SELECT worker_id, status FROM requests WHERE id=$1', [requestId])).rows[0];
  assert(cur, 'Request not found.', 404);
  assert(cur.worker_id === workerId, 'Request does not belong to this worker.', 403);
  assert(false, conflictMsg(cur.status), 409);
}

export async function reject(req, res) {
  const changed = await transition(cleanText(req.params.id, 100), req.user.sub, 'pending', 'rejected', s => `Request is already ${s}.`);
  const c = mapCustomer((await query('SELECT * FROM customers WHERE id=$1', [changed.customerId])).rows[0]);
  let notification = { emailSent: false, demoMode: true };
  if (c) {
    try { notification = await sendRejectionEmail({ request: changed, customer: c }); }
    catch (e) { console.error('Rejection email failure', e); notification = { emailSent: false, demoMode: false }; }
  }
  res.json({ ok: true, request: { id: changed.id, status: 'rejected' }, notification });
}

export async function complete(req, res) {
  const changed = await transition(cleanText(req.params.id, 100), req.user.sub, 'accepted', 'completed', () => 'Only an accepted request can be completed.');
  res.json({ ok: true, request: { id: changed.id, status: 'completed' } });
}

export async function feedback(req, res) {
  const b = req.body || {}, requestId = cleanText(req.params.id, 100);
  const rating = Number(b.rating);
  assert(Number.isInteger(rating) && rating >= 1 && rating <= 5, 'Rating must be an integer from 1 to 5.');
  const f = await tx(async db => {
    const request = (await db.query('SELECT * FROM requests WHERE id=$1 FOR UPDATE', [requestId])).rows[0];
    assert(request && request.customer_id === req.user.sub, 'Booking not found.', 404);
    assert(request.status === 'completed', 'Feedback can only be submitted after completion.', 409);
    const dup = await db.query('SELECT 1 FROM feedback WHERE request_id=$1', [requestId]);
    assert(!dup.rows.length, 'Feedback already submitted.', 409);
    const punctuality=Number(b.punctuality)||rating, professionalism=Number(b.professionalism)||rating, safety=Number(b.safety)||rating;
    const row = (await db.query(
      `INSERT INTO feedback (id,request_id,worker_id,customer_id,rating,comment,punctuality,professionalism,safety)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [id('feedback'), requestId, request.worker_id, req.user.sub, rating, cleanText(b.comment, 1000), punctuality, professionalism, safety]
    )).rows[0];
    const calculated=Number((rating*.45+punctuality*.20+professionalism*.15+safety*.20).toFixed(2));
    await db.query(`INSERT INTO worker_feedback(id,worker_id,request_id,date,stars,arrival_minutes_early,job_completed,professionalism,safety,comment,calculated_rating) VALUES($1,$2,$3,current_date,$4,0,true,$5,$6,$7,$8)`,[id('wfb'),request.worker_id,requestId,rating,professionalism,safety,cleanText(b.comment,1000),calculated]);
    await db.query(`UPDATE workers SET rating=(SELECT ROUND(AVG(calculated_rating)::numeric,2) FROM worker_feedback WHERE worker_id=$1),reviews=(SELECT COUNT(*) FROM worker_feedback WHERE worker_id=$1),safety=(SELECT ROUND(AVG(safety)::numeric,2) FROM worker_feedback WHERE worker_id=$1),professionalism=(SELECT ROUND(AVG(professionalism)::numeric,2) FROM worker_feedback WHERE worker_id=$1),updated_at=NOW() WHERE id=$1`,[request.worker_id]);
    await db.query(`UPDATE worker_profiles SET base_rating=(SELECT COALESCE(ROUND(AVG(calculated_rating)::numeric,2),0) FROM worker_feedback WHERE worker_id=$1),total_feedback=(SELECT COUNT(*) FROM worker_feedback WHERE worker_id=$1),on_time_rate=(SELECT COALESCE(AVG(CASE WHEN arrival_minutes_early>=0 THEN 1 ELSE 0 END),0) FROM worker_feedback WHERE worker_id=$1),updated_at=NOW() WHERE id=$1`,[request.worker_id]);
    return row;
  });
  res.status(201).json({
    ok: true,
    feedback: {
      id: f.id, requestId: f.request_id, workerId: f.worker_id, customerId: f.customer_id, rating: f.rating, comment: f.comment,
      punctuality: f.punctuality, professionalism: f.professionalism, safety: f.safety, createdAt: f.created_at.toISOString()
    }
  });
}

export async function assessment(req, res) {
  const { profession, score, total = 20, passed } = req.body || {};
  assert(cleanText(profession, 80), 'Profession is required.');
  assert(Number.isFinite(Number(score)), 'Score is required.');
  const attempt = await tx(async db => {
    const a = (await db.query(
      `INSERT INTO assessments (id,worker_id,profession,score,total,passed) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [id('assessment'), req.user.sub, cleanText(profession, 80), Number(score), Number(total), Boolean(passed)]
    )).rows[0];
    if (a.passed) {
      await db.query(
        `UPDATE workers SET verif_assessment=TRUE,
           verif_eligible=(verif_identity AND verif_credential AND verif_authorization IS NOT NULL AND verif_authorization<>''),
           updated_at=now() WHERE id=$1`,
        [req.user.sub]
      );
    }
    return a;
  });
  res.status(201).json({
    ok: true,
    attempt: { id: attempt.id, workerId: attempt.worker_id, profession: attempt.profession, score: attempt.score, total: attempt.total, passed: attempt.passed, submittedAt: attempt.submitted_at.toISOString() }
  });
}
