import crypto from 'node:crypto';
import { query } from '../utils/db.js';
import { id } from '../utils/id.js';
import { hashPassword, verifyPassword } from '../utils/password.js';
import { signAccessToken } from '../utils/jwt.js';
import { assert, cleanText, isEmail } from '../utils/validation.js';
import { env } from '../config/env.js';

const hash = x => crypto.createHash('sha256').update(x).digest('hex');
const access = u => signAccessToken({ sub: u.id, role: u.role, name: u.name, email: u.email });
const table = role => (role === 'worker' ? 'workers' : 'customers');

async function issue(userId, role, db = { query }) {
  const token = crypto.randomBytes(48).toString('base64url');
  await db.query(
    'INSERT INTO refresh_tokens (id,token_hash,user_id,role,expires_at) VALUES ($1,$2,$3,$4,$5)',
    [id('rt'), hash(token), userId, role, new Date(Date.now() + env.refreshTokenDays * 86400000)]
  );
  return token;
}

export async function registerCustomer(req, res) {
  const { name, email, password } = req.body || {};
  assert(cleanText(name, 120).length >= 2, 'Name is required.');
  assert(isEmail(email), 'Valid email is required.');
  assert(typeof password === 'string' && password.length >= 8, 'Password must be at least 8 characters.');
  const clean = email.trim().toLowerCase();
  const exists = await query('SELECT 1 FROM customers WHERE lower(email)=$1', [clean]);
  assert(!exists.rows.length, 'Email is already registered.', 409);
  const u = { id: id('customer'), name: cleanText(name, 120), email: clean };
  try {
    await query('INSERT INTO customers (id,name,email,password_hash) VALUES ($1,$2,$3,$4)',
      [u.id, u.name, u.email, await hashPassword(password)]);
  } catch (e) {
    if (e.code === '23505') assert(false, 'Email is already registered.', 409); // race on unique index
    throw e;
  }
  const rt = await issue(u.id, 'customer');
  res.status(201).json({
    ok: true, user: { id: u.id, name: u.name, email: u.email, role: 'customer' },
    accessToken: access({ ...u, role: 'customer' }), refreshToken: rt
  });
}

export async function login(req, res) {
  const { email, password, role = 'customer' } = req.body || {};
  assert(isEmail(email), 'Valid email is required.');
  assert(role === 'customer' || role === 'worker', 'Role must be customer or worker.');
  const { rows } = await query(`SELECT * FROM ${table(role)} WHERE lower(email)=$1`, [email.trim().toLowerCase()]);
  const u = rows[0];
  assert(u && await verifyPassword(typeof password === 'string' ? password : '', u.password_hash), 'Invalid email or password.', 401);
  const p = { id: u.id, name: u.name, email: u.email, role };
  res.json({ ok: true, user: p, accessToken: access(p), refreshToken: await issue(u.id, role) });
}

export async function refresh(req, res) {
  const token = req.body?.refreshToken;
  assert(typeof token === 'string' && token, 'Refresh token is required.');
  // Atomically revoke: only one concurrent caller can consume a given token (rotation).
  const { rows } = await query(
    'UPDATE refresh_tokens SET revoked=TRUE WHERE token_hash=$1 AND revoked=FALSE RETURNING user_id, role, expires_at',
    [hash(token)]
  );
  const found = rows[0];
  assert(found && found.expires_at > new Date(), 'Invalid or expired refresh token.', 401);
  const u = (await query(`SELECT * FROM ${table(found.role)} WHERE id=$1`, [found.user_id])).rows[0];
  assert(u, 'User not found.', 401);
  const p = { id: u.id, name: u.name, email: u.email, role: found.role };
  res.json({ ok: true, user: p, accessToken: access(p), refreshToken: await issue(u.id, found.role) });
}

export async function logout(req, res) {
  if (typeof req.body?.refreshToken === 'string') {
    await query('UPDATE refresh_tokens SET revoked=TRUE WHERE token_hash=$1', [hash(req.body.refreshToken)]);
  }
  res.json({ ok: true });
}

export async function me(req, res) {
  const { rows } = await query(`SELECT * FROM ${table(req.user.role)} WHERE id=$1`, [req.user.sub]);
  const u = rows[0];
  assert(u, 'User not found.', 404);
  res.json({ ok: true, user: { id: u.id, name: u.name, email: u.email, role: req.user.role, profession: u.profession || null } });
}
