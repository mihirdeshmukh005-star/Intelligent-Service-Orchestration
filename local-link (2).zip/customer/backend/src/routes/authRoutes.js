import {Router} from 'express';import {registerCustomer,login,refresh,logout,me} from '../controllers/authController.js';import {auth} from '../middleware/auth.js';
const r=Router();r.post('/register',registerCustomer);r.post('/login',login);r.post('/refresh',refresh);r.post('/logout',logout);r.get('/me',auth,me);export default r;
