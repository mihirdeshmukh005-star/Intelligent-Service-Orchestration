import {Router} from 'express';import {auth,role} from '../middleware/auth.js';import {saveProfile,saveLocation,match,aiMessage,createBooking,myBookings} from '../controllers/customerController.js';
import {feedback} from '../controllers/workerController.js';
const r=Router();r.use(auth,role('customer'));r.patch('/profile',saveProfile);r.post('/location',saveLocation);r.post('/match',match);r.post('/ai/message',aiMessage);r.post('/bookings',createBooking);r.get('/bookings',myBookings);r.post('/bookings/:id/feedback',feedback);export default r;
