import { distanceKm } from '../utils/geo.js';

const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,n));
function ratingQuality(w){
  const reviews=Math.max(0,Number(w.reviews)||0);
  const rating=clamp(Number(w.rating)||0,0,5);
  const bayes=(rating*reviews + 4.2*30)/(reviews+30);
  return clamp((bayes/5)*100);
}
function reliability(w){
  return clamp((Number(w.responseRate)||0)*0.30 + (Number(w.completionRate)||0)*0.25 + (Number(w.punctuality)||0)*0.20 + (Number(w.professionalism)||0)*0.10 + (Number(w.safety)||0)*0.10 + (Number(w.successRate)||0)*0.05);
}
function availability(w,slot){
  if(!w.available) return 0;
  if(!slot) return 70;
  return Array.isArray(w.availability) && w.availability.includes(slot) ? 100 : 0;
}
export function scoreWorker(w, input){
  const d=distanceKm(input.lat,input.lng,w.location.lat,w.location.lng);
  const service= input.profession && w.profession.toLowerCase()===input.profession.toLowerCase() ? 100 : 0;
  const avail=availability(w,input.slot);
  const verified=w.verification?.eligible ? 100 : 0;
  const distanceScore=clamp(100-(d/Math.max(input.radiusKm||5,0.1))*100);
  const reputation=ratingQuality(w);
  const rel=reliability(w);
  const score=verified*0.15 + service*0.25 + avail*0.15 + distanceScore*0.15 + reputation*0.20 + rel*0.10;
  return {score:Number(score.toFixed(2)),distanceKm:Number(d.toFixed(3)),components:{verified,service,availability:avail,distance:distanceScore,reputation:Number(reputation.toFixed(2)),reliability:Number(rel.toFixed(2))}};
}
export function matchWorkers(workers,input){
  return workers.filter(w=>w.status==='active'&&w.verification?.eligible&&w.location&&w.profession&&w.location.serviceRadiusKm>=0)
    .map(w=>({worker:w,...scoreWorker(w,input)}))
    .filter(x=>x.components.service===100&&x.components.availability>0&&x.distanceKm<=Math.min(input.radiusKm||5,x.worker.location.serviceRadiusKm||input.radiusKm||5))
    .sort((a,b)=>b.score-a.score || a.distanceKm-b.distanceKm)
    .map(x=>({
      id:x.worker.id,name:x.worker.name,profession:x.worker.profession,email:x.worker.email,verified:true,
      rating:x.worker.rating,reviews:x.worker.reviews,responseRate:x.worker.responseRate,completionRate:x.worker.completionRate,
      punctuality:x.worker.punctuality,professionalism:x.worker.professionalism,safety:x.worker.safety,jobsCompleted:x.worker.jobsCompleted,
      lat:x.worker.location.lat,lng:x.worker.location.lng,distanceKm:x.distanceKm,matchScore:x.score,scoreBreakdown:x.components,priceRange:x.worker.priceRange,avatar:x.worker.avatar
    }));
}
