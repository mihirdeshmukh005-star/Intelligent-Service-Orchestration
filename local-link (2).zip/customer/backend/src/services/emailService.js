import nodemailer from 'nodemailer';import {env} from '../config/env.js';let transport;function getTransport(){if(!env.smtpHost||!env.smtpUser||!env.smtpPass)return null;if(!transport)transport=nodemailer.createTransport({host:env.smtpHost,port:env.smtpPort,secure:env.smtpSecure,auth:{user:env.smtpUser,pass:env.smtpPass}});return transport;}async function sendMail({to,subject,text}){
  const t=getTransport();
  if(t){await t.sendMail({from:env.mailFrom||env.smtpUser,to,subject,text});return {emailSent:true,provider:'smtp'};}
  if(env.resendKey&&env.resendKey!=='your_key_here'&&env.mailFromEmail){
    const r=await fetch(env.resendUrl,{method:'POST',headers:{Authorization:`Bearer ${env.resendKey}`,'Content-Type':'application/json'},body:JSON.stringify({from:`${env.mailFromName} <${env.mailFromEmail}>`,to:[to],subject,text}),signal:AbortSignal.timeout(10000)});
    if(!r.ok)throw new Error(`Resend ${r.status}: ${(await r.text()).slice(0,200)}`);
    return {emailSent:true,provider:'resend'};
  }
  console.log(`[DEV EMAIL] to=${to}\n${text}`);
  return {emailSent:false,demoMode:true,provider:'dev'};
}

export async function sendAcceptanceEmails({request,customer,worker}){const subject=`Local Link booking confirmed — ${request.profession}`;const a=await sendMail({to:customer.email,subject,text:[`Booking confirmed with ${worker.name}`,`Service: ${request.profession}`,`Time: ${request.slot}`,`Location: ${request.location.label}`,`Latitude: ${request.location.lat}`,`Longitude: ${request.location.lng}`,`Worker email: ${worker.email}`].join('\n')});const b=await sendMail({to:worker.email,subject,text:[`Booking confirmed with ${customer.name}`,`Customer email: ${customer.email}`,`Customer phone: ${customer.phone||'Not provided'}`,`Service: ${request.profession}`,`Time: ${request.slot}`,`Location: ${request.location.label}`,`Latitude: ${request.location.lat}`,`Longitude: ${request.location.lng}`,`Problem: ${request.problem||'Not provided'}`,'','Exact location is disclosed because you accepted the booking.'].join('\n')});return {emailSent:a.emailSent&&b.emailSent,demoMode:Boolean(a.demoMode||b.demoMode),recipients:[customer.email,worker.email],providers:[a.provider,b.provider]};}
export async function sendRejectionEmail({request,customer,reason='The professional declined the request.'}){return sendMail({to:customer.email,subject:'Local Link — Booking request update',text:[`Your ${request.profession} request was not accepted.`,`Time: ${request.slot}`,`Reason: ${reason}`,'','Please choose another professional.'].join('\n')});}
export async function sendRequestNotification({request,worker,customer}){return sendMail({to:worker.email,subject:`Local Link — New ${request.profession} request`,text:[`New ${request.profession} request`,`Customer: ${customer.name}`,`Customer email: ${customer.email}`,`Time: ${request.slot}`,`Problem: ${request.problem||'Not provided'}`,'','Exact location is hidden until you accept.'].join('\n')});}
