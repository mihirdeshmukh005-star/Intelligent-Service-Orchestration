import { query } from '../utils/db.js';
import { hashPassword } from '../utils/password.js';

const slots = Array.from({ length: 17 }, (_, i) => {
  const h = i + 6;
  return `${String(h).padStart(2, '0')}:00–${String(h + 1).padStart(2, '0')}:00`;
});

const base = [
  ['Aarav Electricals', 'Electrician', 19.9975, 73.7898, 4.9, 238, '⚡'],
  ['Shree Plumbing Care', 'Plumber', 20.005, 73.795, 4.8, 184, '💧'],
  ['CoolFix Experts', 'AC Technician', 19.987, 73.782, 4.7, 151, '❄️'],
  ['Precision Carpentry', 'Carpenter', 20.012, 73.776, 4.8, 121, '🔨'],
  ['CareNest House Keeping', 'House Keeping', 20.009, 73.801, 4.7, 112, '🧹'],
  ['BrightCo Painters', 'Painter', 19.978, 73.804, 4.6, 98, '🎨'],
  ['SecureKey Services', 'Locksmith', 20.018, 73.806, 4.7, 86, '🔑'],
  ['SparkHome Cleaning', 'Cleaner', 20.001, 73.802, 4.8, 143, '🧹'],
  ['FixRight Appliances', 'Appliance Repair', 19.991, 73.798, 4.7, 132, '🔧']
];

/** Seeds demo workers only when the workers table is empty. */
export async function seed() {
  const { rows } = await query('SELECT 1 FROM workers LIMIT 1');
  const pw = await hashPassword('DemoWorker@123');
  if (rows.length) {
    const hk=base.find(x=>x[1]==='House Keeping');
    if(hk) await query(`INSERT INTO workers (id,name,email,password_hash,profession,lat,lng,service_radius_km,rating,reviews,avatar,status,available,availability,response_rate,completion_rate,punctuality,professionalism,safety,success_rate,jobs_completed,price_range,verif_identity,verif_credential,verif_assessment,verif_authorization,verif_eligible) VALUES ('worker_housekeeping',$1,'worker.housekeeping@example.com',$2,$3,$4,$5,5,$6,$7,$8,'active',TRUE,$9,96,96,95,96,99,97,112,'₹250–₹900',TRUE,TRUE,TRUE,'mock',TRUE) ON CONFLICT(id) DO NOTHING`,[hk[0],pw,hk[1],hk[2],hk[3],hk[4],hk[5],hk[6],slots]);
    return;
  }
  for (const [i, x] of base.entries()) {
    await query(
      `INSERT INTO workers (id,name,email,password_hash,profession,lat,lng,service_radius_km,rating,reviews,avatar,
         status,available,availability,response_rate,completion_rate,punctuality,professionalism,safety,success_rate,
         jobs_completed,price_range,verif_identity,verif_credential,verif_assessment,verif_authorization,verif_eligible)
       VALUES ($1,$2,$3,$4,$5,$6,$7,5,$8,$9,$10,'active',TRUE,$11,$12,$13,$14,$15,$16,$17,$18,'₹250–₹900',TRUE,TRUE,TRUE,'mock',TRUE)
       ON CONFLICT (id) DO NOTHING`,
      [`worker_${i + 1}`, x[0], `worker.${i + 1}@example.com`, pw, x[1], x[2], x[3], x[4], x[5], x[6], slots,
       98 - i, 97 - i, 95 - i, 96 - i, 99 - i, 97 - i, 250 + i * 31]
    );
  }
}
