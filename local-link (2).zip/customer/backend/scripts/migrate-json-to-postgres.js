// One-off import of the old JSON prototype data into PostgreSQL.
// Usage: node scripts/migrate-json-to-postgres.js [path/to/json-data-dir]   (default ./data)
import fs from 'node:fs/promises';
import path from 'node:path';
import { initDb, tx, closeDb } from '../src/utils/db.js';

const dir = path.resolve(process.argv[2] || './data');
const read = async name => { try { return JSON.parse(await fs.readFile(path.join(dir, `${name}.json`), 'utf8')); } catch { return []; } };
const ts = v => v || new Date().toISOString();

await initDb();
const [customers, workers, requests, feedback, assessments, tokens, sessions] =
  await Promise.all(['customers', 'workers', 'requests', 'feedback', 'assessments', 'refresh_tokens', 'ai_sessions'].map(read));

const counts = await tx(async db => {
  const n = {};
  const run = async (key, rows, fn) => { n[key] = 0; for (const r of rows) { const res = await fn(r); n[key] += res.rowCount; } };

  await run('customers', customers, c => db.query(
    `INSERT INTO customers (id,name,email,password_hash,last_lat,last_lng,last_radius_km,last_label,last_location_at,created_at,updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT DO NOTHING`,
    [c.id, c.name, c.email, c.passwordHash, c.lastLocation?.lat ?? null, c.lastLocation?.lng ?? null, c.lastLocation?.radiusKm ?? null,
     c.lastLocation?.label ?? null, c.lastLocation?.updatedAt ?? null, ts(c.createdAt), ts(c.updatedAt)]));

  await run('workers', workers, w => db.query(
    `INSERT INTO workers (id,name,email,password_hash,profession,lat,lng,service_radius_km,rating,reviews,avatar,status,available,availability,
       response_rate,completion_rate,punctuality,professionalism,safety,success_rate,jobs_completed,price_range,
       verif_identity,verif_credential,verif_assessment,verif_authorization,verif_eligible,created_at,updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29) ON CONFLICT DO NOTHING`,
    [w.id, w.name, w.email, w.passwordHash, w.profession, w.location.lat, w.location.lng, w.location.serviceRadiusKm ?? 5,
     w.rating ?? 0, w.reviews ?? 0, w.avatar ?? null, w.status || 'active', w.available ?? true, w.availability || [],
     w.responseRate ?? 0, w.completionRate ?? 0, w.punctuality ?? 0, w.professionalism ?? 0, w.safety ?? 0, w.successRate ?? 0,
     w.jobsCompleted ?? 0, w.priceRange ?? null,
     !!w.verification?.identity, !!w.verification?.credential, !!w.verification?.assessment,
     w.verification?.authorization === undefined || w.verification?.authorization === false ? null : String(w.verification.authorization),
     !!w.verification?.eligible, ts(w.createdAt), ts(w.updatedAt)]));

  await run('requests', requests, r => db.query(
    `INSERT INTO requests (id,customer_id,worker_id,profession,problem,slot,mode,lat,lng,location_label,status,created_at,updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT DO NOTHING`,
    [r.id, r.customerId, r.workerId, r.profession, r.problem || '', r.slot, r.mode === 'ai' ? 'ai' : 'self', r.location.lat, r.location.lng,
     r.location.label || 'Selected service location', r.status, ts(r.createdAt), ts(r.updatedAt)]));

  await run('feedback', feedback, f => db.query(
    `INSERT INTO feedback (id,request_id,worker_id,customer_id,rating,comment,punctuality,professionalism,safety,created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT DO NOTHING`,
    [f.id, f.requestId, f.workerId, f.customerId, f.rating, f.comment || '', f.punctuality, f.professionalism, f.safety, ts(f.createdAt)]));

  await run('assessments', assessments, a => db.query(
    `INSERT INTO assessments (id,worker_id,profession,score,total,passed,submitted_at) VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING`,
    [a.id, a.workerId, a.profession, a.score, a.total, !!a.passed, ts(a.submittedAt)]));

  await run('refresh_tokens', tokens.filter(t => new Date(t.expiresAt) > new Date() && !t.revoked), t => db.query(
    `INSERT INTO refresh_tokens (id,token_hash,user_id,role,expires_at,revoked) VALUES ($1,$2,$3,$4,$5,FALSE) ON CONFLICT DO NOTHING`,
    [t.id, t.tokenHash, t.userId, t.role, t.expiresAt]));

  await run('ai_sessions', sessions, s => db.query(
    `INSERT INTO ai_sessions (id,customer_id,messages,created_at,updated_at) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING`,
    [s.id, s.customerId, JSON.stringify(s.messages || []), ts(s.createdAt), ts(s.updatedAt)]));
  return n;
});

console.log(`Imported from ${dir}:`, counts);
await closeDb();
