import app from './src/app.js';
import {env} from './src/config/env.js';
import {initDb,closeDb} from './src/utils/db.js';
import {seed} from './src/services/seedService.js';
await initDb();await seed();
const server=app.listen(env.port,()=>console.log(`Local Link API v2 running at http://localhost:${env.port} (PostgreSQL)`));
const shutdown=()=>server.close(async()=>{await closeDb();process.exit(0);});process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);


export default app;
