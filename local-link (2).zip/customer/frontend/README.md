# Local Link — React + Leaflet prototype

A polished customer-side prototype for booking local service professionals.

## Features
- Customer / Service Professional entry screen
- AI Automated mode: chat-style problem description -> profession detection -> ranked professionals -> booking
- Self Booking mode: OpenStreetMap + Leaflet -> landmark search/click -> 3–5 km radius -> profession -> 1-hour slot -> ranked professionals -> booking
- Worker Console: incoming booking request -> accept -> confirmation
- Confirmation email workflow through Node/Express + Nodemailer
- Demo email mode works without SMTP credentials
- Responsive white / sky-blue / dark-blue UI with Framer Motion transitions

## Run

```bash
npm install
npm run start
```

Open http://localhost:5173

API health: http://localhost:5000/api/health

## Email

Copy `.env.example` to `.env`.

Without SMTP credentials, accepting a request works in demo mode and prints both email recipients and message content in the backend terminal.

For real delivery, set SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASS and MAIL_FROM.

## Map

The prototype uses Leaflet with OpenStreetMap tiles and Nominatim search. Public OSM/Nominatim services have usage policies and rate limits; a production application should follow those policies and consider a suitable hosted geocoding/tile provider.

## Important prototype note

Worker verification shown in the UI is demo data. A real government-authorized verification system requires integration with the relevant competent authority and cannot be created merely by the website itself.
