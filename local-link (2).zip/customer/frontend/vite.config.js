export default { base: '/customer/' };
