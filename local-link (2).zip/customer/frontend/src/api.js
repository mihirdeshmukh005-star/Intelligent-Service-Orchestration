// Customer Frontend -> Customer Backend connector
export const API = (import.meta.env.VITE_API_URL ?? '/svc/customer').replace(/\/$/, '');
// ---- Login bridge: tokens come from the Local Link login session (cookie), never from passwords in the browser ----
async function bridge(app) {
  const res = await fetch(`/api/bridge/token?app=${app}`, { credentials: 'same-origin' });
  const j = await res.json().catch(() => ({}));
  if (res.status === 401) { location.replace('/'); throw new Error('Please log in.'); }
  if (res.status === 403 && j.error === 'ASSESSMENT_REQUIRED') { location.replace('/assessment/'); throw new Error(j.message); }
  if (res.status === 403) { location.replace('/'); throw new Error(j.message); }
  if (!res.ok) throw new Error(j.message || 'Could not start your session.');
  return j;
}
export async function signOut() {
  try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: '{}' }); } catch {}
  location.replace('/');
}


let tokens = { customer: null };
let savedLocation = null;
async function customerSession(){
  if(tokens.customer) return tokens.customer;
  const j=await bridge('customer');
  tokens.customer=j.token;
  return tokens.customer;
}
async function raw(path,{method='GET',body,token}={}){
  const headers={'Content-Type':'application/json'};
  if(token) headers.Authorization=`Bearer ${token}`;
  const res=await fetch(API+path,{method,headers,body:body?JSON.stringify(body):undefined});
  const json=await res.json().catch(()=>({}));
  return {res,json};
}
export async function init(){ await customerSession(); return true; }

async function customerCall(path, opts = {}, retry = true) {
  const token = await customerSession();
  const { res, json } = await raw(path, { ...opts, token });
  if (res.status === 401 && retry) { tokens.customer = null; return customerCall(path, opts, false); }
  if (!res.ok || json.ok === false) throw new Error(json.error || `Request failed (${res.status})`);
  return json;
}

const ICONS = { 'House Keeping': '🧹', Electrician: '⚡', Plumber: '💧', 'AC Technician': '❄️', Carpenter: '🔨', Painter: '🎨', Locksmith: '🔑', Cleaner: '🧹', 'Appliance Repair': '🔧' };
// Backend worker -> shape the existing UI components already expect
export const toWorker = w => ({
  id: w.id, name: w.name, profession: w.profession, rating: w.rating, reviews: w.reviews,
  eta: Math.round(10 + w.distanceKm * 6), price: w.priceRange, lat: w.lat, lng: w.lng,
  verified: !!w.verification?.eligible, available: true, response: `${Math.round(w.responseRate)}%`, jobs: w.jobsCompleted,
  email: w.email, image: w.avatar || ICONS[w.profession] || '🛠️', distance: w.distanceKm
});

export async function saveLocation(lat, lng, label, radiusKm = 5) {
  savedLocation = { lat, lng, label, radiusKm };
  await customerCall('/api/customer/location', { method: 'POST', body: { lat, lng, label, radiusKm } });
}
export const getSavedLocation = () => savedLocation;
export async function matchWorkers({ lat, lng, radiusKm, profession, slot }) {
  const d = await customerCall('/api/customer/match', { method: 'POST', body: { lat, lng, radiusKm, profession, slot } });
  return d.workers.map(toWorker);
}
export async function searchLocation(q) {
  return (await customerCall(`/api/locations/search?q=${encodeURIComponent(q)}`)).results;
}
let aiSession;
export async function aiMessage(message) {
  const d = await customerCall('/api/customer/ai/message', { method: 'POST', body: { message, sessionId: aiSession } });
  aiSession = d.sessionId;
  return { reply: d.reply, analysis: d.analysis, workers: d.workers.map(toWorker) };
}
export async function createBooking(b) { return (await customerCall('/api/customer/bookings', { method: 'POST', body: b })).request; }
export async function getBookings() { return (await customerCall('/api/customer/bookings')).requests; }
export async function submitFeedback(id, body) { return (await customerCall(`/api/customer/bookings/${id}/feedback`, { method: 'POST', body })).feedback; }

