import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft, ArrowRight, Bell, CalendarDays, Check, CircleCheckBig, Clock3,
  Droplets, Hammer, Home, KeyRound, LocateFixed, LogIn, Mail, MapPin,
  Navigation, Paintbrush, Search, Send, ShieldCheck, Snowflake, Sparkles,
  Star, Users, Wrench, X, Zap, UserRound
} from "lucide-react";
import { Circle, MapContainer, Marker, Popup, TileLayer, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

import * as api from "./api.js";

const categories = [
  { label: "Electrician", icon: Zap },
  { label: "Plumber", icon: Droplets },
  { label: "Carpenter", icon: Hammer },
  { label: "House Keeping", icon: Home }
];

const slots = Array.from({ length: 17 }, (_, i) => {
  const hour = i + 6;
  const next = hour + 1;
  const fmt = h => `${String(h).padStart(2, "0")}:00`;
  return `${fmt(hour)}–${fmt(next)}`;
});

const defaultCenter = [20.0059, 73.7904];
const DEFAULT_RADIUS = 5;

function distanceKm(aLat, aLng, bLat, bLng) {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const lat1 = (aLat * Math.PI) / 180;
  const lat2 = (bLat * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function rankWorkers(list) {
  return [...list].sort((a, b) => {
    const scoreA = a.rating * 20 + Number(a.response.replace("%", "")) * 0.08 + a.jobs * 0.005 - a.distance * 3;
    const scoreB = b.rating * 20 + Number(b.response.replace("%", "")) * 0.08 + b.jobs * 0.005 - b.distance * 3;
    return scoreB - scoreA;
  });
}

function MapClick({ onPick }) {
  useMapEvents({ click: event => onPick({ lat: event.latlng.lat, lng: event.latlng.lng }) });
  return null;
}

function Recenter({ center }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, map.getZoom(), { animate: true });
  }, [center, map]);
  return null;
}

function Header({ onHome, onLogin, onBookings }) {
  return (
    <header className="topbar">
      <button className="brand" onClick={onHome} aria-label="Local Link home">
        <span className="brand-mark"><MapPin size={18} fill="white" /></span>
        <span>Local Link</span>
      </button>
      <nav className="nav" aria-label="Main navigation">
        <button onClick={onHome}>Home</button>
        <button onClick={() => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" })}>Services</button>
        <button onClick={() => document.getElementById("how")?.scrollIntoView({ behavior: "smooth" })}>How It Works</button>
        <button onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}>About</button>
      </nav>
      <div className="header-actions">
        <button className="login-link" onClick={onBookings}><CalendarDays size={16} /> Bookings</button><button className="login-link" onClick={onLogin}><LogIn size={16} /> Log out</button>
        
      </div>
    </header>
  );
}

function ChoiceScreen({ onSelect }) {
  return (
    <div className="choice-overlay">
      <motion.div className="choice-card" initial={{ opacity: 0, y: 24, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.35 }}>
        <div className="choice-brand"><span className="brand-mark"><MapPin size={18} fill="white" /></span> Local Link</div>
        <h2>Welcome back 👋</h2>
        <p className="muted">How do you want to continue?</p>
        <button className="role-card professional" onClick={() => onSelect("worker")}>
          <span className="role-icon"><Users size={25} /></span>
          <span><b>Service Professional</b><small>Get nearby jobs & manage your services.</small></span>
          <ArrowRight />
        </button>
        <button className="role-card customer" onClick={() => onSelect("customer")}>
          <span className="role-icon home-icon"><Home size={25} /></span>
          <span><b>Customer</b><small>Find & book trusted professionals near you.</small></span>
          <ArrowRight />
        </button>
      </motion.div>
    </div>
  );
}

function Landing({ onSelectCustomer }) {
  const steps = [
    [Search, "Discover", "Find nearby professionals"],
    [ShieldCheck, "Compare", "Check ratings & verification"],
    [CalendarDays, "Book", "Choose a convenient slot"],
    [CircleCheckBig, "Get It Done", "Worker accepts the request"]
  ];

  return (
    <div className="page">
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">Local Services Made Simple</span>
          <h1>Your local problem.<br />The right professional.<br /><em>One simple booking.</em></h1>
          <p>Find verified local professionals without calling multiple people, repeating your problem, or guessing who is available.</p>
          <div className="hero-steps">
            {steps.map(([Icon, title, text]) => (
              <div className="mini-step" key={title}><Icon /><b>{title}</b><span>{text}</span></div>
            ))}
          </div>
          <div className="stats">
            <span><Users /><b>500+</b><small>Professionals</small></span>
            <span><Wrench /><b>1,200+</b><small>Service jobs</small></span>
            <span><Star fill="currentColor" /><b>4.8★</b><small>Average rating</small></span>
          </div>
        </div>
        <div className="hero-visual" aria-label="Local professional map preview">
          <div className="map-glow" />
          <div className="map-road road-a" /><div className="map-road road-b" />
          <div className="map-pin-big"><MapPin size={42} fill="currentColor" /></div>
          <div className="floating-worker w1"><span>⚡</span><b>Electrician</b><strong>4.9 ★</strong><small>1.2 km</small></div>
          <div className="floating-worker w2"><span>💧</span><b>Plumber</b><strong>4.8 ★</strong><small>1.8 km</small></div>
          <div className="floating-worker w3"><span>❄️</span><b>AC Technician</b><strong>4.7 ★</strong><small>2.6 km</small></div>
        </div>
      </section>

      <section id="services" className="section">
        <div className="section-heading"><span className="eyebrow">Choose your booking mode</span><h2>Get to the right professional faster.</h2><p>Let the assistant understand your problem, or choose the location and professional yourself.</p></div>
        <div className="mode-grid">
          <motion.button whileHover={{ y: -6 }} whileTap={{ scale: 0.99 }} className="mode-card ai" onClick={() => onSelectCustomer("ai")}>
            <div className="mode-icon"><Sparkles /></div><span className="mode-label">AI Automated</span>
            <h3>Just explain the problem.</h3>
            <p>Describe the real situation in simple words. Local Link identifies the likely profession and ranks suitable verified professionals nearby.</p>
            <span className="mode-link">Start AI matching <ArrowRight /></span>
          </motion.button>
          <motion.button whileHover={{ y: -6 }} whileTap={{ scale: 0.99 }} className="mode-card self" onClick={() => onSelectCustomer("self")}>
            <div className="mode-icon"><MapPin /></div><span className="mode-label">Self Booking</span>
            <h3>Choose your place and professional.</h3>
            <p>Search a landmark or click the map, choose a profession and time slot, then compare nearby top-rated professionals.</p>
            <span className="mode-link">Open map booking <ArrowRight /></span>
          </motion.button>
        </div>
      </section>

      <section id="how" className="section soft">
        <div className="section-heading"><span className="eyebrow">How it works</span><h2>From problem to professional.</h2></div>
        <div className="timeline">
          {["Describe the problem or select a location", "Find eligible nearby professionals", "Choose a 1-hour time slot", "Worker receives and accepts request", "Both sides receive confirmation"].map((item, i) => (
            <div className="timeline-item" key={item}><span>{i + 1}</span><b>{item}</b></div>
          ))}
        </div>
      </section>

      <section id="about" className="section about">
        <div><span className="eyebrow">Trust layer</span><h2>Recommendations are more than ratings.</h2><p>Professionals are ranked using service match, availability, distance, reputation, response reliability and verification status.</p></div>
        <div className="trust-box"><ShieldCheck size={28} /><b>Verified professionals first</b><span>The prototype only exposes verified workers as eligible booking candidates.</span></div>
      </section>
    </div>
  );
}

function AIAssistant({ onBack, onBook }) {
  const [messages, setMessages] = useState([{ from: "ai", text: "Hi! Tell me what is happening. Example: “My kitchen tap is leaking and I need someone tomorrow morning.”" }]);
  const [input, setInput] = useState("");
  const [analysis, setAnalysis] = useState(null);
  const [slot, setSlot] = useState("");

  const analyze = async () => {
    const raw = input.trim();
    if (!raw) return;
    setInput("");
    try {
      if (!api.getSavedLocation()) await api.saveLocation(defaultCenter[0], defaultCenter[1], "Nashik service area", DEFAULT_RADIUS);
      const r = await api.aiMessage(raw);
      setMessages(prev => [...prev, { from: "user", text: raw }, { from: "ai", text: r.reply }]);
      if (r.analysis?.profession) setAnalysis({ profession: r.analysis.profession, workers: r.workers, problem: raw });
    } catch (e) {
      setMessages(prev => [...prev, { from: "user", text: raw }, { from: "ai", text: `Sorry, I could not reach Local Link right now (${e.message}).` }]);
    }
  };

  return (
    <div className="workspace">
      <div className="workspace-top"><button className="back-btn" onClick={onBack}><ArrowLeft /> Back</button><div className="workspace-title"><Sparkles /> AI Automated</div><span className="secure-pill"><ShieldCheck size={15} /> Smart matching</span></div>
      <div className="ai-layout">
        <div className="chat-panel">
          <div className="chat-header"><div className="ai-avatar"><Sparkles /></div><div><b>Local Link AI</b><small>Problem analysis & local matching</small></div></div>
          <div className="messages">{messages.map((message, index) => <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className={`bubble ${message.from}`} key={`${message.from}-${index}`}>{message.text}</motion.div>)}</div>
          <div className="chat-input"><textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); analyze(); } }} placeholder="Explain your problem..." /><button onClick={analyze} aria-label="Analyze problem"><Send size={18} /></button></div>
        </div>
        <div className="results-panel">
          {!analysis ? <div className="empty-analysis"><Sparkles size={38} /><h3>Tell me the problem</h3><p>The prototype analyses keywords from the description and demonstrates the recommendation workflow.</p></div> : (
            <div className="worker-results">
              <div className="results-head"><div><span className="eyebrow">Recommended</span><h2>{analysis.profession}s near you</h2></div><span className="result-count">{analysis.workers.length} matches</span></div>
              <div className="ai-summary"><b>Detected request</b><span>{analysis.problem}</span></div>
              <label className="compact-label">Preferred time slot</label>
              <select className="compact-select" value={slot} onChange={e => setSlot(e.target.value)}><option value="">Select a slot</option>{slots.map(s => <option key={s}>{s}</option>)}</select>
              {analysis.workers.map((worker, index) => <WorkerRow key={worker.id} worker={worker} index={index} onBook={() => onBook({ ...worker, requestedSlot: slot, problem: analysis.problem, mode: "ai", coords: api.getSavedLocation() || { lat: defaultCenter[0], lng: defaultCenter[1], radiusKm: DEFAULT_RADIUS }, location: api.getSavedLocation()?.label })} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function WorkerRow({ worker, index = 0, onBook }) {
  return (
    <motion.div layout initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.05 }} className="worker-row">
      <div className="avatar-emoji">{worker.image}</div>
      <div className="worker-main">
        <div className="name-line"><b>{worker.name}</b>{worker.verified && <span className="verified"><ShieldCheck size={13} /> Verified</span>}</div>
        <span>{worker.profession} • {worker.distance.toFixed(1)} km away • ETA {worker.eta} min</span>
        <div className="worker-meta"><span><Star size={14} fill="currentColor" /> {worker.rating} ({worker.reviews})</span><span>{worker.price}</span><span>Response {worker.response}</span></div>
      </div>
      <button className="book-btn" onClick={onBook}>Book <ArrowRight size={16} /></button>
    </motion.div>
  );
}

function SelfBooking({ onBack, onBook }) {
  const [center, setCenter] = useState(defaultCenter);
  const [picked, setPicked] = useState({ lat: defaultCenter[0], lng: defaultCenter[1] });
  const [query, setQuery] = useState("");
  const [placeName, setPlaceName] = useState("Nashik service area");
  const [radius, setRadius] = useState(DEFAULT_RADIUS);
  const [profession, setProfession] = useState("");
  const [slot, setSlot] = useState("");
  const [status, setStatus] = useState("");

  const [nearbyWorkers, setNearbyWorkers] = useState([]);
  useEffect(() => {
    if (!profession) { setNearbyWorkers([]); return; }
    let live = true;
    api.matchWorkers({ lat: picked.lat, lng: picked.lng, radiusKm: radius, profession, slot })
      .then(list => { if (live) setNearbyWorkers(list); })
      .catch(e => { if (live) { setNearbyWorkers([]); setStatus(e.message); } });
    return () => { live = false; };
  }, [profession, radius, picked, slot]);

  const selectLocation = (lat, lng, label = "Selected map location") => {
    setPicked({ lat, lng });
    setCenter([lat, lng]);
    setPlaceName(label);
    setStatus(`Location selected. Showing professionals within ${radius} km.`);
    api.saveLocation(lat, lng, label, radius).catch(() => {});
  };

  const locate = () => {
    if (!navigator.geolocation) {
      setStatus("Geolocation is not supported. Click the map or search a landmark.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => selectLocation(pos.coords.latitude, pos.coords.longitude, "Your current location"),
      () => setStatus("Location permission was unavailable. Search a landmark or click the map.")
    );
  };

  const searchPlace = async () => {
    const value = query.trim();
    if (!value) return;
    setStatus("Finding location…");
    try {
      const results = await api.searchLocation(value);
      if (!results.length) {
        setStatus("Location not found. Try a landmark, hotel or area name.");
        return;
      }
      selectLocation(results[0].lat, results[0].lng, results[0].label);
    } catch {
      setStatus("Could not reach the location search service. You can still click the map.");
    }
  };

  return (
    <div className="workspace">
      <div className="workspace-top"><button className="back-btn" onClick={onBack}><ArrowLeft /> Back</button><div className="workspace-title"><MapPin /> Self Booking</div><span className="secure-pill">OpenStreetMap + Leaflet</span></div>
      <div className="self-grid">
        <div className="map-card">
          <div className="map-toolbar">
            <div className="search-map"><Search size={17} /><input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => { if (e.key === "Enter") searchPlace(); }} placeholder="Search Jatra Hotel, area or landmark…" /><button onClick={searchPlace}>Search</button></div>
            <button className="locate-btn" onClick={locate}><LocateFixed size={17} /> Use my location</button>
          </div>
          <MapContainer center={center} zoom={14} scrollWheelZoom className="leaflet-map">
            <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <Recenter center={center} />
            <MapClick onPick={point => selectLocation(point.lat, point.lng)} />
            <Circle center={[picked.lat, picked.lng]} radius={radius * 1000} pathOptions={{ color: "#1677ff", fillColor: "#1677ff", fillOpacity: 0.08 }} />
            <Marker position={[picked.lat, picked.lng]} icon={L.divIcon({ className: "custom-marker", html: "<div></div>", iconSize: [22, 22], iconAnchor: [11, 11] })}><Popup>{placeName}</Popup></Marker>
            {nearbyWorkers.map(worker => <Marker key={worker.id} position={[worker.lat, worker.lng]} icon={L.divIcon({ className: "worker-marker", html: `<div>${worker.image}</div>`, iconSize: [38, 38], iconAnchor: [19, 19] })}><Popup><b>{worker.name}</b><br />{worker.rating} ★ • {worker.distance.toFixed(1)} km away</Popup></Marker>)}
          </MapContainer>
          <div className="map-note"><MapPin size={15} /> Click the map or search a landmark. Radius: {radius} km.</div>
        </div>

        <aside className="booking-sidebar">
          <span className="eyebrow">Book a professional</span><h2>Tell us where & when.</h2>
          <div className="selected-place"><Navigation size={18} /><div><b>Service location</b><span title={placeName}>{placeName}</span><small>{picked.lat.toFixed(5)}, {picked.lng.toFixed(5)}</small></div></div>
          <label>Search radius <b>{radius} km</b></label><input type="range" min="3" max="5" step="1" value={radius} onChange={e => setRadius(Number(e.target.value))} />
          <label>Professional</label>
          <div className="category-grid">{categories.map(category => { const Icon = category.icon; return <button className={profession === category.label ? "active" : ""} key={category.label} onClick={() => setProfession(category.label)}><Icon size={17} />{category.label}</button>; })}</div>
          <label>Time slot <span>6:00 AM – 11:00 PM</span></label>
          <select value={slot} onChange={e => setSlot(e.target.value)}><option value="">Select a time slot</option>{slots.map(s => <option key={s}>{s}</option>)}</select>
          {status && <div className="inline-status"><MapPin size={15} />{status}</div>}
          {profession && slot ? (
            nearbyWorkers.length ? <div className="sidebar-results"><div className="sidebar-result-title"><b>Top {profession}s</b><span>{nearbyWorkers.length} nearby</span></div>{nearbyWorkers.map((worker, index) => <WorkerRow key={worker.id} worker={worker} index={index} onBook={() => onBook({ ...worker, requestedSlot: slot, location: placeName, mode: "self", coords: { lat: picked.lat, lng: picked.lng, radiusKm: radius } })} />)}</div> : <div className="hint-box"><ShieldCheck /><span>No verified {profession.toLowerCase()} is inside the selected {radius} km radius. Try a wider radius or another profession.</span></div>
          ) : <div className="hint-box"><Clock3 /><span>Select a professional and a time slot to see verified workers ranked by proximity, rating and reliability.</span></div>}
        </aside>
      </div>
    </div>
  );
}

function WorkerConsole({ requests, onAccept, onBack }) {
  return (
    <div className="workspace">
      <div className="workspace-top"><button className="back-btn" onClick={onBack}><ArrowLeft /> Back</button><div className="workspace-title"><Bell /> Worker Console</div><span className="secure-pill">{requests.length} pending</span></div>
      <div className="console-card">
        <div className="console-head"><div><span className="eyebrow">Incoming requests</span><h2>Booking requests</h2></div><span className="verified"><ShieldCheck size={14} /> Verified worker workflow</span></div>
        {requests.length === 0 ? <div className="empty-console"><CircleCheckBig /><h3>No pending requests</h3><p>Submit a customer booking first. It will appear here for the worker to accept.</p></div> : requests.map(request => (
          <div className="request-card" key={request.id}>
            <div className="request-icon">{request.worker.image}</div>
            <div className="request-body"><b>{request.worker.name}</b><span>Request for {request.name || "Customer"} • {request.profession}</span><p>{request.problem || "Service requested by the customer."}</p><div className="request-details"><span><Mail size={14} /> {request.email}</span><span><MapPin size={14} /> {request.location}</span><span><Clock3 size={14} /> {request.slot}</span></div></div>
            <button className="accept-btn" onClick={() => onAccept(request)}>Accept Request <Check size={16} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

function BookingModal({ worker, onClose, onSend }) {
  const [name, setName] = useState(api.getMe()?.name || "Demo Customer");
  const [email, setEmail] = useState(api.getMe()?.email || "customer@example.com");
  const [slot, setSlot] = useState(worker.requestedSlot || "");
  const [location, setLocation] = useState(worker.location || "Selected map location, Nashik");
  const [problem, setProblem] = useState(worker.problem || "");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const submit = async event => {
    event.preventDefault();
    if (!name.trim() || !email.includes("@") || !slot || !location.trim()) {
      setError("Please complete your name, valid email, location and time slot.");
      return;
    }
    setError("");
    setSending(true);
    try {
      await onSend({ worker, name: name.trim(), email: email.trim(), slot, location: location.trim(), problem: problem.trim(), profession: worker.profession });
    } catch (e) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <motion.div initial={{ opacity: 0, y: 20, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} className="booking-modal">
        <button className="modal-close" onClick={onClose} aria-label="Close"><X /></button>
        <div className="modal-icon">{worker.image}</div><span className="eyebrow">Booking request</span><h2>Request {worker.name}</h2><p>The worker must accept the request before the booking is confirmed.</p>
        <form onSubmit={submit}>
          <div className="form-grid">
            <label>Your name<input value={name} onChange={e => setName(e.target.value)} /></label>
            <label>Your email<input type="email" value={email} onChange={e => setEmail(e.target.value)} /></label>
            <label>Time slot<select value={slot} onChange={e => setSlot(e.target.value)}><option value="">Select a slot</option>{slots.map(s => <option key={s}>{s}</option>)}</select></label>
            <label>Location<input value={location} onChange={e => setLocation(e.target.value)} /></label>
          </div>
          <label>Problem details<textarea value={problem} onChange={e => setProblem(e.target.value)} placeholder="Optional details for the professional…" /></label>
          {error && <div className="form-error">{error}</div>}
          <button className="primary-wide" disabled={sending}>{sending ? "Sending request…" : <>Send Booking Request <Send size={17} /></>}</button>
        </form>
      </motion.div>
    </div>
  );
}

function SuccessModal({ booking, onClose }) {
  return (
    <div className="modal-backdrop">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="success-modal">
        <div className="success-check"><Check /></div><span className="eyebrow">Request accepted</span><h2>Booking confirmed 🎉</h2>
        <p>{booking.emailSent ? "Confirmation emails were sent to the customer and professional." : "The booking is confirmed. Email is in demo mode unless SMTP is configured on the backend."}</p>
        <div className="email-summary">
          <div><Mail /><span><b>Customer</b>{booking.email}</span></div>
          <div><Mail /><span><b>Professional</b>{booking.worker.name}</span></div>
          <div><CalendarDays /><span><b>Time</b>{booking.slot}</span></div>
        </div>
        <div className="email-actions"><button onClick={onClose}>Continue</button><a href={`mailto:${booking.email}?subject=${encodeURIComponent("Local Link booking confirmed")}&body=${encodeURIComponent(`Your booking with ${booking.worker.name} is confirmed for ${booking.slot}.`)}`}>Open customer email</a></div>
      </motion.div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState("landing");
  const [bookingWorker, setBookingWorker] = useState(null);
  const [apiError, setApiError] = useState("");
  const [bookings, setBookings] = useState([]);
  const [bookingNotice, setBookingNotice] = useState(null);
  const [showBookings, setShowBookings] = useState(false);
  const [feedbackBooking, setFeedbackBooking] = useState(null);

  useEffect(() => { api.init().catch(() => {}); }, []);
  useEffect(() => {
    let alive=true;
    const load=async()=>{try{const list=await api.getBookings();if(!alive)return;setBookings(list);const latest=list[0];if(latest&&['accepted','rejected','auto-rejected'].includes(latest.status)){const key=`ll_notice_${latest.id}_${latest.status}`;if(sessionStorage.getItem(key)!=='1'){sessionStorage.setItem(key,'1');setBookingNotice(latest);}}}catch{}};
    load(); const t=setInterval(load,5000); return()=>{alive=false;clearInterval(t)};
  }, []);

  const customerFlow = mode => setScreen(mode === "ai" ? "ai" : "self");
  const sendRequest = async data => {
    const w=data.worker,c=w.coords||{lat:defaultCenter[0],lng:defaultCenter[1],radiusKm:DEFAULT_RADIUS};
    const created=await api.createBooking({workerId:w.id,slot:data.slot,problem:data.problem,mode:data.mode||"self",radiusKm:c.radiusKm||DEFAULT_RADIUS,location:{lat:c.lat,lng:c.lng,label:data.location}});
    setBookingWorker(null); setBookings(prev=>[{...created,worker:{id:w.id,name:w.name,profession:w.profession},slot:data.slot,status:'pending'},...prev]); setScreen("landing"); setApiError("Booking request sent. The professional must accept it before the exact location is disclosed.");
  };
  return <div className="app-shell">
    <Header onHome={()=>setScreen("landing")} onLogin={api.signOut} onBookings={()=>setShowBookings(true)} />
    <AnimatePresence mode="wait">
      {screen === "landing" && <motion.div key="landing" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}><Landing onSelectCustomer={customerFlow}/></motion.div>}
      {screen === "ai" && <motion.div key="ai" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}}><AIAssistant onBack={()=>setScreen("landing")} onBook={setBookingWorker}/></motion.div>}
      {screen === "self" && <motion.div key="self" initial={{opacity:0,x:20}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-20}}><SelfBooking onBack={()=>setScreen("landing")} onBook={setBookingWorker}/></motion.div>}
    </AnimatePresence>
    {bookingWorker && <BookingModal worker={bookingWorker} onClose={()=>setBookingWorker(null)} onSend={sendRequest}/>} 
    {bookingNotice && <BookingStatusModal booking={bookingNotice} onClose={()=>setBookingNotice(null)} onBookAgain={()=>{setBookingNotice(null);setScreen("self")}}/>}
    {showBookings && <BookingsModal bookings={bookings} onClose={()=>setShowBookings(false)} onFeedback={setFeedbackBooking}/>} 
    {feedbackBooking && <FeedbackModal booking={feedbackBooking} onClose={()=>setFeedbackBooking(null)} onSubmitted={async()=>{setFeedbackBooking(null);setBookings(await api.getBookings())}}/>}
    {apiError && <div className="toast-error" role="alert"><span>{apiError}</span><button onClick={()=>setApiError("")}><X size={16}/></button></div>}
    <footer><span>© 2026 Local Link. All rights reserved.</span><span>Privacy Policy&nbsp;&nbsp; | &nbsp;&nbsp;Terms of Service&nbsp;&nbsp; | &nbsp;&nbsp;Help</span></footer>
  </div>;
}

function BookingStatusModal({booking,onClose,onBookAgain}){const accepted=booking.status==='accepted';return <div className="modal-backdrop"><motion.div className="success-modal" initial={{opacity:0,y:15}} animate={{opacity:1,y:0}}><div className={`success-check ${accepted?'':'fail'}`}>{accepted?<Check/>:<X/>}</div><span className="eyebrow">BOOKING UPDATE</span><h2>{accepted?'Booking confirmed':'Professional unavailable'}</h2><p>{accepted?`Your booking with ${booking.worker?.name||'the professional'} is accepted. Confirmation emails are being sent to both sides.`:`${booking.worker?.name||'The selected professional'} did not accept this request. Please choose a new professional.`}</p>{accepted&&booking.location?.disclosed&&<div className="email-summary"><div><MapPin/><span><b>Location</b>{booking.location.label}</span></div></div>}<div className="email-actions"><button onClick={onClose}>Close</button>{!accepted&&<button onClick={onBookAgain}>Book a new professional</button>}</div></motion.div></div>}
function BookingsModal({bookings,onClose,onFeedback}){return <div className="modal-backdrop"><motion.div className="booking-modal" initial={{opacity:0,y:15}} animate={{opacity:1,y:0}}><button className="modal-close" onClick={onClose}><X/></button><span className="eyebrow">MY BOOKINGS</span><h2>Booking history</h2><div className="booking-history">{bookings.length===0?<p>No bookings yet.</p>:bookings.map(b=><div className="history-row" key={b.id}><div><b>{b.worker?.name||'Professional'}</b><span>{b.profession} · {b.slot}</span><small>{b.status}</small></div>{b.status==='completed'?<button onClick={()=>onFeedback(b)}>Rate service</button>:<span>{b.status}</span>}</div>)}</div></motion.div></div>}
function FeedbackModal({booking,onClose,onSubmitted}){const [stars,setStars]=useState(5),[punctuality,setPunctuality]=useState(5),[professionalism,setProfessionalism]=useState(5),[safety,setSafety]=useState(5),[comment,setComment]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');const submit=async e=>{e.preventDefault();setBusy(true);try{await api.submitFeedback(booking.id,{rating:stars,punctuality,professionalism,safety,comment});await onSubmitted()}catch(e){setError(e.message)}finally{setBusy(false)}};return <div className="modal-backdrop"><motion.div className="booking-modal" initial={{opacity:0,y:15}} animate={{opacity:1,y:0}}><button className="modal-close" onClick={onClose}><X/></button><span className="eyebrow">CUSTOMER REVIEW</span><h2>Rate {booking.worker?.name||'your professional'}</h2><form onSubmit={submit}><label>Overall rating<select value={stars} onChange={e=>setStars(Number(e.target.value))}>{[5,4,3,2,1].map(x=><option key={x} value={x}>{x} / 5</option>)}</select></label><label>Punctuality<select value={punctuality} onChange={e=>setPunctuality(Number(e.target.value))}>{[5,4,3,2,1].map(x=><option key={x} value={x}>{x} / 5</option>)}</select></label><label>Professionalism<select value={professionalism} onChange={e=>setProfessionalism(Number(e.target.value))}>{[5,4,3,2,1].map(x=><option key={x} value={x}>{x} / 5</option>)}</select></label><label>Safety<select value={safety} onChange={e=>setSafety(Number(e.target.value))}>{[5,4,3,2,1].map(x=><option key={x} value={x}>{x} / 5</option>)}</select></label><label>Review<textarea value={comment} onChange={e=>setComment(e.target.value)} maxLength={1000}/></label>{error&&<div className="form-error">{error}</div>}<button className="primary-wide" disabled={busy}>{busy?'Submitting…':'Submit review'}</button></form></motion.div></div>}
